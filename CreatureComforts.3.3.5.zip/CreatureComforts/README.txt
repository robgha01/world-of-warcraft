Creature Comforts
=================

* Written by Phanx <addons@phanx.net>
* Maintainted by Akkorian <akkorian@hotmail.com>
* Copyright © 2008–2011 Phanx. Some rights reserved. See LICENSE.txt for details.
* http://www.wowinterface.com/downloads/info9635-CreatureComforts.html
* http://wow.curse.com/downloads/wow-addons/details/creaturecomforts.aspx


Description
-----------

Creature Comforts combines all of your hunter pet upkeep skills into a
single “smart” button. It supports Call, Dismiss, Feed, Mend, and Revive
Pet. It works by automatically updating a macro that you can drag and
drop onto any action button or bind a key directly to.


Usage
-----

Options are available in the Interface Options window, or by typing
“/cc” or “/creaturecomforts”.

There are two ways to use Creature Comforts. You can simply bind a key
to Creature Comforts in the standard keybindings UI, or you can use a
macro that can be placed on any action button. The macro is created and
updated automatically, and can be found on the character tab in the
standard macro UI.


Localization
------------

Creature Comforts is compatible with English, Deutsch, Español,
Français, Русский, 한국어, 简体中文, and 正體中文 game clients.

Creature Comforts is translated into English and 简体中文. If you can
provide translations for another locale, please send me a PM.


Feedback
--------

Please use the ticket system on either download site report bugs or
request features. Use the comment system only for general questions
or comments.

If you need to contact me privately, you may do by private message
on either download site, or by email at <akkorian@hotmail.com>.
--[[--------------------------------------------------------------------
	Creature Comforts
	Combines all of your hunter pet upkeep skills into a single button.
	Written by Phanx <addons@phanx.net>
	Maintainted by Akkorian <akkorian@hotmail.com>
	Copyright © 2008–2011 Phanx. Some rights reserved. See LICENSE.txt for details.
	http://www.wowinterface.com/downloads/info9635-CreatureComforts.html
	http://wow.curse.com/downloads/wow-addons/details/creaturecomforts.aspx
----------------------------------------------------------------------]]

--if select(2, UnitClass("player")) ~= "HUNTER" then return end

local locale = GetLocale()
if locale:match("^en") then return end

local L = { }
local _, namespace = ...
namespace.L = L

------------------------------------------------------------------------
--	deDE | Deutsch | German
--	Last updated 2008-07-28 by cM
------------------------------------------------------------------------

if locale == "deDE" then
	L["Bread"] = "Brot"
	L["Cheese"] = "Käse"
	L["Fish"] = "Fisch"
	L["Fruit"] = "Obst"
	L["Fungus"] = "Fungus"
	L["Meat"] = "Fleisch"

	L["%s is very hungry!"] = "%s ist sehr hungrig!"
	L["%s is hungry."] = "%s ist hungrig!"
	L["You don't have any food for %s."] = "Sie haben noch keine Nahrung für %s."

--	L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."] = ""
--	L["Create Macro"] = ""
--	L["Create a character-specific macro for one-button pet care."] = ""
--	L["All character macro slots are in use."] = ""
	L["Key Binding"] = KEY_BINDING
--	L["Click to set a key binding for activating the Creature Comforts macro."] = ""
--	L["Use bonus foods"] = ""
--	L["Feed your pet items which provide stat bonuses when eaten."] = ""
--	L["Use combo foods"] = ""
--	L["Feed your pet items which restore both health and mana when eaten."] = ""
--	L["Use conjured foods"] = ""
--	L["Feed your pet items conjured by mages."] = ""
--	L["Use raw foods"] = ""
--	L["Feed your pet items which may be used by the Cooking profession."] = ""
--	L["Feed when happy."] = ""
--	L["Automatically consume food items even if your pet is already happy."] = ""
--	L["Warn when hungry"] = ""
--	L["Print a notice when your pet is less than happy."] = ""
--	L["Warn when out of food"] = ""
--	L["Print a warning when you have no food to feed your pet."] = ""
--	L["Alt"] = ""
--	L["Ctrl"] = ""
--	L["Shift"] = ""
--	L["Dismiss modifier"] = ""
--	L["Use this modifier key to dismiss your pet."] = ""
--	L["Mend modifier"] = ""
--	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = ""
--	L["Mend threshold"] = ""
--	L["Mend your pet out of combat by default when its health is below this percent."] = ""
--	L["Show item icon"] = ""
--	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = ""
return end

------------------------------------------------------------------------
--	esES | Español (EU) | Spanish (Europe)
--	esMX | Español (AL) | Spanish (Latin America)
--	Last updated 2011-01-18 by Akkorian
------------------------------------------------------------------------

if locale == "esES" or locale == "esMX" then
	L["Bread"] = "Pan"
	L["Cheese"] = "Queso"
	L["Fish"] = "Pescado"
	L["Fruit"] = "Fruta"
	L["Fungus"] = "Hongo"
	L["Meat"] = "Carne"

	L["%s is very hungry!"] = "%s tiene mucha hambre!"
	L["%s is hungry."] = "%s tiene hambre."
	L["You don't have any food for %s."] = "No tienes ningún comida para %s."

	L["These settings allow you to configure how Creature Comforts works."] = "Estes opciones te permiten configurar el modo en que el addon funciona."
	L["Create Macro"] = "Obtener Macro"
	L["Create a character-specific macro for one-button pet care"] = "Obtener una macro del personaje para el cuidado de tu mascota con un solo botón."
	L["All character macro slots are in use."] = "Todas las casillas para macros del personaje ya están en uso."
	L["Key Binding"] = KEY_BINDING
	L["Click to set a key binding for activating the Creature Comforts macro."] = "Clic para asignar una tecla para activar la macro de Creature Comforts."
	L["Use bonus foods"] = "Usar comdida con bonos"
	L["Feed your pet items which provide stat bonuses when eaten"] = "Alimente a tu mascota los alimentos que dan bonificaciones cuando te comes."
	L["Use combo foods"] = "Usar comida combinados"
	L["Feed your pet items which restore both health and mana when eaten"] = "Alimente a tu mascota los alimentos que restaurar la salud y maná cuando te comes."
	L["Use conjured foods"] = "Usar comida creados"
	L["Feed your pet items conjured by mages"] = "Alimente a tu mascota los alimentos que fueron crearon por arte de magia."
	L["Use raw foods"] = "Usar comida crudos"
	L["Feed your pet items which may be used by the Cooking profession"] = "Alimente a tu mascota los alimentos que te puedes cocinar."
	L["Feed when happy."] = "Alimentar cuando feliz"
	L["Automatically consume food items even if your pet is already happy."] = "Alimentar a tu mascota, incluso cuando está feliz."
	L["Warn when hungry"] = "Alertar cuando hambre"
	L["Print a notice when your pet is less than happy."] = "Alertar por un mensaje en el marco de chat cuando tu mascota no está feliz."
	L["Warn when out of food"] = "Alertar cuando"
	L["Print a warning when you have no food to feed your pet."] = "Alertar por un mensaje en el marco de chat cuando no tienen comida para tu mascota."
	L["Alt"] = "Alt"
	L["Ctrl"] = "Ctrl"
	L["Shift"] = "Mayús"
	L["Dismiss modifier"] = "Modificador para Retirar"
	L["Use this modifier key to dismiss your pet."] = "Usar este tecla de modificación para Retirar tu mascota."
	L["Mend modifier"] = "Modificador para Aliviar"
	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = "Usar este tecla de modificación para Aliviar tu mascota fuera de combate, o Revivir tu mascota en combate si es desaparecido."
	L["Mend threshold"] = "Umbral para Aliviar"
	L["Mend your pet out of combat by default when its health is below this percent."] = "Aliviar tu mascota fuere de combate sólo si su salud está por debajo de este porcentaje."
	L["Show item icon"] = "Mostrar icono de objeto"
	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = "Mostrar el icono del objeto que se alimenta a tu mascota, en lugar del icono del facultad Alimentar mascota."
return end

------------------------------------------------------------------------
--	frFR | Français | French
--	Last updated 2008-07-28 by Lanffeust
------------------------------------------------------------------------

if locale == "frFR" then
	L["Bread"] = "Pain"
	L["Cheese"] = "Fromage"
	L["Fish"] = "Poisson"
	L["Fruit"] = "Fruit"
	L["Fungus"] = "Champignon"
	L["Meat"] = "Viande"

	L["%s is very hungry!"] = "%s est très faim!"
	L["%s is hungry."] = "%s a faim!"
	L["You don't have any food for %s."] = "Vous n'avez pas de nourriture pour %s."

--	L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."] = ""
--	L["Create Macro"] = ""
--	L["Create a character-specific macro for one-button pet care"] = ""
--	L["All character macro slots are in use."] = ""
	L["Key Binding"] = KEY_BINDING
--	L["Click to set a key binding for activating the Creature Comforts macro."] = ""
--	L["Use bonus foods"] = ""
--	L["Feed your pet items which provide stat bonuses when eaten"] = ""
--	L["Use combo foods"] = ""
--	L["Feed your pet items which restore both health and mana when eaten"] = ""
--	L["Use conjured foods"] = ""
--	L["Feed your pet items conjured by mages"] = ""
--	L["Use raw foods"] = ""
--	L["Feed your pet items which may be used by the Cooking profession"] = ""
--	L["Feed when happy."] = ""
--	L["Automatically consume food items even if your pet is already happy."] = ""
--	L["Warn when hungry"] = ""
--	L["Print a notice when your pet is less than happy."] = ""
--	L["Warn when out of food"] = ""
--	L["Print a warning when you have no food to feed your pet."] = ""
--	L["Alt"] = ""
--	L["Ctrl"] = ""
--	L["Shift"] = ""
--	L["Dismiss modifier"] = ""
--	L["Use this modifier key to dismiss your pet."] = ""
--	L["Mend modifier"] = ""
--	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = ""
--	L["Mend threshold"] = ""
--	L["Mend your pet out of combat by default when its health is below this percent."] = ""
--	L["Show item icon"] = ""
--	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = ""
return end

------------------------------------------------------------------------
--	ruRU | Русский | Russian
--	Last updated 2008-08-10 by XisRaa
------------------------------------------------------------------------

if locale == "ruRU" then
	L["Bread"] = "Хлеб"
	L["Cheese"] = "Сыр"
	L["Fish"] = "Рыба"
	L["Fruit"] = "Фрукт"
	L["Fungus"] = "Гриб"
	L["Meat"] = "Мясо"

	L["%s is hungry."] = "%s голоден."
	L["%s is very hungry!"] = "%s очень голоден!"
	L["You don't have any food for %s."] = "У вас нет еды для %s."

--	L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."] = ""
--	L["Create Macro"] = ""
--	L["Create a character-specific macro for one-button pet care"] = ""
--	L["All character macro slots are in use."] = ""
	L["Key Binding"] = KEY_BINDING
--	L["Click to set a key binding for activating the Creature Comforts macro."] = ""
--	L["Use bonus foods"] = ""
--	L["Feed your pet items which provide stat bonuses when eaten"] = ""
--	L["Use combo foods"] = ""
--	L["Feed your pet items which restore both health and mana when eaten"] = ""
--	L["Use conjured foods"] = ""
--	L["Feed your pet items conjured by mages"] = ""
--	L["Use raw foods"] = ""
--	L["Feed your pet items which may be used by the Cooking profession"] = ""
--	L["Feed when happy."] = ""
--	L["Automatically consume food items even if your pet is already happy."] = ""
--	L["Warn when hungry"] = ""
--	L["Print a notice when your pet is less than happy."] = ""
--	L["Warn when out of food"] = ""
--	L["Print a warning when you have no food to feed your pet."] = ""
--	L["Alt"] = ""
--	L["Ctrl"] = ""
--	L["Shift"] = ""
--	L["Dismiss modifier"] = ""
--	L["Use this modifier key to dismiss your pet."] = ""
--	L["Mend modifier"] = ""
--	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = ""
--	L["Mend threshold"] = ""
--	L["Mend your pet out of combat by default when its health is below this percent."] = ""
--	L["Show item icon"] = ""
--	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = ""
return end

------------------------------------------------------------------------
--	koKR | 한국어 | Korean
--	Last updated YYYY-MM-DD by Nobody
------------------------------------------------------------------------

if locale == "koKR" then
	L["Bread"] = "빵"
	L["Cheese"] = "치즈"
	L["Fish"] = "물고기"
	L["Fruit"] = "과일"
	L["Fungus"] = "곰팡이류"
	L["Meat"] = "고기"

	L["%s is very hungry!"] = "%s 은 매우 배고파!"
	L["%s is hungry."] = "%s 은 배가됩니다."
	L["You don't have any food for %s."] = "당신은 %s 에 대한 모든 음식이 없어."

--	L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."] = ""
--	L["Create Macro"] = ""
--	L["Create a character-specific macro for one-button pet care"] = ""
--	L["All character macro slots are in use."] = ""
	L["Key Binding"] = KEY_BINDING
--	L["Click to set a key binding for activating the Creature Comforts macro."] = ""
--	L["Use bonus foods"] = ""
--	L["Feed your pet items which provide stat bonuses when eaten"] = ""
--	L["Use combo foods"] = ""
--	L["Feed your pet items which restore both health and mana when eaten"] = ""
--	L["Use conjured foods"] = ""
--	L["Feed your pet items conjured by mages"] = ""
--	L["Use raw foods"] = ""
--	L["Feed your pet items which may be used by the Cooking profession"] = ""
--	L["Feed when happy."] = ""
--	L["Automatically consume food items even if your pet is already happy."] = ""
--	L["Warn when hungry"] = ""
--	L["Print a notice when your pet is less than happy."] = ""
--	L["Warn when out of food"] = ""
--	L["Print a warning when you have no food to feed your pet."] = ""
--	L["Alt"] = ""
--	L["Ctrl"] = ""
--	L["Shift"] = ""
--	L["Dismiss modifier"] = ""
--	L["Use this modifier key to dismiss your pet."] = ""
--	L["Mend modifier"] = ""
--	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = ""
--	L["Mend threshold"] = ""
--	L["Mend your pet out of combat by default when its health is below this percent."] = ""
--	L["Show item icon"] = ""
--	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = ""
return end

------------------------------------------------------------------------
--	zhCN | 简体中文 | Simplified Chinese
--	Last updated 2008-12-27 by VENSTER
------------------------------------------------------------------------

if locale == "zhCN" then
	L["Bread"] = "面包"
	L["Cheese"] = "奶酪"
	L["Fish"] = "鱼"
	L["Fruit"] = "水果"
	L["Fungus"] = "蘑菇"
	L["Meat"] = "肉"

	L["%s is hungry."] = "%s有点饿了"
	L["%s is very hungry!"] = "%s很饿了"
	L["You don't have any food for %s."] = "包包里没有%s吃的东西"

--	L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."] = ""
	L["Create Macro"] = "创建宏"
	L["Create a character-specific macro for one-button pet upkeep"] = "创建一个角色专用宝宝一键管理宏"
	L["All character macros are in use."] = "所有的角色专用宏栏位均被使用"
	L["Key Binding"] = KEY_BINDING
--	L["Click to set a key binding for activating the Creature Comforts macro."] = ""
	L["Use bonus foods"] = "使用buff食品"
	L["Feed your pet items which provide stat bonuses when eaten"] = "将buff食品也包含在宝宝菜单中"
	L["Use combo foods"] = "使用混合食品"
	L["Feed your pet items which restore both health and mana when eaten"] = "将同时恢复生命与法力的食品也包含在宝宝菜单中"
	L["Use conjured foods"] = "使用魔法食物"
	L["Feed your pet items conjured by mages"] = "将法师制作的魔法食品也包含在宝宝菜单中"
	L["Use raw foods"] = "使用生食物"
	L["Feed your pet items which may be used by the Cooking profession"] = "将进一步烹饪的食品也包含在宝宝菜单中"
	L["Feed when happy."] = "高兴时依然喂食"
	L["Automatically consume food items even if your pet is already happy."] = "即使宝宝高兴，依然自动喂食合适的食物"
	L["Notify when hungry"] = "饥饿时通知"
	L["Print a notice when your pet is less than happy."] = "当宝宝不高兴是显示通知"
	L["Notify for no food"] = "没有食物时通知"
	L["Print a notice when you have no food to feed your pet."] = "当身上没有宝宝食物时显示通知"
	L["Show item icon"] = "显示物品图标"
	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = "显示将要喂给宝宝的食物图标，否则显示技能图标"
	L["Alt"] = "Alt"
	L["Ctrl"] = "Ctrl"
	L["Shift"] = "Shift"
	L["Dismiss modifier"] = "“解散”修饰键"
	L["Use this modifier key to dismiss your pet."] = "使用这个修饰键解散宝宝"
	L["Mend/Revive modifier"] = "“治疗/复活”修饰键"
	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = "使用这个修饰键治疗或者复活宝宝"
	L["Mend Threshold"] = "治疗阈值"
	L["Mend your pet out of combat by default when its health is below this percent."] = "宝宝生命值低于设定下限时，离开战斗后显示为治疗技能"
--	L["Show item icon"] = ""
--	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = ""
return end

------------------------------------------------------------------------
--	zhTW | 正體中文 | Traditional Chinese
--	Last updated YYYY-MM-DD by Nobody
------------------------------------------------------------------------

if locale == "zhTW" then
	L["Bread"] = "麵包"
	L["Cheese"] = "乳酪"
	L["Fish"] = "魚類"
	L["Fruit"] = "水果"
	L["Fungus"] = "菌類"
	L["Meat"] = "肉類"

	L["%s is very hungry!"] = "%s是非常餓！"
	L["%s is hungry."] = "%s是餓了。"
	L["You don't have any food for %s."] = "您沒有任何食物%s。"

--	L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."] = ""
--	L["Create Macro"] = ""
--	L["Create a character-specific macro for one-button pet care"] = ""
--	L["All character macro slots are in use."] = ""
	L["Key Binding"] = KEY_BINDING
--	L["Click to set a key binding for activating the Creature Comforts macro."] = ""
--	L["Use bonus foods"] = ""
--	L["Feed your pet items which provide stat bonuses when eaten"] = ""
--	L["Use combo foods"] = ""
--	L["Feed your pet items which restore both health and mana when eaten"] = ""
--	L["Use conjured foods"] = ""
--	L["Feed your pet items conjured by mages"] = ""
--	L["Use raw foods"] = ""
--	L["Feed your pet items which may be used by the Cooking profession"] = ""
--	L["Feed when happy."] = ""
--	L["Automatically consume food items even if your pet is already happy."] = ""
--	L["Warn when hungry"] = ""
--	L["Print a notice when your pet is less than happy."] = ""
--	L["Warn when out of food"] = ""
--	L["Print a warning when you have no food to feed your pet."] = ""
--	L["Alt"] = ""
--	L["Ctrl"] = ""
--	L["Shift"] = ""
--	L["Dismiss modifier"] = ""
--	L["Use this modifier key to dismiss your pet."] = ""
--	L["Mend modifier"] = ""
--	L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."] = ""
--	L["Mend threshold"] = ""
--	L["Mend your pet out of combat by default when its health is below this percent."] = ""
--	L["Show item icon"] = ""
--	L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."] = ""
return end

------------------------------------------------------------------------
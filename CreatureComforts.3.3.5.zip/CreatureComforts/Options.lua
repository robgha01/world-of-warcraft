--[[--------------------------------------------------------------------
	Creature Comforts
	Combines all of your hunter pet upkeep skills into a single button.
	Written by Phanx <addons@phanx.net>
	Maintainted by Akkorian <akkorian@hotmail.com>
	Copyright � 2008�2011 Phanx. Some rights reserved. See LICENSE.txt for details.
	http://www.wowinterface.com/downloads/info9635-CreatureComforts.html
	http://wow.curse.com/downloads/wow-addons/details/creaturecomforts.aspx
----------------------------------------------------------------------]]

local ADDON_NAME, namespace = ...
if not namespace.CreatureComforts then return end

------------------------------------------------------------------------

local optionsPanel = LibStub("PhanxConfig-OptionsPanel").CreateOptionsPanel(ADDON_NAME, nil, function(self)
	local CreatureComforts = namespace.CreatureComforts
	local db = CreatureComfortsDB
	local L = namespace.L

	local CreateCheckbox = LibStub("PhanxConfig-Checkbox").CreateCheckbox
	local CreateDropdown = LibStub("PhanxConfig-Dropdown").CreateDropdown
	local CreateSlider = LibStub("PhanxConfig-Slider").CreateSlider

	-------------------------------------------------------------------

	local title, notes = LibStub("PhanxConfig-Header").CreateHeader(self, self.name,
		L["These settings allow you to create and configure the behavior of the Creature Comforts pet care macro."])

	-------------------------------------------------------------------

	local macro = LibStub("PhanxConfig-Button").CreateButton(self, L["Get Macro"],
		L["Create a character-specific macro for one-button pet care"])
	macro:SetNormalFontObject(GameFontNormal)
	macro:SetDisabledFontObject(GameFontDisable)
	macro:SetHighlightFontObject(GameFontHighlight)
	macro:SetScript("OnClick", function(self)
		local id = GetMacroIndexByName("AutoPet")
		if id and id ~= 0 then
			PickupMacro(id)
		elseif select(2, GetNumMacros()) >= 18 then
			print("|cffaad372Creature Comforts:|r", L["All character macro slots are in use."])
		else
			id = CreateMacro("AutoPet", 1, "", 1, 1)
			CreatureComforts:Scan()
			PickupMacro(id)
		end
	end)

	local binding = LibStub("PhanxConfig-KeyBinding").CreateKeyBinding(self, L["Key Binding"],
		"CLICK CreatureComfortsButton:LeftButton",
		L["Click to set a key binding for activating the Creature Comforts macro."])
	binding:SetPoint("TOPLEFT", notes, "BOTTOM", -8, -8)
	binding:SetPoint("TOPRIGHT", notes, "BOTTOMRIGHT", 0, -8)

	macro:SetPoint("TOPLEFT", notes, "BOTTOMLEFT", 0, -8 + macro:GetHeight() - binding.container:GetHeight())
	macro:SetPoint("TOPRIGHT", notes, "BOTTOM", -8, -8 + macro:GetHeight() - binding.container:GetHeight())

	-------------------------------------------------------------------

	local useBonus = CreateCheckbox(self, L["Use bonus food"],
		L["Feed your pet items which provide stat bonuses when eaten."])
	useBonus:SetPoint("TOPLEFT", macro, "BOTTOMLEFT", -2, -8)
	useBonus.OnClick = function(self, checked)
		db.useBonus = checked
		CreatureComforts:Diet()
		CreatureComforts:Scan()
	end

	local useCombo = CreateCheckbox(self, L["Use combo food"],
		L["Feed your pet items which restore both health and mana when eaten."])
	useCombo:SetPoint("TOPLEFT", useBonus, "BOTTOMLEFT", 0, -8)
	useCombo.OnClick = function(self, checked)
		db.useCombo = checked
		CreatureComforts:Diet()
		CreatureComforts:Scan()
	end

	local useConjured = CreateCheckbox(self, L["Use conjured food"],
		L["Feed your pet items conjured by mages."])
	useConjured:SetPoint("TOPLEFT", useCombo, "BOTTOMLEFT", 0, -8)
	useConjured.OnClick = function(self, checked)
		db.useConjured = checked
		CreatureComforts:Diet()
		CreatureComforts:Scan()
	end

	local useRaw = CreateCheckbox(self, L["Use raw food"],
		L["Feed your pet items which may be used by the Cooking profession."])
	useRaw:SetPoint("TOPLEFT", useConjured, "BOTTOMLEFT", 0, -8)
	useRaw.OnClick = function(self, checked)
		db.useRaw = checked
		CreatureComforts:Diet()
		CreatureComforts:Scan()
	end

	-------------------------------------------------------------------

	local feedHappy = CreateCheckbox(self, L["Feed when happy"],
		L["Automatically consume food items even if your pet is already happy."])
	feedHappy:SetPoint("TOPLEFT", useRaw, "BOTTOMLEFT", 0, -8 - useRaw:GetHeight())
	feedHappy.OnClick = function(self, checked)
		db.feedHappy = checked
		CreatureComforts:Edit()
	end

	-------------------------------------------------------------------

	local warnHungry = CreateCheckbox(self, L["Warn when hungry"],
		L["Print a notice when your pet is less than happy."])
	warnHungry:SetPoint("TOPLEFT", feedHappy, "BOTTOMLEFT", 0, -8 - feedHappy:GetHeight())
	warnHungry.OnClick = function(self, checked)
		db.warnHungry = checked
		CreatureComforts:Edit()
	end

	-------------------------------------------------------------------

	local warnFood = CreateCheckbox(self, L["Warn when out of food"],
		L["Print a notice when you have no food to feed your pet."])
	warnFood:SetPoint("TOPLEFT", warnHungry, "BOTTOMLEFT", 0, -8)
	warnFood.OnClick = function(self, checked)
		db.warnFood = checked
		CreatureComforts:Edit()
	end

	-------------------------------------------------------------------

	local info
	local function AddItem(text, value, func, checked, disabled)
		info = info or { }
		info.text = text
		info.value = value
		info.func = func
		info.checked = checked
		info.disabled = disabled
		UIDropDownMenu_AddButton(info)
	end

	local modifierToString = { ["alt"] = L["Alt"], ["ctrl"] = L["Ctrl"], ["shift"] = L["Shift"] }

	-------------------------------------------------------------------

	local dismissModifier = CreateDropdown(self, L["Dismiss modifier"], nil,
		L["Use this modifier key to dismiss your pet."])
	dismissModifier:SetPoint("TOPLEFT", binding, "BOTTOMLEFT", 0, -8)
	dismissModifier:SetPoint("TOPRIGHT", binding, "BOTTOMRIGHT", 0, -8)
	do
		local function OnClick(self)
			dismissModifier:SetValue(self.value, modifierToString[self.value])
			db.dismissModifier = self.value
			CreatureComforts:Edit()
		end

		UIDropDownMenu_Initialize(dismissModifier.dropdown, function()
			local selected = db.dismissModifier
			local other = db.mendModifier

			AddItem(L["Alt"], "alt", OnClick, "alt" == selected, "alt" == other)
			AddItem(L["Ctrl"], "ctrl", OnClick, "ctrl" == selected, "ctrl" == other)
			AddItem(L["Shift"], "shift", OnClick, "shift" == selected, "shift" == other)
		end)
	end

	-------------------------------------------------------------------

	local mendModifier = CreateDropdown(self, L["Mend/Revive modifier"], nil,
		L["Use this modifier key to mend your pet out of combat, or revive it in combat if it's despawned."])
	mendModifier:SetPoint("TOPLEFT", dismissModifier, "BOTTOMLEFT", 0, -8)
	mendModifier:SetPoint("TOPRIGHT", dismissModifier, "BOTTOMRIGHT", 0, -8)
	do
		local function OnClick(self)
			mendModifier:SetValue(self.value, modifierToString[self.value])
			db.mendModifier = self.value
			CreatureComforts:Edit()
		end

		UIDropDownMenu_Initialize(mendModifier.dropdown, function()
			local selected = db.mendModifier
			local other = db.dismissModifier

			AddItem(L["Alt"], "alt", OnClick, "alt" == selected, "alt" == other)
			AddItem(L["Ctrl"], "ctrl", OnClick, "ctrl" == selected, "ctrl" == other)
			AddItem(L["Shift"], "shift", OnClick, "shift" == selected, "shift" == other)
		end)
	end

	-------------------------------------------------------------------

	local mendThreshold = CreateSlider(self, L["Mend threshold"], 0, 1, 0.05, true,
		L["Mend your pet out of combat by default when its health is below this percent."])
	mendThreshold:SetPoint("TOPLEFT", mendModifier, "BOTTOMLEFT", 0, -8)
	mendThreshold:SetPoint("TOPRIGHT", mendModifier, "BOTTOMRIGHT", 0, -8)
	mendThreshold.OnValueChanged = function(self, value)
		value = math.floor(value * 100 + 0.5) / 100
		db.mendThreshold = value
		CreatureComforts:UNIT_HEALTH("pet")
		return value
	end

	-------------------------------------------------------------------

	local showFood = CreateCheckbox(self, L["Show item icon"],
		L["Show the icon of the food item that will be consumed, instead of the Feed Pet spell icon."])
	showFood:SetPoint("TOPLEFT", mendThreshold, "BOTTOMLEFT", 0, -20)
	showFood.OnClick = function(self, checked)
		db.showFood = checked
		CreatureComforts:BAG_UPDATE()
	end

	-------------------------------------------------------------------

	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
	self:SetScript("OnEvent", function(self, event)
		if event == "PLAYER_REGEN_DISABLED" then
			macro:Disable()
			binding:Disable()
		else
			macro:Enable()
			binding:Enable()
		end
	end)

	-------------------------------------------------------------------

	self.refresh = function()
		if InCombatLockdown() then
			macro:Disable()
			binding:Disable()
		else
			macro:Enable()
			binding:Enable()
		end
		binding:RefreshValue()
		useBonus:SetChecked(db.useBonus)
		useCombo:SetChecked(db.useCombo)
		useConjured:SetChecked(db.useConjured)
		useRaw:SetChecked(db.useRaw)
		feedHappy:SetChecked(db.feedHappy)
		warnHungry:SetChecked(db.warnHungry)
		warnFood:SetChecked(db.warnFood)
		dismissModifier:SetValue(db.dismissModifier, modifierToString[db.dismissModifier])
		mendModifier:SetValue(db.mendModifier, modifierToString[db.mendModifier])
		mendThreshold:SetValue(db.mendThreshold)
		showFood:SetChecked(db.showFood)
	end
end)

optionsPanel.aboutPanel = LibStub("LibAboutPanel").new(optionsPanel.name, ADDON_NAME)

------------------------------------------------------------------------

SLASH_CREATURECOMFORTS1 = "/cc"
SLASH_CREATURECOMFORTS2 = "/creaturecomforts"

SlashCmdList.CREATURECOMFORTS = function()
	InterfaceOptionsFrame_OpenToCategory(optionsPanel.aboutPanel)
	InterfaceOptionsFrame_OpenToCategory(optionsPanel)
end

------------------------------------------------------------------------

local DataBroker = LibStub("LibDataBroker-1.1", true)
if DataBroker then
	DataBroker:NewDataObject("CreatureComforts", {
		type = "launcher",
		icon = "Interface\\Icons\\Ability_Hunter_BeastTraining",
		label = "CreatureComforts",
		OnClick = SlashCmdList.CREATURECOMFORTS,
	})
end

------------------------------------------------------------------------
RIO_ShowOfflineMaster = true;
RIOMain_Browser = {};
RIO_FullGuildList = {};
RIO_totalGuildNumber = 0;
RIO_totalGuildOffset = 0;
RIO_displayRanksMaster = {true, true, true, true, true, true, true, true, true, true};
RIO_SelectedList = {};
RIO_hasLoaded =false;
RIO_UpdateInterval = 1.5;
RIO_UpdateIntervalExtended = 15;
RIO_CodeWordString = "Invite";
RIO_CodeWords = {};

RIO_SendGuildMsg = true;
RIO_NotifyWhenDone = true;
RIO_GuildWhispersOnly = false;
RIO_AlwaysOn = false;

RIO_MinimapPos = 315 -- default position of the minimap icon in degrees
RIO_MinimapShow = true;
RIO_AutoSet25man = true;
RIO_AutoSetDifficulty = false;
RIO_AutoDifficultySetting = 1;
RIO_MasterLooter = false;
RIO_MainFrameScale = 1;
local L = LibStub("AceLocale-3.0"):GetLocale("KeystoneCommander")

local WEEK_IN_SECONDS = 604800
local RESET_NA = 1486479600
local RESET_EU = 1485327600

local version = "1.3.3"

local currentDate
local playerName = UnitName("player")
local sName, sLink, iRarity, iLevel, iMinLevel, sType, sSubType, iStackCount = GetItemInfo(138019);

local guildName
local newLevel = 0

local scrollFrame
local numButtons = 18
local buttonHeight = 16

local printableLink

local tempDatabase = {}
local onlineCharacters = {}

if not KCPlayerDB then 
	KCPlayerDB = {};
end

local best

local classColors = {
	[L["Death Knight"]] = "|cffC41F3B",
	[L["Demon Hunter"]] = "|cffA330C9",
	[L["Druid"]] = "|cffFF7D0A",
	[L["Hunter"]] = "|cffABD473",
	[L["Mage"]] = "|cff69CCF0",
	[L["Monk"]] = "|cff00FF96",
	[L["Paladin"]] = "|cffF58CBA",
	[L["Priest"]] = "|cffffffff",
	[L["Rogue"]] = "|cffFFF569",
	[L["Shaman"]] = "|cff0070DE",
	[L["Warlock"]] = "|cff9482C9",
	[L["Warrior"]] = "|cffC79C6E",
	[L["Offline"]] = "|cff202020"
}

local dungeons = {
	{name = L["Maw"], d = 1},
	{name = L["Black"], d = 2},
	{name = L["Cathedral"], d = 2},
	{name = L["Court"], d = 2},
	{name = L["Darkheart"], d = 2},
	{name = L["Eye"], d = 2},
	{name = L["Lower"], d = 2},
	{name = L["Upper"], d = 2},
	{name = L["Nelth"], d = 2},
	{name = L["Vault"], d = 2},
	{name = L["Halls"], d = 3},
	{name = L["Arcway"], d = 3}
}

KCDB = {
	week = 604800,
	resetTime,
	checkOffline = false,
	checkChat = false,
	sortOption = "name"
}

local f = CreateFrame("Frame", nil, UIParent)
f:RegisterEvent("PLAYER_LOGIN")

local function KC_PlayerLogin(self,event)
	if event == "PLAYER_LOGIN" then
		WeeklyReset()
		KC_BG:Hide()
		DEFAULT_CHAT_FRAME:AddMessage("|cff965573"..L["Keystone Commander: "].."|r".. L[" Loaded - v"]..version);  
		sortOptions()
		GetMyKey()
	end
end

local f2 = CreateFrame("Frame", nil, UIParent)
f2:RegisterEvent("CHALLENGE_MODE_COMPLETED")
f2:RegisterEvent("BAG_UPDATE_DELAYED")
f2:RegisterEvent("UNIT_QUEST_LOG_CHANGED")
f2:RegisterEvent("GUILD_ROSTER_UPDATE")

function KC_KeyPickup(self, event)
	KeyCheck()
	if(KCPlayerDB[playerName] == nil) then
	--
	elseif(KCPlayerDB[playerName] ~= nil) then
		--WatchVar("KCPlayerDB")
		--WatchVar("newLevel")
		if((tonumber(KCPlayerDB[playerName].Level)) < (tonumber(newLevel))) then
			GetMyKey()
			if(key2Chat:GetChecked() == true) then
				SendChatMessage(L["Acquired: "]..printableLink, "GUILD", nil)  
			end
		elseif((tonumber(KCPlayerDB[playerName].Level)) >= (tonumber(newLevel))) then
			--
		end
	else
		SendChatMessage(L["Acquired: "]..printableLink, "GUILD", nil)  
	end
end

function WeeklyReset()

	local currentTime = GetServerTime()
	local region = GetCurrentRegion()
	local week = WEEK_IN_SECONDS
	local resetNA = RESET_NA
	local resetEU = RESET_NA
	local resetTime

	if (region == 1) then
		resetTime = resetNA
	elseif (region == 3) then
		resetTime = resetEU
	else
		resetTime = resetNA
	end
	
	if (KCDB.resetTime ~= nil) then
		resetTime = KCDB.resetTime
		if (resetTime < currentTime) then
			repeat
				resetTime = resetTime + week
			until(resetTime > currentTime)
			print("|cff965573"..L["Keystone Commander: "].."|r"..L["Weekly Server Reset - Resetting Keystone Commander Database!"])   
			KCPlayerDB = {}
		end
	else
		if (resetTime < currentTime) then
			repeat
				resetTime = resetTime + week
			until(resetTime > currentTime)
			print("|cff965573"..L["Keystone Commander: "].."|r"..L["Weekly Server Reset - Resetting Keystone Commander Database!"])  
			KCPlayerDB = {}
		end
	end
	KCDB.resetTime = resetTime
end

f2:SetScript("OnEvent", function(self,event) 
	if event == "UNIT_QUEST_LOG_CHANGED" then
		WeeklyReset()
	end
	if event == "CHALLENGE_MODE_COMPLETED" or event == "BAG_UPDATE_DELAYED" then
		KC_KeyPickup()
	end
	if event == "GUILD_ROSTER_UPDATE" then
		SendDataBase()
	end
end)

function RecieveKey(self, event, prefix, message, channel, sender)
	success = RegisterAddonMessagePrefix("KeyCom_Key")
	if (event == "CHAT_MSG_ADDON" and prefix == "KeyCom_Key") then
		if (success == true) then
			local senderName = string.match(sender, "%a+")
			if (senderName == playerName or string.find(message, playerName)) then
			else
				local messageCharacter = string.match(message, "%a+")
				local reverseMessage = message:reverse()
				local messageKeyLevel = string.match(reverseMessage, "%d+")
				if(KCPlayerDB[messageCharacter] ~= nil and messageKeyLevel > KCPlayerDB[messageCharacter].Level) then					
					CompareData(KCPlayerDB, messageCharacter, "Time", message)
				elseif(KCPlayerDB[messageCharacter] ~= nil and messageKeyLevel < KCPlayerDB[messageCharacter].Level) then
					--#
				else
					WriteToDataBase(message)
				end
			end
		end
	end
end

local f3 = CreateFrame("Frame", nil, UIParent)
f3:RegisterEvent("CHAT_MSG_ADDON")
f3:SetScript("OnEvent", RecieveKey)

f:SetScript("OnEvent", KC_PlayerLogin)

local btn = CreateFrame("Button", "KC_Button", PVEFrame)
	btn:SetSize(122,54)
	btn:SetNormalTexture("Interface\\Addons\\KeystoneCommander\\Images\\button")
	btn:SetPushedTexture("Interface\\Addons\\KeystoneCommander\\Images\\button_pressed")
	btn:SetHighlightTexture("Interface\\Addons\\KeystoneCommander\\Images\\button_highlight")
	btn:SetFrameStrata("LOW")
	btn:SetPoint("BOTTOMRIGHT", PVEFrame, -20, -30)   
	-- btn:SetScript("OnEnter", function(self)
	-- 	GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
	-- 	GameTooltip:ClearLines();
	-- 	GameTooltip:SetText(L["Keystone Commander"],1,1,.10,1,1);   
	-- 	GameTooltip:Show()
	-- end)
	-- btn:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	btn:SetScript("OnClick", function() FrameSwitch() end)

local frameBG = CreateFrame("Frame", "KC_BG", PVEFrame, "BasicFrameTemplate")
	frameBG:RegisterEvent("GUILD_ROSTER_UPDATE")
	frameBG:SetPoint("LEFT", PVEFrame, 565, 0)
	frameBG:SetSize(360,428)
	frameBG:EnableMouse(1)
	frameBG:SetScript("OnShow", function() GetMyKey() end)
	frameBG:SetScript("OnLoad", function() GuildRoster() end)
	frameBG.title = frameBG:CreateFontString("KC_Title", "OVERLAY", "GameFontNormal")
		frameBG.title:SetPoint("TOP", 0, -4)
		frameBG.title:SetText(L["Keystone Commander"])  
	frameBG.guildname = frameBG:CreateFontString("KC_Guild", "OVERLAY", "GameFontNormalHuge")
		frameBG.guildname:SetPoint("TOP", 0, -28)		

local frame = CreateFrame("FRAME", "KC_Frame", KC_BG)
	frame:SetPoint("LEFT", KC_BG, 1, -30)
	frame:SetSize(354, numButtons*buttonHeight+16)
	frame:SetBackdrop( { bgFile="Interface\\FrameGeneral\\UI-Background-Marble", insets={left=4,right=4,top=4,bottom=4}, tileSize=256, tile=true, edgeFile="Interface\\GLUES\\COMMON\\TextPanel-Border", edgeSize = 16 } )
	frame:SetScript("OnShow", function() 
		checkbox:SetChecked(KCDB.checkOffline) 
		key2Chat:SetChecked(KCDB.checkChat)
	end)
	frame:SetScript("OnHide", function() 
		KCDB.checkOffline = checkbox:GetChecked()
		KCDB.checkChat = key2Chat:GetChecked()
	end)

checkbox = CreateFrame("CheckButton", "KC_ShowOffline", KC_Frame, "UICheckButtonTemplate")
	checkbox:ClearAllPoints()
	checkbox:SetPoint("BOTTOMLEFT", 5, -30)
	_G[checkbox:GetName() .. "Text"]:SetText(L["Hide Offline Members"])   
	checkbox:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines(); 
		GameTooltip:SetText(L["Hide all offline members within the key database."],1,1,.10,1,1);    
		GameTooltip:Show()
	end)
	checkbox:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	checkbox:SetScript("OnClick", function()
		if(KCDB.checkOffline ~= nil) then
			if(checkbox:GetChecked()) then
				KCDB.checkOffline = true
			else
				KCDB.checkOffline = false
			end
		end
		--buttonClick(KCDB.sortOption)
		sortOptions()
	end)


key2Chat = CreateFrame("CheckButton", "KC_Key2Chat", KC_BG, "UICheckButtonTemplate")
	key2Chat:ClearAllPoints()
	key2Chat:SetPoint("TOPRIGHT", -4, -46)
	_G[key2Chat:GetName() .. "Text"]:SetText(L["Announce Key Acquired"])   
	_G[key2Chat:GetName() .. "Text"]:SetPoint("LEFT", -124, 0)
	key2Chat:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines(); 
		GameTooltip:SetText(L["Automatically link your key to guild chat on acquisition or upgrade."],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	key2Chat:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	key2Chat:SetScript("OnClick", function()
		if(KCDB.checkChat ~= nil) then
			if(key2Chat:GetChecked()) then
				KCDB.checkChat = true
			else
				KCDB.checkChat = false
			end
		end
		--buttonClick(KCDB.sortOption)
		sortOptions()
	end)


local scrollFrame = CreateFrame("ScrollFrame", "KC_Content", KC_Frame, "FauxScrollFrameTemplate")
	scrollFrame:SetPoint("TOPLEFT", 0, -8)
	scrollFrame:SetPoint("BOTTOMRIGHT", -30, 8)
	scrollFrame:SetScript("OnVerticalScroll",function(self,offset)
		FauxScrollFrame_OnVerticalScroll(self, offset, 16, update) end)

local menuFrame = CreateFrame("Frame", "KC_MenuFrame", UIParent, "UIDropDownMenuTemplate")

local buttonLinkMenu = {
    { text = L["Select a Chat."], isTitle = true},   
    { text = L["Chat Frame"], func = function() print(printableLink); end },   
    { text = L["Say"], func = function() SendChatMessage(printableLink, "SAY", nil); end },   
    { text = L["Party"], colorCode = "|cff6666ff", func = function() SendChatMessage(printableLink, "PARTY", nil); end },   
    { text = L["Guild"], colorCode = "|cff25ff25", func = function() SendChatMessage(printableLink, "GUILD", nil); end },   
    { text = L["Raid"], colorCode = "|cffff4900", func = function() SendChatMessage(printableLink, "RAID", nil); end },   
	{ text = L["     Close Menu"], func = function() menuFrame:Hide() end}   
}

scrollFrame.buttons = {}
for i=1,numButtons do
  	scrollFrame.buttons[i] = CreateFrame("Button","KC_Buttons"..i,frame)
		local kcButton = scrollFrame.buttons[i]
		kcButton:SetSize(346,buttonHeight)
		kcButton:SetNormalFontObject("GameFontHighlightLeft")
		kcButton:SetPoint("TOPLEFT",4,-(i-1)*buttonHeight-8)
		kcButton:SetNormalTexture("Interface\\Addons\\KeystoneCommander\\Images\\stripe_background")
		kcButton:SetHighlightTexture("Interface\\FriendsFrame\\UI-FriendsFrame-HighlightBar")
		kcButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
		kcButton:RegisterForClicks("LeftButtonUp", "RightButtonUp");
			kcButton.nameText = kcButton:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
			kcButton.nameText:SetPoint("LEFT", 6, 0)
			kcButton.nameText:SetText(nil)
			--
			kcButton.keyText = kcButton:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
			kcButton.keyText:SetPoint("LEFT", 94, 0)
			kcButton.keyText:SetText(nil)
			--
			kcButton.levelText = kcButton:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
			kcButton.levelText:SetPoint("LEFT", 268, 0)
			kcButton.levelText:SetText(nil)
			--
			kcButton.bestText = kcButton:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
			kcButton.bestText:SetPoint("LEFT", 312, 0)
			kcButton.bestText:SetText(nil)
end

local keyButton = CreateFrame("Button", "KC_LinkKey", KC_Frame, "UIPanelButtonTemplate")
	keyButton:SetSize(100,22)
	keyButton:SetText(L["Link My Key"])   
	keyButton:SetPoint("BOTTOMRIGHT", -15, -25)
	keyButton:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Link your key to chat channels, or have it put in your chat frame."],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	keyButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	keyButton:SetScript("OnClick", function() EasyMenu(buttonLinkMenu, menuFrame, "cursor", 0 , 0, "MENU") end)

local nameSortButton = CreateFrame("Button", "KC_nameSortButton", KC_Frame, "KCColumnHeaderTemplate")
	nameSortButton:SetSize(94, 19)
	nameSortButton:SetText(L["Name"])   
	nameSortButton:SetPoint("TOP", -128, 18)
	nameSortButton:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Sort by Name"],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	nameSortButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	nameSortButton:SetScript("OnClick", function(self) buttonClick(compareName) end)

local zoneSortButton = CreateFrame("Button", "KC_zoneSortButton", KC_Frame, "KCColumnHeaderTemplate")
	zoneSortButton:SetSize(170, 19)
	zoneSortButton:SetText(L["Dungeon"])   
	zoneSortButton:SetPoint("TOP", 3, 18)
	zoneSortButton:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Sort by Dungeon"],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	zoneSortButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	zoneSortButton:SetScript("OnClick", function(self) buttonClick(compareZone) end)


local levelSortButton = CreateFrame("Button", "KC_levelSortButton", KC_Frame, "KCColumnHeaderTemplate")
	levelSortButton:SetSize(46, 19)
	levelSortButton:SetText(L["Level"])   
	levelSortButton:SetPoint("TOP", 109, 18)
	levelSortButton:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Sort by Key Level"],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	levelSortButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	levelSortButton:SetScript("OnClick", function(self) buttonClick(compareLevel) end)


local bestSortButton = CreateFrame("Button", "KC_bestSortButton", KC_Frame, "KCColumnHeaderTemplate")
	bestSortButton:SetSize(47, 19)
	bestSortButton:SetText(L["Best"])   
	bestSortButton:SetPoint("TOP", 153, 18)
	bestSortButton:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Sort by Highest Completed"],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	bestSortButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)
	bestSortButton:SetScript("OnClick", function(self) buttonClick(compareBest) end)



local nameMenu = {}

local nameFrame = CreateFrame("Frame", "KC_ContextMenu", UIParent, "UIDropDownMenuTemplate")


local refreshButton = CreateFrame("Button", "KC_RefreshButton", KC_BG)
	refreshButton:SetSize(25,25)
	refreshButton:SetPoint("TOPLEFT", 6, -26)
	refreshButton:SetNormalTexture("Interface\\Buttons\\UI-RotationLeft-Button-Up")
	refreshButton:SetPushedTexture("Interface\\Buttons\\UI-RotationLeft-Button-Down")
	refreshButton:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	refreshButton:SetScript("OnClick", function(self) sortOptions() end)
	refreshButton:SetScript("OnEnter", function(self) 
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); 
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Force Refresh Data"],1,1,.10,1,1);    
		GameTooltip:Show() 
	end)
	refreshButton:SetScript("OnLeave", function(self) GameTooltip:Hide() end)

function update()

	IsPlayerInGuild()
	frameBG.guildname:SetText(guildName)

	local charName, zone, level
	local buttonText
	local onlineCharacterKeys = {}	
	
	local n = 1
	for k,v in ipairs(tempDatabase) do
		if(checkbox:GetChecked() == false) or v.online then
			onlineCharacterKeys[n] = k	
			n=n+1
		end
	end
	n = n - 1

  	FauxScrollFrame_Update(scrollFrame,(n),numButtons,buttonHeight)
	for index = 1, numButtons do
		local offset = (index) + FauxScrollFrame_GetOffset(scrollFrame)
		local kcButton = scrollFrame.buttons[index]
		kcButton.index = offset
		if offset<=(n) then
			local tempOffset = tempDatabase[onlineCharacterKeys[offset]]
			local string = tempOffset.class..tempOffset.name.."|r".." - "..tempOffset.zone.." +"..(tempOffset.level or "0")
			kcButton.nameMenu = {
				{text = tempOffset.name, isTitle = true}, 
				{text = L["Whisper"], func = function()    
					ChatFrame1EditBox:Show()
					ChatFrame1EditBox:SetFocus()
					ChatFrame1EditBox:SetText("/w "..tempOffset.name.." ") 
					end},
				{text = L["Invite to Party"], func = function()   
					InviteUnit(tempOffset.name)
					end}, 
				{ text = L["     Close Menu"], func = function() nameFrame:Hide() end}   
			}
			kcButton:SetText(string)
			kcButton:SetScript("OnEnter", function(self) GameTooltip:SetOwner(self, "ANCHOR_CURSOR"); GameTooltip:ClearLines(); GameTooltip:SetHyperlink(tempOffset.key); GameTooltip:Show() end)
			kcButton:SetScript("OnClick", function(...)
				local _, button = ...
				if (button == "RightButton") then
					EasyMenu(kcButton.nameMenu, nameFrame, "cursor", 0 , 0, "MENU")
				else
					ChatFrame1EditBox:Show()
					ChatFrame1EditBox:SetFocus()
					ChatFrame1EditBox:SetText("/w "..tempOffset.name.." ") 
				end;
			end)
			kcButton:Show()
		else
			kcButton:Hide()
		end
	end
end

function rarityColor(text,number)
	if(number <= 3) then
		text:SetText("+"..number)
	elseif (number > 3 and number <= 6) then
		text:SetText("|cff1eff00".."+"..number)
	elseif(number > 6 and number <= 9) then
		text:SetText("|cff0070dd".."+"..number)
	elseif(number > 9 and number <= 14) then
		text:SetText("|cffa335ee".."+"..number)
	else
		text:SetText("|cffff8000".."+"..number)
	end
end

function highlightAP(level)
	if(level <= 3) then
		KC_Single_Highlight:SetPoint("CENTER", 0, 7)
	elseif(level >= 4 and level <= 6) then
		KC_Single_Highlight:SetPoint("CENTER", 0, -4)
	elseif(level >= 7 and level <= 9) then
		KC_Single_Highlight:SetPoint("CENTER", 0, -21)
	elseif(level >= 10) then
		KC_Single_Highlight:SetPoint("CENTER", 0, -34)
	end
end

function highlightGear(level)
	KC_Single_Highlight2:Show()
	if(level == 2) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -146)
	elseif(level == 3) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -160)
	elseif(level == 4) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -174)
	elseif(level == 5) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -188)
	elseif(level == 6) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -202)
	elseif(level == 7) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -216)
	elseif(level == 8) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -230)
	elseif(level == 9) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -244)
	elseif(level >= 10) then
		KC_Single_Highlight2:SetPoint("CENTER", 0, -258)
	end
end

function sortOptions()
	if KCDB.sortOption ~= nil then
		if KCDB.sortOption == "name" then
			buttonClick(compareName)
		elseif KCDB.sortOption == "level" then
			buttonClick(compareLevel)
		elseif KCDB.sortOption == "zone" then
			buttonClick(compareZone)
		elseif KCDB.sortOption == "best" then
			buttonClick(compareBest)
		end
	else
		buttonClick(compareName)
	end
end

function buttonClick(sortType)
	GetWeeklyBestKey()
	GetOnlineCharacters()
	CreateTempDatabase()
	table.sort(tempDatabase, sortType)
	update()
end

function compareLevel(a,b)
	local result = a.level < b.level
		if a.level == b.level then
			result = a.name < b.name
			if a.name == b.name then
				result = a.zone < b.zone
			end
	end
	KCDB.sortOption = "level"
	return result
end

function compareBest(a,b)
	local result = a.dep < b.dep
		if a.dep == b.dep then
			result = a.name < b.name
			if a.name == b.name then
				result = a.zone < b.zone
			end
	end
	KCDB.sortOption = "best"
	return result
end

function compareName(a,b)
	local result = a.name < b.name
	if a.name == b.name then
		result = a.zone < b.zone
		if a.zone == b.zone then
			result = a.level < b.level
		end
	end
	KCDB.sortOption = "name"
	return result
end

function compareZone(a,b)
	local first = a.zone:gsub('%d','')
	local second = b.zone:gsub('%d','')

	local result = first < second
	if first == second then
		result = a.level < b.level
		if a.level == b.level then
			result = a.name < b.name
		end
	end
	KCDB.sortOption = "zone"
	return result
end

function CreateTempDatabase()

	tempDatabase = {}
	local charClass
	local offlineColor = "|cff505050"
	local charOnline

	for charName, value in pairs(KCPlayerDB) do
		local onlineChar = onlineCharacters[charName]
		if(onlineChar ~= nil) then
			local onlineCharClass = onlineChar["Class"]
			local classColor = classColors[onlineCharClass]
			charOnline = true
			charClass = classColor
		else
			charOnline = false
			charClass = offlineColor
		end

		if not value.Best then
			value.Best = "0"
		end	

		local newLevel = tonumber(value.Level)
		local newBest = tonumber(value.Best)

		if newLevel == nil or newLevel == "" then
			newLevel = 1
		end

		if(newBest == 1 or newBest == nil or newBest == "") then
			newBest = 0
		end

		table.insert(tempDatabase, {
			name = value.Name,
			key = value.Key,
			level = newLevel,
			zone = value.Zone,
			dep = newBest,
			class = charClass,
			online = charOnline
		})
	end
end

function GetOnlineCharacters()

	GuildRoster()
	local numTotal, numOnlineMaxLevel, numOnline = GetNumGuildMembers()
	onlineCharacters = {}
	local i = 0
	for g = 1, numOnline do
		local name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName, achievementPoints, achievementRank, isMobile, isSoREligible, standingID = GetGuildRosterInfo(g)
		if online then
			i = 0
			for fullName in string.gmatch(name, "[^-]+") do
				name = fullName
				break
			end
			onlineCharacters[name] = {
				["Name"] = name,
				["Online"] = "true",
				["Class"] = class
			}
		else
		end
	end
end

function KeyCheck()
	inventory = {}
	local temporaryLink

	for i = 0, NUM_BAG_SLOTS do
		for j = 1, GetContainerNumSlots(i) do
			local tempItem = GetContainerItemLink(i,j)
			table.insert(inventory, tempItem)
		end
	end

	for a,tempName in ipairs(inventory) do
		if(string.find(tempName, "Keystone")) then
			temporaryLink = tempName
		else

		end
	end
	
	if temporaryLink  then
		local itemName = (string.match(temporaryLink, "\124h.-\124h"):gsub("%[","%%[)("):gsub("%]",")(%%]"))
		local _,itemid,mlvl,_,_,_,_,_,_,_,_,_,_,_,_,_ = strsplit(":", temporaryLink)
		
		if mlvl == nil or mlvl == "" then
			mlvl = "1"
		end

		newLevel = (tonumber(mlvl))
	end
	return newLevel
end

function GetMyKey()
	inventory = {}
	for i = 0, NUM_BAG_SLOTS do
		for j = 1, GetContainerNumSlots(i) do
			local tempItem = GetContainerItemLink(i,j)
			table.insert(inventory, tempItem)
		end
	end

	for a,tempName in ipairs(inventory) do
		if(string.find(tempName, L["Keystone"])) then
			local myLink = tempName
			ParseMyKey(myLink)
			printableLink = myLink
			return printableLink
		else

		end
	end
end

function SendDataBase()

	GetCurrentTime()
	for i in pairs(KCPlayerDB) do
		if(i ~= playerName) then
			local thisKey = KCPlayerDB[i].Key
			local thisTime = KCPlayerDB[i].Time
			local bestKey = KCPlayerDB[i].Best
			if (KCPlayerDB[i].Best == nil) then
				bestKey = "0"
			end
			if not string.match(thisKey, L["Keystone:"]) then   
				table.removekey(KCPlayerDB, i)
			else
				ParseDataBase(i, thisKey, bestKey)
			end
		end
	end
end

function ParseDataBase(name, key, bestKey)

	local itemName = (string.match(key, "\124h.-\124h"):gsub("%[","%%[)("):gsub("%]",")(%%]"))
	local _,itemid,mlvl,_,_,_,_,_,_,_,_,_,_,_,_,_ = strsplit(":", key)
	local tempDung = (tostring(key))
	local dung = string.gsub(tempDung, L["Keystone: "], "")
	local txt = dung.."-"..mlvl
	local itemColor = select(4,GetItemQualityColor(4))
	local itemLink = key.."-"..txt.."|h|h|r"
	local keyString = (tostring(name.."-"..itemLink.."-"..bestKey))

	SendKey(keyString)
end

function ParseMyKey(key)
	GetWeeklyBestKey()
	-- The commented code only works with wow client 7.2.0+
	-- local itemName = (string.match(key, "\124h.-\124h"):gsub("%[","%%[)("):gsub("%]",")(%%]"))
	-- local _,itemid,mlvl,depl,_,_,_,_,_,_,_,_,_,_,_,_ = strsplit(":", key)
	-- local tempDung = (tostring(key))
	-- local dung = string.gsub(tempDung, L["Keystone: "], "")
	-- local txt = dung.."-"..mlvl
	-- local itemColor = select(4,GetItemQualityColor(4))
	-- local itemLink = key.."-"..txt.."|h|h|r"
	-- local keyString = (tostring(playerName.."-"..itemLink.."-"..best))

	local itemString = string.match(key, "item[%-?%d:]+")

	if not string.match(itemString, "138019") then
		GetMyKey()
	end

	local itemName = string.match(key, "\124h.-\124h"):gsub("%[","%%[)("):gsub("%]",")(%%]")
	local _,itemid,_,_,_,_,_,_,_,_,_,flags,_,_,mapid,mlvl = strsplit(":", itemString)
	local dung = GetRealZoneText(mapid)
	local txt = dung.."-"..mlvl
	local itemColor = select(4,GetItemQualityColor(4))
	local itemLink = key.."-"..txt.."|h|h|r"
	local keyString = (tostring(playerName.."-"..itemLink))

	WriteToDataBase(keyString)
	SendKey(keyString)
end

function FrameSwitch()
   if (KC_BG) then
	   if(  KC_BG:IsVisible() ) then
		  HideUIPanel(KC_BG)
		  KeyCheck()
	   else
	   		ShowUIPanel(KC_BG)
			KeyCheck()
		  --buttonClick(KCDB.sortOption);
		  sortOptions()
	   end
   end
end 

function SendKey(kckey)
	SendAddonMessage("KeyCom_Key", kckey, "GUILD")
end

function WriteToDataBase(arg1)

	GetCurrentTime()

	local dbest
	local string = arg1
	local i = 0
	local words = {}
	for word in string.gmatch(string, "[^-]+") do
		words[i] = word
		i=i+1
	end

	local gname = words[0]
	local gkey = words[1]
	local gzone = words[2]
	local glevel = words[3]
	local gbest = words[4]

	local newLevel = stripchars(words[3], "|hr")

	if newLevel == nil or newLevel == "" then
		newLevel = 1
	end

	KCPlayerDB[gname] = {
	Name = gname,
	Key = gkey,
	Zone = gzone,
	Level = newLevel,
	Best = gbest,
	Time = currentDate
	}

end

function GetCurrentTime()

	local date = date()
	local hour,minute = GetGameTime()

	local j = 0
	local day = {}
	for tod in string.gmatch(date, "[^ ]+") do
		day[j] = tod
		j=j+1
	end

	currentDate = (day[0].."-"..hour..":"..minute)
end

function CompareData(db, key, value, string)

	GetCurrentTime()
	if (db[key][value] <= currentDate) then
		WriteToDataBase(string)
	elseif (db[key][value] > currentDate) then
	else
		WriteToDataBase(string)
	end
end

function table.removekey(table, key)
    local element = table[key]
    table[key] = nil
    return element
end

function table.contains(table, element)
  for _, value in pairs(table) do
    if value == element then
      return true
    end
  end
  return false
end

function stripchars(str, chrs)
  local s = str:gsub("["..chrs.."]", '')
  return s
end

function IsPlayerInGuild()
	local status = true
	if IsInGuild() then
		guildName = GetGuildInfo("player")
		if (guildName == nil) then
			status = false 
		end
	end
	return status
end

function GetWeeklyBestKey()
	C_ChallengeMode.RequestMapInfo()
	C_ChallengeMode.RequestRewards()
	local mapTable = C_ChallengeMode.GetMapTable()
	
	best = 0
	for i, mapId in pairs(mapTable) do
		local _, weeklyBestTime, weeklyBestLevel = C_ChallengeMode.GetMapPlayerStats(mapId)

		if weeklyBestLevel and weeklyBestLevel > best then
			best = weeklyBestLevel
		end
	end
	return best
end
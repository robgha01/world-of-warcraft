local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("KeystoneCommander", "enUS", true)
if not L then return end

-- Chat commands
L["keystonecommander"] = true
L["kc"] = true


L["Keystone Commander: "] = true
L[" Loaded - v"] = true
L["Acquired: "] = true
L["Weekly Server Reset - Resetting Keystone Commander Database!"] = true
L["Keystone Commander"] = true
L["Hide Offline Members"] = true
L["Hide all offline members within the key database."] = true
L["Announce Key Acquired"] = true
L["Automatically link your key to guild chat on acquisition or upgrade."] = true
L["Select a Chat."] = true
L["Chat Frame"] = true
L["Say"] = true
L["Party"] = true
L["Guild"] = true
L["Raid"] = true
L["     Close Menu"] = true
L["Link My Key"] = true
L["Link your key to chat channels, or have it put in your chat frame."] = true
L["Sort Options"] = true
L["Name"] = true
L["Dungeon"] = true
L["Level"] = true
L["Sort keys by Name, Dungeon, or Level."] = true
L["Whisper"] = true
L["Invite to Party"] = true
L["Keystone:"] = true
L["Keystone: "] = true
L["Keystone"] = true

L["Mythic+ Information"] = true
L["AP - Lesser Dungeons: Maw of Souls"] = true
L["AP - Regular Dungeons: Blackrook Hold, Cathedral of Eternal Night, Court of Stars, Darkheart Thicket, Eye of Azshara, Upper and Lower Karazhan, Neltharion's Lair, Vault of the Wardens"] = true
L["AP - Greater Dungeons: The Arcway, Halls of Valor"] = true
L["Base Gear Item Level from end of dungeon chests & class hall weekly chest."] = true
L["Force Refresh Data"] = true
L["Best"] = true
L["Sort by Name"] = true
L["Sort by Dungeon"] = true
L["Sort by Key Level"] = true
L["Sort by Highest Completed"] = true

L["Death Knight"] = true
L["Demon Hunter"] = true
L["Druid"] = true
L["Hunter"] = true
L["Mage"] = true
L["Monk"] = true
L["Paladin"] = true
L["Priest"] = true
L["Rogue"] = true
L["Shaman"] = true
L["Warlock"] = true
L["Warrior"] = true
L["Offline"] = true

L["Maw"] = true
L["Black"] = true
L["Cathedral"] = true
L["Court"] = true
L["Darkheart"] = true
L["Eye"] = true
L["Lower"] = true
L["Upper"] = true
L["Nelth"] = true
L["Vault"] = true
L["Halls"] = true
L["Arcway"] = true
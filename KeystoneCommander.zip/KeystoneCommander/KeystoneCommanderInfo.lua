local L = LibStub("AceLocale-3.0"):GetLocale("KeystoneCommander")
local playerName = UnitName("player")

local AKPercentage = {
	[0] = 1,
	[1] = 1, [2] = 1.5, [3] = 1.9, [4] = 1.4, [5] = 2, [6] = 2.75, [7] = 3.75, [8] = 5, [9] = 6.5, [10] = 8.5,
	[11] = 11, [12] = 14, [13] = 17.75, [14] = 22.5, [15] = 28.5, [16] = 36, [17] = 45.5, [18] = 57, [19] = 72, [20] = 90,
	[21] = 113, [22] = 142, [23] = 178, [24] = 223, [25] = 250, [26] = 1001, [27] = 1301, [28] = 1701, [29] = 2201, [30] = 2901,
	[31] = 3801, [32] = 4901, [33] = 6401, [34] = 8301, [35] = 10801,[36] = 14001, [37] = 18201, [38] = 23701, [39] = 30801, [40] = 40001,
	[41] = 52001, [42] = 67601, [43] = 87901, [44] = 114301, [45] = 148601, [46] = 193201, [47] = 251201, [48] = 326601, [49] = 424601, [50] = 552001
}

local baseGearIlvl = {
	["2"] = { chest = 870, weekly = 875},
	["3"] = { chest = 870, weekly = 880},
	["4"] = { chest = 875, weekly = 885},
	["5"] = { chest = 875, weekly = 890},
	["6"] = { chest = 880, weekly = 890},
	["7"] = { chest = 880, weekly = 895},
	["8"] = { chest = 885, weekly = 895},
	["9"] = { chest = 885, weekly = 900},
	["10"] = { chest = 890, weekly = 905}
}

local baseDungeonAp = {
	["lesser"] = { low = 175, middle = 290, high = 325, cap = 465},
	["regular"] = { low = 300, middle = 475, high = 540, cap = 775},
	["greater"] = { low = 375, middle = 600, high = 675, cap = 1000},
}

function comma_value(amount)
	local formatted = amount
		while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
			if (k==0) then
				break
			end
		end
	return formatted
end

local ApBtn = CreateFrame("Button", "KC_AP_Button", KC_BG)
	ApBtn:SetSize(25,25)
	ApBtn:SetPoint("TOPRIGHT", -6, -26)
	ApBtn:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
	ApBtn:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Down")
	ApBtn:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
	ApBtn:SetScript("OnClick", function(self)
		KC_Info_OnShow()
		if(KC_AP_Frame:IsVisible()) then
			HideUIPanel(KC_AP_Frame)
			SetClampedTextureRotation(self:GetNormalTexture(), 0)
			SetClampedTextureRotation(self:GetPushedTexture(), 0)
		else
			ShowUIPanel(KC_AP_Frame)
			SetClampedTextureRotation(self:GetNormalTexture(), 180)
			SetClampedTextureRotation(self:GetPushedTexture(), 180)
		end
	end)
	ApBtn:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
		GameTooltip:ClearLines();
		GameTooltip:SetText(L["Mythic+ Information"],1,1,.10,1,1);   
		GameTooltip:Show()
		end)
	ApBtn:SetScript("OnLeave", function(self) GameTooltip:Hide() end)

function KC_Info_OnShow()

	local AKPer = (select(2,GetCurrencyInfo(1171)))

	ApFrame = CreateFrame("Frame", "KC_AP_Frame", KC_Frame, "BasicFrameTemplate")
		ApFrame:SetSize(200,540)
		ApFrame:SetPoint("RIGHT", KC_Frame, 207, -26)
		ApFrame:Hide()
			ApFrame.AKTitle = ApFrame:CreateFontString("KC_AK_Title", "OVERLAY", "GameFontNormal")
			ApFrame.AKTitle:SetPoint("TOP", 0, -4)
			ApFrame.AKTitle:SetText("Mythic+ Information")
			ApFrame.AKName = ApFrame:CreateFontString("KC_AK_Name", "OVERLAY", "GameFontNormalLarge")
			ApFrame.AKName:SetPoint("TOP", 0, -35)
			ApFrame.AKName:SetText("|cFFFFFFFF"..playerName)
			ApFrame.AKLevel = ApFrame:CreateFontString("KC_AK", "OVERLAY", "GameFontNormal")
			ApFrame.AKLevel:SetPoint("TOP", 0, -65)		
			ApFrame.AKLevel:SetText("Artifact Knowledge: "..select(2,GetCurrencyInfo(1171)))

	local LesserDungCat = CreateFrame("Frame", "LC_Lesser_Cat", KC_AP_Frame, "CharacterStatFrameCategoryTemplate")
		LesserDungCat:SetPoint("RIGHT", KC_AP_Frame, -2, 160)
			LesserDungCat.Label = LesserDungCat:CreateFontString("KC_L_Lab", "OVERLAY", "GameFontNormal")
			LesserDungCat.Label:SetPoint("CENTER", 0, 2)
			LesserDungCat.Label:SetText("|cFFFFFFFF".."Lesser Dungeons")
		LesserDungCat:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
			GameTooltip:ClearLines();
			GameTooltip:SetText(L["AP - Lesser Dungeons: Maw of Souls"],1,1,.10,1,1);   
			GameTooltip:Show()
			end)
		LesserDungCat:SetScript("OnLeave", function(self) GameTooltip:Hide() end)

		local LesserDung1 = CreateFrame("Frame", "LC_Lesser_1", LC_Lesser_Cat, "CharacterStatFrameTemplate")
			LesserDung1:SetPoint("BOTTOM",-2, -10)
				LesserDung1.Label = LesserDung1:CreateFontString("KC_L_1", "OVERLAY", "GameFontNormalSmall")
				LesserDung1.Label:SetPoint("CENTER", 0, 0)
				LesserDung1.Label:SetText("2-3: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.lesser.low * AKPercentage[AKPer] ))
				LesserDung1.Label2 = LesserDung1:CreateFontString("KC_L_2", "OVERLAY", "GameFontNormalSmall")
				LesserDung1.Label2:SetPoint("CENTER", 0, -13)
				LesserDung1.Label2:SetText("4-6: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.lesser.middle * AKPercentage[AKPer] ))
		local LesserDung2 = CreateFrame("Frame", "LC_Lesser_2", LC_Lesser_Cat, "CharacterStatFrameTemplate")
			LesserDung2:SetPoint("BOTTOM",-2, -38)
				LesserDung2.Label = LesserDung2:CreateFontString("KC_L_3", "OVERLAY", "GameFontNormalSmall")
				LesserDung2.Label:SetPoint("CENTER", 0, 0)
				LesserDung2.Label:SetText("7-9: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.lesser.high * AKPercentage[AKPer] ))
				LesserDung2.Label2 = LesserDung2:CreateFontString("KC_L_4", "OVERLAY", "GameFontNormalSmall")
				LesserDung2.Label2:SetPoint("CENTER", 0, -13)
				LesserDung2.Label2:SetText("10+: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.lesser.cap * AKPercentage[AKPer] ))

	local RegularDungCat = CreateFrame("Frame", "LC_Regular_Cat", KC_AP_Frame, "CharacterStatFrameCategoryTemplate")
		RegularDungCat:SetPoint("RIGHT", KC_AP_Frame, -2, 70)
			RegularDungCat.Label = RegularDungCat:CreateFontString("KC_R_Lab", "OVERLAY", "GameFontNormal")
			RegularDungCat.Label:SetPoint("CENTER", 0, 2)
			RegularDungCat.Label:SetText("|cFFFFFFFF".."Regular Dungeons")

		RegularDungCat:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
			GameTooltip:ClearLines();
			GameTooltip:SetText(L["AP - Regular Dungeons: Blackrook Hold,"..
				" Cathedral of Eternal Night, Court of Stars, Darkheart Thicket,"..
				" Eye of Azshara, Upper and Lower Karazhan,"..
				" Neltharion's Lair, Vault of the Wardens"],1,1,.10,1,1);   
			GameTooltip:Show()
			end)
		RegularDungCat:SetScript("OnLeave", function(self) GameTooltip:Hide() end)

		local RegularDung1 = CreateFrame("Frame", "LC_Regular_1", LC_Regular_Cat, "CharacterStatFrameTemplate")
			RegularDung1:SetPoint("BOTTOM",-2, -10)
				RegularDung1.Label = RegularDung1:CreateFontString("KC_R_1", "OVERLAY", "GameFontNormalSmall")
				RegularDung1.Label:SetPoint("CENTER", 0, 0)
				RegularDung1.Label:SetText("2-3: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.regular.low * AKPercentage[AKPer] ))
				RegularDung1.Label2 = RegularDung1:CreateFontString("KC_R_2", "OVERLAY", "GameFontNormalSmall")
				RegularDung1.Label2:SetPoint("CENTER", 0, -13)
				RegularDung1.Label2:SetText("4-6: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.regular.middle * AKPercentage[AKPer] ))
		local RegularDung2 = CreateFrame("Frame", "LC_Regular_2", LC_Regular_Cat, "CharacterStatFrameTemplate")
			RegularDung2:SetPoint("BOTTOM",-2, -38)
				RegularDung2.Label = RegularDung2:CreateFontString("KC_R_3", "OVERLAY", "GameFontNormalSmall")
				RegularDung2.Label:SetPoint("CENTER", 0, 0)
				RegularDung2.Label:SetText("7-9: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.regular.high * AKPercentage[AKPer] ))
				RegularDung2.Label2 = RegularDung2:CreateFontString("KC_R_4", "OVERLAY", "GameFontNormalSmall")
				RegularDung2.Label2:SetPoint("CENTER", 0, -13)
				RegularDung2.Label2:SetText("10+: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.regular.cap * AKPercentage[AKPer] ))

	local GreaterDungCat = CreateFrame("Frame", "LC_Greater_Cat", KC_AP_Frame, "CharacterStatFrameCategoryTemplate")
		GreaterDungCat:SetPoint("RIGHT", KC_AP_Frame, -2, -20)
			GreaterDungCat.Label = GreaterDungCat:CreateFontString("KC_G_Lab", "OVERLAY", "GameFontNormal")
			GreaterDungCat.Label:SetPoint("CENTER", 0, 2)
			GreaterDungCat.Label:SetText("|cFFFFFFFF".."Greater Dungeons")
		GreaterDungCat:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
			GameTooltip:ClearLines();
			GameTooltip:SetText(L["AP - Greater Dungeons: The Arcway, Halls of Valor"],1,1,.10,1,1);   
			GameTooltip:Show()
			end)
		GreaterDungCat:SetScript("OnLeave", function(self) GameTooltip:Hide() end)

		local GreaterDung1 = CreateFrame("Frame", "LC_Greater_1", LC_Greater_Cat, "CharacterStatFrameTemplate")
			GreaterDung1:SetPoint("BOTTOM",-2, -10)
				GreaterDung1.Label = GreaterDung1:CreateFontString("KC_G_1", "OVERLAY", "GameFontNormalSmall")
				GreaterDung1.Label:SetPoint("CENTER", 0, 0)
				GreaterDung1.Label:SetText("2-3: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.greater.low * AKPercentage[AKPer] ))
				GreaterDung1.Label2 = GreaterDung1:CreateFontString("KC_G_2", "OVERLAY", "GameFontNormalSmall")
				GreaterDung1.Label2:SetPoint("CENTER", 0, -13)
				GreaterDung1.Label2:SetText("4-6: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.greater.middle * AKPercentage[AKPer] ))
		local GreaterDung2 = CreateFrame("Frame", "LC_Greater_2", LC_Greater_Cat, "CharacterStatFrameTemplate")
			GreaterDung2:SetPoint("BOTTOM",-2, -38)
				GreaterDung2.Label = GreaterDung2:CreateFontString("KC_G_3", "OVERLAY", "GameFontNormalSmall")
				GreaterDung2.Label:SetPoint("CENTER", 0, 0)
				GreaterDung2.Label:SetText("7-9: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.greater.high * AKPercentage[AKPer] ))
				GreaterDung2.Label2 = GreaterDung2:CreateFontString("KC_G_4", "OVERLAY", "GameFontNormalSmall")
				GreaterDung2.Label2:SetPoint("CENTER", 0, -13)
				GreaterDung2.Label2:SetText("10+: ".."|cFFFFFFFF"..comma_value(baseDungeonAp.greater.cap * AKPercentage[AKPer] ))

	local GearLevelCat = CreateFrame("Frame", "LC_Gear_Cat", KC_AP_Frame, "CharacterStatFrameCategoryTemplate")
		GearLevelCat:SetPoint("RIGHT", KC_AP_Frame, -2, -110)
			GearLevelCat.Label = GearLevelCat:CreateFontString("KC_Gear_Lab", "OVERLAY", "GameFontNormal")
			GearLevelCat.Label:SetPoint("CENTER", 0, 2)
			GearLevelCat.Label:SetText("|cFFFFFFFF".."Base Item Level")
		GearLevelCat:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_CURSOR");
			GameTooltip:ClearLines();
			GameTooltip:SetText(L["Base Gear Item Level from end of dungeon chests & class hall weekly chest."],1,1,.10,1,1);   
			GameTooltip:Show()
			end)
		GearLevelCat:SetScript("OnLeave", function(self) GameTooltip:Hide() end)

		local GearLevelSub = CreateFrame("Frame", "LC_Gear_1", LC_Gear_Cat, "CharacterStatFrameTemplate")
			GearLevelSub:SetPoint("BOTTOM",-2, -10)
				GearLevelSub.Label = GearLevelSub:CreateFontString("KC_Gear_1", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub.Label:SetPoint("CENTER", 0, 0)
				GearLevelSub.Label:SetText("    Level           Chest(s)    Class Hall")
				GearLevelSub.Label2 = GearLevelSub:CreateFontString("KC_Gear_2", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub.Label2:SetPoint("CENTER", 0, -13)
				GearLevelSub.Label2:SetText("+2:                 ".."|cFFFFFFFF"..baseGearIlvl["2"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["2"].weekly)
		local GearLevelSub2 = CreateFrame("Frame", "LC_Gear_2", LC_Gear_Cat, "CharacterStatFrameTemplate")
			GearLevelSub2:SetPoint("BOTTOM",-2, -38)
				GearLevelSub2.Label = GearLevelSub2:CreateFontString("KC_Gear_3", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub2.Label:SetPoint("CENTER", 0, 0)
				GearLevelSub2.Label:SetText("+3:                 ".."|cFFFFFFFF"..baseGearIlvl["3"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["3"].weekly)
				GearLevelSub2.Label2 = GearLevelSub2:CreateFontString("KC_Gear_4", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub2.Label2:SetPoint("CENTER", 0, -13)
				GearLevelSub2.Label2:SetText("+4:                 ".."|cFFFFFFFF"..baseGearIlvl["4"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["4"].weekly)
		local GearLevelSub3 = CreateFrame("Frame", "LC_Gear_3", LC_Gear_Cat, "CharacterStatFrameTemplate")
			GearLevelSub3:SetPoint("BOTTOM",-2, -66)
				GearLevelSub3.Label = GearLevelSub3:CreateFontString("KC_Gear_5", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub3.Label:SetPoint("CENTER", 0, 0)
				GearLevelSub3.Label:SetText("+5:                 ".."|cFFFFFFFF"..baseGearIlvl["5"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["5"].weekly)
				GearLevelSub3.Label2 = GearLevelSub3:CreateFontString("KC_Gear_6", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub3.Label2:SetPoint("CENTER", 0, -13)
				GearLevelSub3.Label2:SetText("+6:                 ".."|cFFFFFFFF"..baseGearIlvl["6"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["6"].weekly)
		local GearLevelSub4 = CreateFrame("Frame", "LC_Gear_4", LC_Gear_Cat, "CharacterStatFrameTemplate")
			GearLevelSub4:SetPoint("BOTTOM",-2, -94)
				GearLevelSub4.Label = GearLevelSub4:CreateFontString("KC_Gear_7", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub4.Label:SetPoint("CENTER", 0, 0)
				GearLevelSub4.Label:SetText("+7:                 ".."|cFFFFFFFF"..baseGearIlvl["7"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["7"].weekly)
				GearLevelSub4.Label2 = GearLevelSub4:CreateFontString("KC_Gear_8", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub4.Label2:SetPoint("CENTER", 0, -13)
				GearLevelSub4.Label2:SetText("+8:                 ".."|cFFFFFFFF"..baseGearIlvl["8"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["8"].weekly)
		local GearLevelSub5 = CreateFrame("Frame", "LC_Gear_5", LC_Gear_Cat, "CharacterStatFrameTemplate")
			GearLevelSub5:SetPoint("BOTTOM",-2, -122)
				GearLevelSub5.Label = GearLevelSub5:CreateFontString("KC_Gear_9", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub5.Label:SetPoint("CENTER", 0, 0)
				GearLevelSub5.Label:SetText("+9:                 ".."|cFFFFFFFF"..baseGearIlvl["9"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["9"].weekly)
				GearLevelSub5.Label2 = GearLevelSub5:CreateFontString("KC_Gear_10", "OVERLAY", "GameFontNormalSmall")
				GearLevelSub5.Label2:SetPoint("CENTER", 0, -13)
				GearLevelSub5.Label2:SetText("10+:               ".."|cFFFFFFFF"..baseGearIlvl["10"].chest.."             ".."|cFFFFFFFF"..baseGearIlvl["10"].weekly)

		local highlightFrame = CreateFrame("Frame", "KC_Highlight", KC_AP_Frame)
			highlightFrame:SetSize(200,92)
			highlightFrame:SetFrameStrata("TOOLTIP")
			highlightFrame:SetBackdrop( { bgFile="Interface\\BUTTONS\\UI-Listbox-Highlight2"} )
			highlightFrame:SetBackdropColor(1, 1, 0, .05)
			highlightFrame:Hide()

		local singleHighlight = CreateFrame("Frame", "KC_Single_Highlight", KC_Highlight)
			singleHighlight:SetSize(195,12)
			singleHighlight:SetFrameStrata("TOOLTIP")
			singleHighlight:SetBackdrop( { bgFile="Interface\\BUTTONS\\UI-Listbox-Highlight"} )
			singleHighlight:SetBackdropColor(0, 1, 0, .4)

		local singleHighlight2 = CreateFrame("Frame", "KC_Single_Highlight2", KC_AP_Frame)
			singleHighlight2:SetSize(195,12)
			singleHighlight2:SetFrameStrata("TOOLTIP")
			singleHighlight2:SetBackdrop( { bgFile="Interface\\BUTTONS\\UI-Listbox-Highlight"} )
			singleHighlight2:SetBackdropColor(0, 1, 0, .4)
			singleHighlight2:Hide()	

end
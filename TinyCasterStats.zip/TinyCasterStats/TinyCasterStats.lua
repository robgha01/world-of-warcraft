-- TinyCasterStats 2.3 by thevaan
-- Project revision: 89
--
-- TinyCasterStats.lua:
-- File revision: 
-- Last modified: 2017-08-10T15:24:50Z
-- Author: 

local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local AddonName = "TinyCasterStats"
local AceAddon = LibStub("AceAddon-3.0")
local media = LibStub("LibSharedMedia-3.0")
TinyCasterStats = AceAddon:NewAddon(AddonName, "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale(AddonName)
local LGT = LibStub:GetLibrary("LibGroupTalents-1.0");

local ldb = LibStub("LibDataBroker-1.1");
local TCSBroker = ldb:NewDataObject(AddonName, {
	type = "data source",
	label = AddonName,
	icon = "Interface\\Icons\\Ability_Mage_ArcaneBarrage",
	text = "--"
	})

local isInFight = false
local SpecChangedPause = GetTime()

local backdrop = {
	bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
	edgeFile = "",
	tile = false, tileSize = 16, edgeSize = 0,
	insets = { left = 0, right = 0, top = 0, bottom = 0 }
}

local function Debug(...)
	if debug then
		local text = ""
		for i = 1, select("#", ...) do
			if type(select(i, ...)) == "boolean" then
				text = text..(select(i, ...) and "true" or "false").." "
			else
				text = text..(select(i, ...) or "nil").." "
			end
		end
		DEFAULT_CHAT_FRAME:AddMessage("|cFFCCCC99"..AddonName..": |r"..text)
	end
end

TinyCasterStats.fonts = {}

TinyCasterStats.defaults = {
	char = {
		Font = "Vera",
		FontEffect = "none",
		Size = 12,
		FrameLocked = true,
		yPosition = 200,
		xPosition = 200,
		inCombatAlpha = 1,
		outOfCombatAlpha = .3,
		RecordMsg = true,
		RecordSound = false,
		RecordSoundFile = "Fanfare3",
		Spec1 = {
			HighestSpelldmg = 0,
			HighestCrit = "0.00",
			HighestHaste = 0,
			HighestHastePerc = "0.00",
			HighestMP5if = 0,
			HighestMP5 = 0,
			HighestSpirit = 0,
			HighestHit = 0,
			--HighestMastery = "0.00",
			--HighestVersatility = "0.00"
		},
		Spec2 = {
			HighestSpelldmg = 0,
			HighestCrit = "0.00",
			HighestHaste = 0,
			HighestHastePerc = "0.00",
			HighestMP5if = 0,
			HighestMP5 = 0,
			HighestSpirit = 0,
			HighestHit = 0,
			--HighestMastery = "0.00",
			--HighestVersatility = "0.00"
		},
		Style = {
			Spelldmg = true,
			Crit = true,
			Haste = true,
			Spirit = false,
			--Mastery = true,
			HastePerc = false,
			MP5 = false,
			MP5ic = false,
			MP5auto = false,
			--Versatility = false,
			Hit = false,
			showRecords = true,
			vertical = false,
			labels = false,
			LDBtext = true
		},
		Color = {
			sp = {
				r = 1.0,
				g = 0.803921568627451,
				b = 0
			},
			crit = {
				r = 1.0,
				g = 0,
				b = 0.6549019607843137
			},
			haste = {
				r = 0,
				g = 0.611764705882353,
				b = 1.0
			},
			mp5 = {
				r = 1.0,
				g = 1.0,
				b = 1.0
			},
			spirit = {
				r = 1.0,
				g = 1.0,
				b = 1.0
			},
			hit = {
				r = 1.0,
				g = 1.0,
				b = 1.0
			},
			--mastery = {
			--	r = 1.0,
			--	g = 1.0,
			--	b = 1.0
			--},
			--versatility = {
			--	r = 1,
			--	g = 0.72156862745098,
			--	b = 0.0313725490196078
			--}
		},
		DBver = 4
	}
}

TinyCasterStats.tcsframe = CreateFrame("Frame",AddonName.."Frame",UIParent)
TinyCasterStats.tcsframe:SetWidth(100)
TinyCasterStats.tcsframe:SetHeight(15)
TinyCasterStats.tcsframe:SetFrameStrata("BACKGROUND")
TinyCasterStats.tcsframe:EnableMouse(true)
TinyCasterStats.tcsframe:RegisterForDrag("LeftButton")

TinyCasterStats.strings = {
	spString = TinyCasterStats.tcsframe:CreateFontString(),
	critString = TinyCasterStats.tcsframe:CreateFontString(),
	hasteString = TinyCasterStats.tcsframe:CreateFontString(),
	--masteryString = TinyCasterStats.tcsframe:CreateFontString(),
	spiritString = TinyCasterStats.tcsframe:CreateFontString(),
	mp5String = TinyCasterStats.tcsframe:CreateFontString(),
	--versatilityString = TinyCasterStats.tcsframe:CreateFontString(),
	hitString = TinyCasterStats.tcsframe:CreateFontString(),
	
	spRecordString = TinyCasterStats.tcsframe:CreateFontString(),
	critRecordString = TinyCasterStats.tcsframe:CreateFontString(),
	hasteRecordString = TinyCasterStats.tcsframe:CreateFontString(),
	--masteryRecordString = TinyCasterStats.tcsframe:CreateFontString(),
	spiritRecordString = TinyCasterStats.tcsframe:CreateFontString(),
	mp5RecordString = TinyCasterStats.tcsframe:CreateFontString(),
	--versatilityRecordString = TinyCasterStats.tcsframe:CreateFontString()	
	hitRecordString = TinyCasterStats.tcsframe:CreateFontString(),
}

function TinyCasterStats:SetStringColors()
	local c = self.db.char.Color
	self.strings.spString:SetTextColor(c.sp.r, c.sp.g, c.sp.b, 1.0)
	self.strings.critString:SetTextColor(c.crit.r, c.crit.g, c.crit.b, 1.0)
	self.strings.hitString:SetTextColor(c.hit.r, c.hit.g, c.hit.b, 1.0)
	self.strings.hasteString:SetTextColor(c.haste.r, c.haste.g, c.haste.b, 1.0)
	--self.strings.masteryString:SetTextColor(c.mastery.r, c.mastery.g, c.mastery.b, 1.0)
	self.strings.spiritString:SetTextColor(c.spirit.r, c.spirit.g, c.spirit.b, 1.0)
	self.strings.mp5String:SetTextColor(c.mp5.r, c.mp5.g, c.mp5.b, 1.0)
	--self.strings.versatilityString:SetTextColor(c.versatility.r, c.versatility.g, c.versatility.b, 1.0)

	self.strings.spRecordString:SetTextColor(c.sp.r, c.sp.g, c.sp.b, 1.0)
	self.strings.critRecordString:SetTextColor(c.crit.r, c.crit.g, c.crit.b, 1.0)
	self.strings.hitRecordString:SetTextColor(c.hit.r, c.hit.g, c.hit.b, 1.0)
	self.strings.hasteRecordString:SetTextColor(c.haste.r, c.haste.g, c.haste.b, 1.0)
	--self.strings.masteryRecordString:SetTextColor(c.mastery.r, c.mastery.g, c.mastery.b, 1.0)
	self.strings.spiritRecordString:SetTextColor(c.spirit.r, c.spirit.g, c.spirit.b, 1.0)
	self.strings.mp5RecordString:SetTextColor(c.mp5.r, c.mp5.g, c.mp5.b, 1.0)
	--self.strings.versatilityRecordString:SetTextColor(c.versatility.r, c.versatility.g, c.versatility.b, 1.0)
end

function TinyCasterStats:SetTextAnchors()
	local offsetX, offsetY = 3, 0
	if (not self.db.char.Style.vertical) then
		self.strings.spString:SetPoint("TOPLEFT", self.tcsframe,"TOPLEFT", offsetX, offsetY)
		self.strings.hasteString:SetPoint("TOPLEFT", self.strings.spString, "TOPRIGHT", offsetX, offsetY)
		self.strings.spiritString:SetPoint("TOPLEFT", self.strings.hasteString, "TOPRIGHT", offsetX, offsetY)
		self.strings.mp5String:SetPoint("TOPLEFT", self.strings.spiritString, "TOPRIGHT", offsetX, offsetY)
		self.strings.critString:SetPoint("TOPLEFT", self.strings.mp5String, "TOPRIGHT", offsetX, offsetY)
		self.strings.hitString:SetPoint("TOPLEFT", self.strings.critString, "TOPRIGHT", offsetX, offsetY)
		--self.strings.masteryString:SetPoint("TOPLEFT", self.strings.critString, "TOPRIGHT", offsetX, offsetY)
		--self.strings.versatilityString:SetPoint("TOPLEFT", self.strings.masteryString, "TOPRIGHT", offsetX, offsetY)

		self.strings.spRecordString:SetPoint("TOPLEFT", self.strings.spString, "BOTTOMLEFT")
		self.strings.hasteRecordString:SetPoint("TOPLEFT", self.strings.spRecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.spiritRecordString:SetPoint("TOPLEFT", self.strings.hasteRecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.mp5RecordString:SetPoint("TOPLEFT", self.strings.spiritRecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.critRecordString:SetPoint("TOPLEFT", self.strings.mp5RecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.hitRecordString:SetPoint("TOPLEFT", self.strings.critRecordString, "TOPRIGHT", offsetX, offsetY)
		--self.strings.masteryRecordString:SetPoint("TOPLEFT", self.strings.critRecordString, "TOPRIGHT", offsetX, offsetY)
		--self.strings.versatilityRecordString:SetPoint("TOPLEFT", self.strings.masteryRecordString, "TOPRIGHT", offsetX, offsetY)
	else
		self.strings.spString:SetPoint("TOPLEFT", self.tcsframe,"TOPLEFT", offsetX, offsetY)
		self.strings.hasteString:SetPoint("TOPLEFT", self.strings.spString, "BOTTOMLEFT")
		self.strings.spiritString:SetPoint("TOPLEFT", self.strings.hasteString, "BOTTOMLEFT")
		self.strings.mp5String:SetPoint("TOPLEFT", self.strings.spiritString, "BOTTOMLEFT")
		self.strings.critString:SetPoint("TOPLEFT", self.strings.mp5String, "BOTTOMLEFT")
		self.strings.hitString:SetPoint("TOPLEFT", self.strings.critString, "BOTTOMLEFT")
		--self.strings.masteryString:SetPoint("TOPLEFT", self.strings.critString, "BOTTOMLEFT")
		--self.strings.versatilityString:SetPoint("TOPLEFT", self.strings.masteryString, "BOTTOMLEFT")

		self.strings.spRecordString:SetPoint("TOPLEFT", self.strings.spString, "TOPRIGHT", offsetX, offsetY)
		self.strings.hasteRecordString:SetPoint("TOPLEFT", self.strings.spRecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.spiritRecordString:SetPoint("TOPLEFT", self.strings.hasteRecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.mp5RecordString:SetPoint("TOPLEFT", self.strings.spiritRecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.critRecordString:SetPoint("TOPLEFT", self.strings.mp5RecordString, "TOPRIGHT", offsetX, offsetY)
		self.strings.hitRecordString:SetPoint("TOPLEFT", self.strings.critRecordString, "TOPRIGHT", offsetX, offsetY)
		--self.strings.masteryRecordString:SetPoint("TOPLEFT", self.strings.masteryString, "TOPRIGHT", offsetX, offsetY)
		--self.strings.versatilityRecordString:SetPoint("TOPLEFT", self.strings.masteryRecordString, "TOPRIGHT", offsetX, offsetY)		
	end
end

function TinyCasterStats:SetDragScript()
	if self.db.char.FrameLocked then
		self.tcsframe:SetMovable(false)
		fixed = "|cffFF0000"..L["Text is fixed. Uncheck Lock Frame in the options to move!"].."|r"
		self.tcsframe:SetScript("OnDragStart", function() DEFAULT_CHAT_FRAME:AddMessage(fixed) end)
		self.tcsframe:SetScript("OnEnter", nil)
		self.tcsframe:SetScript("OnLeave", nil)
	else
		self.tcsframe:SetMovable(true)
		self.tcsframe:SetScript("OnDragStart", function() self.tcsframe:StartMoving() end)
		self.tcsframe:SetScript("OnDragStop", function() self.tcsframe:StopMovingOrSizing() self.db.char.xPosition = self.tcsframe:GetLeft() self.db.char.yPosition = self.tcsframe:GetBottom() end)
		self.tcsframe:SetScript("OnEnter", function() self.tcsframe:SetBackdrop(backdrop) end)
		self.tcsframe:SetScript("OnLeave", function() self.tcsframe:SetBackdrop(nil) end)
	end
end

function TinyCasterStats:SetFrameVisible()

	if self.db.char.FrameHide then
		self.tcsframe:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", -1000, -1000)
	else
		self.tcsframe:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", self.db.char.xPosition, self.db.char.yPosition)
	end

end

function TinyCasterStats:SetBroker()

	if self.db.char.Style.LDBtext then
		TCSBroker.label = ""
	else
		TCSBroker.label = AddonName
	end

end

function TinyCasterStats:InitializeFrame()
	self.tcsframe:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", self.db.char.xPosition, self.db.char.yPosition)
	local font = media:Fetch("font", self.db.char.Font)
	for k, fontObject in pairs(self.strings) do
		fontObject:SetFontObject(GameFontNormal)
		if not fontObject:SetFont(font, self.db.char.Size, self.db.char.FontEffect) then
			fontObject:SetFont("Fonts\\FRIZQT__.TTF", self.db.char.Size, self.db.char.FontEffect)
		end
		fontObject:SetJustifyH("LEFT")
		fontObject:SetJustifyV("MIDDLE")
	end
	self.strings.spString:SetText(" ")
	self.strings.spString:SetHeight(self.strings.spString:GetStringHeight())
	self.strings.spString:SetText("")
	self:SetTextAnchors()
	self:SetStringColors()
	self:SetDragScript()
	self:SetFrameVisible()
	self:SetBroker()
	self:Stats()
end

function TinyCasterStats:OnInitialize()
	local AceConfigReg = LibStub("AceConfigRegistry-3.0")
	local AceConfigDialog = LibStub("AceConfigDialog-3.0")

	self.db = LibStub("AceDB-3.0"):New(AddonName.."DB", TinyCasterStats.defaults, "char")
	LibStub("AceConfig-3.0"):RegisterOptionsTable(AddonName, self:Options(), "tcscmd")
	--self.db:ResetDB()
	media.RegisterCallback(self, "LibSharedMedia_Registered")

	self:RegisterChatCommand("tcs", function() AceConfigDialog:Open(AddonName) end)
	self:RegisterChatCommand(AddonName, function() AceConfigDialog:Open(AddonName) end)
	self.optionsFrame = AceConfigDialog:AddToBlizOptions(AddonName, AddonName)
	self.db:RegisterDefaults(self.defaults)
	local version = GetAddOnMetadata(AddonName,"Version")
	local loaded = L["Open the configuration menu with /tcs or /tinycasterstats"].."|r"
	DEFAULT_CHAT_FRAME:AddMessage("|cffffd700"..AddonName.." |cff00ff00~v"..version.."~|cffffd700: "..loaded)

	TCSBroker.OnClick = function(frame, button)	AceConfigDialog:Open(AddonName)	end
	TCSBroker.OnTooltipShow = function(tt) tt:AddLine(AddonName) end

	TinyCStatsDB = TinyCStatsDB or {}
	self.Globaldb = TinyCStatsDB
end

function TinyCasterStats:OnEnable()
	self:LibSharedMedia_Registered()
	self:InitializeFrame()
	self:RegisterEvent("PLAYER_ENTERING_WORLD", "OnEvent")
	self:RegisterEvent("UNIT_AURA", "OnEvent")
	self:RegisterEvent("UPDATE_SHAPESHIFT_FORM", "OnEvent")
	self:RegisterEvent("UNIT_INVENTORY_CHANGED", "OnEvent")
	self:RegisterEvent("UNIT_LEVEL", "OnEvent")
	self:RegisterEvent("PLAYER_REGEN_ENABLED", "OnEvent")
	self:RegisterEvent("PLAYER_REGEN_DISABLED", "OnEvent")
	self:RegisterEvent("PLAYER_TALENT_UPDATE", "OnEvent")
end

function TinyCasterStats:UseTinyXStats()

	if self.Globaldb.NoXStatsPrint then return end

	local text = {}
	text[1] = "|cFF00ff00You can use TinyXStats, (all in one Stats Addon).|r"
	text[2] = "http://www.curse.com/addons/wow/tinystats"
	text[3] = "|cFF00ff00This will always be updated as the first.|r"
	for i = 1, 3 do
		DEFAULT_CHAT_FRAME:AddMessage("|cFFCCCC99"..AddonName..": |r"..text[i])
	end

end

function TinyCasterStats:LibSharedMedia_Registered()
	media:Register("font", "BaarSophia", [[Interface\Addons\TinyCasterStats\Fonts\BaarSophia.ttf]])
	media:Register("font", "LucidaSD", [[Interface\Addons\TinyCasterStats\Fonts\LucidaSD.ttf]])
	media:Register("font", "Teen", [[Interface\Addons\TinyCasterStats\Fonts\Teen.ttf]])
	media:Register("font", "Vera", [[Interface\Addons\TinyCasterStats\Fonts\Vera.ttf]])
	media:Register("sound", "Fanfare1", [[Interface\Addons\TinyCasterStats\Sound\Fanfare.ogg]])
	media:Register("sound", "Fanfare2", [[Interface\Addons\TinyCasterStats\Sound\Fanfare2.ogg]])
	media:Register("sound", "Fanfare3", [[Interface\Addons\TinyCasterStats\Sound\Fanfare3.ogg]])

	for k, v in pairs(media:List("font")) do
		self.fonts[v] = v
	end
end

local orgSetActiveSpecGroup = SetActiveSpecGroup;
function SetActiveSpecGroup(...)
	SpecChangedPause = GetTime() + 60
	Debug("Set SpecChangedPause")
	return orgSetActiveSpecGroup(...)
end

function TinyCasterStats:OnEvent(event, arg1)
	if ((event == "PLAYER_REGEN_ENABLED") or (event == "PLAYER_ENTERING_WORLD")) then
		self.tcsframe:SetAlpha(self.db.char.outOfCombatAlpha)
		isInFight = false
		--[[local weekday, month, day, year = CalendarGetDate()
		if self.db.char.PostXStatsDay ~= day then
			self.db.char.PostXStatsDay = day
			self:UseTinyXStats()
		end]]--
	end
	if (event == "PLAYER_REGEN_DISABLED") then
		self.tcsframe:SetAlpha(self.db.char.inCombatAlpha)
		isInFight = true
	end
	if (event == "UNIT_AURA" and arg1 == "player") then
		self:ScheduleTimer("Stats", .8)
	end
	if (event ~= "UNIT_AURA") then
		self:Stats()
	end

end

local function HexColor(stat)

	local c = TinyCasterStats.db.char.Color[stat]
	local hexColor = string.format("|cff%2X%2X%2X", 255*c.r, 255*c.g, 255*c.b)
	return hexColor

end

local function GetHaste()
--Localize buff names
	local hasteBuffs = {
		bloodlust = GetSpellInfo(2825),
		heroism = GetSpellInfo(32182),
		wrathOfAir = GetSpellInfo(2895),
		elementalMastery = GetSpellInfo(64701),
		moonkinAura = GetSpellInfo(24907),
		concentrationAura = GetSpellInfo(19746),
		crusaderAura = GetSpellInfo(32223),
		devotionAura = GetSpellInfo(465),
		retributionAura = GetSpellInfo(7294),
		shadowResistanceAura = GetSpellInfo(19876),
		frostResistanceAura = GetSpellInfo(19888),
		fireResistanceAura = GetSpellInfo(19891),
		icyVeins = GetSpellInfo(12472),
		berserking = GetSpellInfo(26297),
		backdraft = GetSpellInfo(54277),
		pushingTheLimit = GetSpellInfo(70753),
		powerInfusion = GetSpellInfo(10060),
		naturesGrace = GetSpellInfo(16886),
		netherwindPresence = GetSpellInfo(44403),
		celestialFocus = GetSpellInfo(16924),
		giftOfTheEarthmother = GetSpellInfo(51183),
		swiftRetribution = GetSpellInfo(53648),
		improvedMoonkinForm = GetSpellInfo(48396),
		judgementsOfThePure = GetSpellInfo(54153)
	}
    local CR = GetCombatRating(CR_HASTE_SPELL)
    local CRB = GetCombatRatingBonus(CR_HASTE_SPELL)
    local FaktorHastePercent = 0

    if (CRB and CRB > 0 and CR and CR > 0) then--  Division by zero fix ?
		FaktorHastePercent = CR/CRB
	end

	local hasteperc = 1 + 0.01 * CRB
	
	if (UnitAura("player", hasteBuffs.bloodlust) or UnitAura("player", hasteBuffs.heroism)) then
		CR = CR * 1.3
		hasteperc = hasteperc * 1.3
	end
	if (UnitAura("player", hasteBuffs.wrathOfAir)) then
		CR = CR * 1.05
		hasteperc = hasteperc * 1.05
	end
	if (UnitAura("player", hasteBuffs.elementalMastery)) then
		CR = CR * 1.15
		hasteperc = hasteperc * 1.05
	end
	if (UnitAura("player", hasteBuffs.icyVeins)) then
		CR = CR * 1.20
		hasteperc = hasteperc * 1.20
	end
	if (UnitAura("player", hasteBuffs.berserking)) then
		CR = CR * 1.20
		hasteperc = hasteperc * 1.20
	end
	if (UnitAura("player", hasteBuffs.backdraft)) then
		CR = CR * 1.30
		hasteperc = hasteperc * 1.30
	end
	if (UnitAura("player", hasteBuffs.pushingTheLimit)) then
		CR = CR * 1.12
		hasteperc = hasteperc * 1.12
	end
	if (UnitAura("player", hasteBuffs.naturesGrace)) then
		CR = CR * 1.20
		hasteperc = hasteperc * 1.20
	end
	local _,_,_,_,_,_,_,_,_,_,spellID = UnitAura("player", hasteBuffs.judgementsOfThePure)
	if (spellID) then
		if (spellID == 54153) then --Rank 5
			CR = CR * 1.15
			hasteperc = hasteperc * 1.15
		elseif (spellID == 54152) then --Rank 4
			CR = CR * 1.12
			hasteperc = hasteperc * 1.12
		elseif (spellID == 53657) then --Rank 3
			CR = CR * 1.09
			hasteperc = hasteperc * 1.09
		elseif (spellID == 53656) then --Rank 2
			CR = CR * 1.06
			hasteperc = hasteperc * 1.06
		elseif (spellID == 53655) then --Rank 1
			CR = CR * 1.03
			hasteperc = hasteperc * 1.03
		end
	end
	
	if (UnitAura("player", hasteBuffs.powerInfusion)
		and not (UnitAura("player", hasteBuffs.bloodlust) or UnitAura("player", hasteBuffs.heroism))) then
		CR = CR * 1.20
		hasteperc = hasteperc * 1.20
	end
	local netherwindPresence = LGT:UnitHasTalent("player", hasteBuffs.netherwindPresence)
	if (netherwindPresence) then
		CR = CR * (1 + netherwindPresence * .02)
		hasteperc = hasteperc * (1 + netherwindPresence * .02)
	end
	local celestialFocus = LGT:UnitHasTalent("player", hasteBuffs.celestialFocus)
	if (celestialFocus) then
		CR = CR * (1 + celestialFocus * .01)
		hasteperc = hasteperc * (1 + celestialFocus * .01)
	end
	local giftOfTheEarthmother = LGT:UnitHasTalent("player", hasteBuffs.giftOfTheEarthmother)
	if (giftOfTheEarthmother) then
		CR = CR * (1 + giftOfTheEarthmother * .02)
		hasteperc = hasteperc * (1 + giftOfTheEarthmother * .02)
	end

	local moonkinPoints
	local _,_,_,_,_,_,_,caster = UnitAura("player", hasteBuffs.moonkinAura)
	if (caster) then
		moonkinPoints = LGT:UnitHasTalent(caster, hasteBuffs.improvedMoonkinForm)
	end
	local oldPoints, pallyPoints = 0, nil
	for i,buff in ipairs({"concentrationAura","crusaderAura","devotionAura","retributionAura",
		"shadowResistanceAura","frostResistanceAura","fireResistanceAura"}) do
		local _,_,_,_,_,_,_,caster = UnitAura("player", hasteBuffs[buff])
		if (caster) then
			if (pallyPoints) then
				oldPoints = pallyPoints
			end
			local newPoints = LGT:UnitHasTalent(caster, hasteBuffs.swiftRetribution)
			if (newPoints and newPoints > oldPoints) then
				pallyPoints = newPoints
			end
		end
	end
	if (pallyPoints or moonkinPoints) then
		if (pallyPoints and moonkinPoints) then
			if (pallyPoints >= moonkinPoints) then
				CR = (CR * (1 + pallyPoints * .01))
				hasteperc = (hasteperc * (1 + pallyPoints * .01))
			else
				CR = (CR * (1 + moonkinPoints * .01))
				hasteperc = (hasteperc * (1 + moonkinPoints * .01))
			end
		elseif (not moonkinPoints and pallyPoints) then
			CR = (CR * (1 + pallyPoints * .01))
			hasteperc = (hasteperc * (1 + pallyPoints * .01))
		elseif (not pallyPoints) then
			CR = (CR * (1 + moonkinPoints * .01))
			hasteperc = (hasteperc * (1 + moonkinPoints * .01))
		end
    end
    
    local haste = hasteperc * FaktorHastePercent
    return string.format("%.0f",haste), string.format("%.2f",hasteperc)
end

local function GetSpellDamage()
	local spelldamage = 0
	for i = 2, 7, 1 do -- Start at 2 to skip physical damage , MAX_SPELL_SCHOOLS
		if (spelldamage < GetSpellBonusDamage(i)) then
			spelldamage = GetSpellBonusDamage(i)
		end
	end
	if (spelldamage < GetSpellBonusHealing()) then
		spelldamage = GetSpellBonusHealing()
	end
	return spelldamage
end

local function GetCrit()
	local critchance = 0
	for i = 2, 7, 1 do
		if (critchance < GetSpellCritChance(i)) then
			critchance = GetSpellCritChance(i)
		end
	end
	return critchance
end

local function GetHit()
	local hitBuffs = { -- 1%/rank unless otherwise noted
		arcaneFocus = GetSpellInfo(12840),
		precision = GetSpellInfo(29440),
		elementalPrecision = GetSpellInfo(30674),
		shadowFocus = GetSpellInfo(15328),
		suppression = GetSpellInfo(18176),
		balanceOfPower = GetSpellInfo(33596), -- 2%/rank
		impFaerieFire = GetSpellInfo(33602),
		faerieFire = GetSpellInfo(770), -- target
		misery = GetSpellInfo(33198) -- target
	}
	local hit = GetCombatRatingBonus(CR_HIT_SPELL)
	local arcaneFocus = LGT:UnitHasTalent("player", hitBuffs.arcaneFocus)
	if (arcaneFocus) then
		hit = hit + arcaneFocus
	end
	local precision = LGT:UnitHasTalent("player", hitBuffs.precision)
	if (precision) then
		hit = hit + precision
	end
	local elementalPrecision = LGT:UnitHasTalent("player", hitBuffs.elementalPrecision)
	if (elementalPrecision) then
		hit = hit + elementalPrecision
	end
	local shadowFocus = LGT:UnitHasTalent("player", hitBuffs.shadowFocus)
	if (shadowFocus) then
		hit = hit + shadowFocus
	end
	local suppression = LGT:UnitHasTalent("player", hitBuffs.suppression)
	if (suppression) then
		hit = hit + suppression
	end
	local balanceOfPower = LGT:UnitHasTalent("player", hitBuffs.balanceOfPower)
	if (balanceOfPower) then
		hit = hit + 2 * balanceOfPower
	end
	
	local impFaerieFirePoints
	local _,_,_,_,_,_,_,caster = UnitAura("target", hitBuffs.faerieFire, nil, "HARMFUL")
	if (caster) then
		impFaerieFirePoints = LGT:UnitHasTalent(caster, hitBuffs.impFaerieFire)
	end
	local miseryPoints
	local _,_,_,_,_,_,_,caster,_,_,spellID = UnitAura("target", hitBuffs.misery, nil, "HARMFUL")
	if (caster) then
		if (spellID == 33198) then --Rank 3
			miseryPoints = 3
		elseif (spellID == 33197) then --Rank 2
			miseryPoints = 2
		elseif (spellID == 33196) then --Rank 1
			miseryPoints = 1
		end
	end
	if (impFaerieFirePoints or miseryPoints) then
		if (impFaerieFirePoints and miseryPoints) then
			if (impFaerieFirePoints >= miseryPoints) then
				hit = hit + impFaerieFirePoints
			else
				hit = hit + miseryPoints
			end
		elseif (not miseryPoints and impFaerieFirePoints) then
			hit = hit + impFaerieFirePoints
		elseif (not impFaerieFirePoints) then
			hit = hit + miseryPoints
		end
	end
	return hit
end

function TinyCasterStats:Stats()
	Debug("Stats()")
	local style = self.db.char.Style
	local spelldmg = GetSpellDamage()
	local crit = string.format("%.2f",GetCrit())
	local haste, hasteperc = GetHaste()
	local hit = GetHit()
	--local mastery = string.format("%.2f", GetMasteryEffect())
	--local versatility = string.format("%.2f",GetCombatRating(29)/130)
	local s, spirit = UnitStat("player", 5)
	local base, casting = GetManaRegen()
	base = floor(base * 5.0)
	casting = floor(casting * 5.0)
	local spec = "Spec"..GetActiveTalentGroup()

	local recordBroken = "|cffFF0000"..L["Record broken!"]..": "
	local recordIsBroken = false

	if SpecChangedPause <= GetTime() then
		if (tonumber(spelldmg) > tonumber(self.db.char[spec].HighestSpelldmg)) then
			self.db.char[spec].HighestSpelldmg = spelldmg
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..STAT_SPELLPOWER..": |c00ffef00"..self.db.char[spec].HighestSpelldmg.."|r")
				recordIsBroken = true
			end
		end
		if (tonumber(crit) > tonumber(self.db.char[spec].HighestCrit)) then
			self.db.char[spec].HighestCrit = crit
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..SPELL_CRIT_CHANCE..": |c00ffef00".. self.db.char[spec].HighestCrit.."%|r")
				recordIsBroken = true
			end
		end
		if ((tonumber(haste) > tonumber(self.db.char[spec].HighestHaste)) or (tonumber(hasteperc) > tonumber(self.db.char[spec].HighestHastePerc))) then
			self.db.char[spec].HighestHaste = haste
			self.db.char[spec].HighestHastePerc = hasteperc
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..SPELL_HASTE..": |c00ffef00"..self.db.char[spec].HighestHaste.."|r")
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..L["Percent Haste"]..": |c00ffef00"..self.db.char[spec].HighestHastePerc.."%|r")
				recordIsBroken = true
			end
		end
		if (hit > tonumber(self.db.char[spec].HighestHit)) then
			self.db.char[spec].HighestHit = hit
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken.."|cffFF0000"..L["Hit Rate"]..": |c00ffef00"..string.format("%.2f", self.db.char[spec].HighestHit).."%|r")
			end
		end
		if (tonumber(spirit) > tonumber(self.db.char[spec].HighestSpirit)) then
			self.db.char[spec].HighestSpirit = spirit
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..ITEM_MOD_SPIRIT_SHORT..": |c00ffef00"..self.db.char[spec].HighestSpirit.."|r")
				recordIsBroken = true
			end
		end
		--if (tonumber(mastery) > tonumber(self.db.char[spec].HighestMastery)) then
		--	self.db.char[spec].HighestMastery = mastery
		--	if (self.db.char.RecordMsg == true) then
		--		DEFAULT_CHAT_FRAME:AddMessage(recordBroken..STAT_MASTERY..": |c00ffef00"..self.db.char[spec].HighestMastery.."%|r")
		--		recordIsBroken = true
		--	end
		--end
		if (tonumber(base) > tonumber(self.db.char[spec].HighestMP5)) then
			self.db.char[spec].HighestMP5 = base
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..ITEM_MOD_MANA_REGENERATION_SHORT.." "..L["out of combat"]..": |c00ffef00"..self.db.char[spec].HighestMP5.."mp5|r")
				recordIsBroken = true
			end
		end
		if (tonumber(casting) > tonumber(self.db.char[spec].HighestMP5if)) then
			self.db.char[spec].HighestMP5if = casting
			if (self.db.char.RecordMsg == true) then
				DEFAULT_CHAT_FRAME:AddMessage(recordBroken..ITEM_MOD_MANA_REGENERATION_SHORT.." "..L["in combat"]..": |c00ffef00"..self.db.char[spec].HighestMP5if.."mp5|r")
				recordIsBroken = true
			end
		end
		--if (tonumber(versatility) > tonumber(self.db.char[spec].HighestVersatility)) then
		--	self.db.char[spec].HighestVersatility = versatility
		--	if (self.db.char.RecordMsg == true) then
		--		DEFAULT_CHAT_FRAME:AddMessage(recordBroken..STAT_VERSATILITY..": |c00ffef00"..self.db.char[spec].HighestVersatility.."%|r")
		--		recordIsBroken = true
		--	end
		--end
	end

	if ((recordIsBroken == true) and (self.db.char.RecordSound == true)) then
		PlaySoundFile(media:Fetch("sound", self.db.char.RecordSoundFile),"Master")
	end

	local ldbString = ""
	local ldbRecord = ""
	local mp5TempString = ""
	local mp5RecordTempString = ""

	if (style.showRecords) then ldbRecord = "|n" end

	if (style.Spelldmg) then
		local spTempString = ""
		local spRecordTempString = ""
		ldbString = ldbString..HexColor("sp")
		if (style.labels) then
			spTempString = spTempString..L["Sp:"].." "
			ldbString = ldbString..L["Sp:"].." "
		end
		spTempString = spTempString..spelldmg
		ldbString = ldbString..spelldmg.." "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("sp")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..L["Sp:"].." "
				end
				spRecordTempString = spRecordTempString.."("..self.db.char[spec].HighestSpelldmg..")"
				ldbRecord = ldbRecord..self.db.char[spec].HighestSpelldmg.." "
			else
				if (style.labels) then
					spRecordTempString = spRecordTempString..L["Sp:"].." "
					ldbRecord = ldbRecord..L["Sp:"].." "
				end
				spRecordTempString = spRecordTempString..self.db.char[spec].HighestSpelldmg
				ldbRecord = ldbRecord..self.db.char[spec].HighestSpelldmg.." "
			end
		end
		self.strings.spString:SetText(spTempString)
		self.strings.spRecordString:SetText(spRecordTempString)
	else
		self.strings.spString:SetText("")
		self.strings.spRecordString:SetText("")
	end
	if (style.Hit) then
		local hitTempString = ""
		local hitRecordTempString = ""
		ldbString = ldbString.."|c00ffef00"
		if (style.labels) then
			hitTempString = hitTempString..L["Hit:"].." "
			ldbString = ldbString..L["Hit:"].." "
		end
		hitTempString = hitTempString..string.format("%.2f", hit).."%"
		ldbString = ldbString..string.format("%.2f", hit).."% "
		if (style.showRecords) then
			ldbRecord = ldbRecord.."|c00ffef00"
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..L["Hit:"].." "
				end
				hitRecordTempString = hitRecordTempString.."("..string.format("%.2f", self.db.char[spec].HighestHit).."%)"
				ldbRecord = ldbRecord..string.format("%.2f", self.db.char[spec].HighestHit).."% "
			else
				if (style.labels) then
					hitRecordTempString = hitRecordTempString..L["Hit:"].." "
					ldbRecord = ldbRecord..L["Hit:"].." "
				end
				hitRecordTempString = hitRecordTempString..string.format("%.2f", self.db.char[spec].HighestHit).."%"
				ldbRecord = ldbRecord..string.format("%.2f", self.db.char[spec].HighestHit).."% "
			end
		end
		self.strings.hitString:SetText(hitTempString)
		self.strings.hitRecordString:SetText(hitRecordTempString)
	else
		self.strings.hitString:SetText("")
		self.strings.hitRecordString:SetText("")
	end
	if (style.Haste) then
		local hasteTempString = ""
		local hasteRecordTempString = ""
		ldbString = ldbString..HexColor("haste")
		if (style.labels) then
			hasteTempString = hasteTempString..SPELL_HASTE_ABBR..": "
			ldbString = ldbString..SPELL_HASTE_ABBR..": "
		end
		hasteTempString = hasteTempString..haste
		ldbString = ldbString..haste.." "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("haste")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..SPELL_HASTE_ABBR..": "
				end
				hasteRecordTempString = hasteRecordTempString.."("..self.db.char[spec].HighestHaste..")"
				ldbRecord = ldbRecord..self.db.char[spec].HighestHaste.." "
			else
				if (style.labels) then
					hasteRecordTempString = hasteRecordTempString..SPELL_HASTE_ABBR..": "
					ldbRecord = ldbRecord..SPELL_HASTE_ABBR..": "
				end
				hasteRecordTempString = hasteRecordTempString..self.db.char[spec].HighestHaste
				ldbRecord = ldbRecord..self.db.char[spec].HighestHaste.." "
			end
		end
		self.strings.hasteString:SetText(hasteTempString)
		self.strings.hasteRecordString:SetText(hasteRecordTempString)
	elseif (not style.HastePerc) then
		self.strings.hasteString:SetText("")
		self.strings.hasteRecordString:SetText("")
	end
	if (style.HastePerc) then
		local hasteTempString = ""
		local hasteRecordTempString = ""
		ldbString = ldbString..HexColor("haste")
		if (style.labels) then
			hasteTempString = hasteTempString..SPELL_HASTE_ABBR..": "
			ldbString = ldbString..SPELL_HASTE_ABBR..": "
		end
		hasteTempString = hasteTempString..hasteperc.."%"
		ldbString = ldbString..hasteperc.."% "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("haste")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..SPELL_HASTE_ABBR..": "
				end
				hasteRecordTempString = hasteRecordTempString.."("..self.db.char[spec].HighestHastePerc.."%)"
				ldbRecord = ldbRecord..self.db.char[spec].HighestHastePerc.."% "
			else
				if (style.labels) then
					hasteRecordTempString = hasteRecordTempString..SPELL_HASTE_ABBR..": "
					ldbRecord = ldbRecord..SPELL_HASTE_ABBR..": "
				end
				hasteRecordTempString = hasteRecordTempString..self.db.char[spec].HighestHastePerc.."%"
				ldbRecord = ldbRecord..self.db.char[spec].HighestHastePerc.."% "
			end
		end
		self.strings.hasteString:SetText(hasteTempString)
		self.strings.hasteRecordString:SetText(hasteRecordTempString)
	elseif (not style.Haste) then
		self.strings.hasteString:SetText("")
		self.strings.hasteRecordString:SetText("")
	end
	if (style.Spirit) then
		local spiritTempString = ""
		local spiritRecordTempString = ""
		ldbString = ldbString..HexColor("spirit")
		if (style.labels) then
			spiritTempString = spiritTempString..L["Spi:"].." "
			ldbString = ldbString..L["Spi:"].." "
		end
		spiritTempString = spiritTempString..spirit
		ldbString = ldbString..spirit.." "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("spirit")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..L["Spi:"]..": "
				end
				spiritRecordTempString = spiritRecordTempString.."("..self.db.char[spec].HighestSpirit..")"
				ldbRecord = ldbRecord..self.db.char[spec].HighestSpirit.." "
			else
				if (style.labels) then
					spiritRecordTempString = spiritRecordTempString..L["Spi:"].." "
					ldbRecord = ldbRecord..L["Spi:"].." "
				end
				spiritRecordTempString = spiritRecordTempString..self.db.char[spec].HighestSpirit
				ldbRecord = ldbRecord..self.db.char[spec].HighestSpirit.." "
			end
		end
		self.strings.spiritString:SetText(spiritTempString)
		self.strings.spiritRecordString:SetText(spiritRecordTempString)
	else
		self.strings.spiritString:SetText("")
		self.strings.spiritRecordString:SetText("")
	end
	if (style.MP5) then
		ldbString = ldbString..HexColor("mp5")
		if (style.labels) then
			mp5TempString = mp5TempString..L["MP5:"].." "
			ldbString = ldbString..L["MP5:"].." "
		end
		mp5TempString = mp5TempString..base.."mp5 "
		ldbString = ldbString..base.."mp5 "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("mp5")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..L["MP5:"].." "
				end
				mp5RecordTempString = mp5RecordTempString.."("..self.db.char[spec].HighestMP5.."mp5)"
				ldbRecord = ldbRecord..self.db.char[spec].HighestMP5.."mp5 "
			else
				if (style.labels) then
					mp5RecordTempString = mp5RecordTempString..L["MP5:"].." "
					ldbRecord = ldbRecord..L["MP5:"].." "
				end
				mp5RecordTempString = mp5RecordTempString..self.db.char[spec].HighestMP5.."mp5 "
				ldbRecord = ldbRecord..self.db.char[spec].HighestMP5.."mp5 "
			end
		end
		self.strings.mp5String:SetText(mp5TempString)
		self.strings.mp5RecordString:SetText(mp5RecordTempString)
	end
	if (style.MP5ic) then
		ldbString = ldbString..HexColor("mp5")
		if (style.labels) then
			mp5TempString = mp5TempString..L["MP5-ic:"].." "
			ldbString = ldbString..L["MP5-ic:"].." "
		end
		mp5TempString = mp5TempString..casting.."mp5 "
		ldbString = ldbString..casting.."mp5 "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("mp5")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..L["MP5-ic:"].." "
				end
				mp5RecordTempString = mp5RecordTempString.."("..self.db.char[spec].HighestMP5if.."mp5)"
				ldbRecord = ldbRecord..self.db.char[spec].HighestMP5if.."mp5 "
			else
				if (style.labels) then
					mp5RecordTempString = mp5RecordTempString..L["MP5-ic:"].." "
					ldbRecord = ldbRecord..L["MP5-ic:"].." "
				end
				mp5RecordTempString = mp5RecordTempString..self.db.char[spec].HighestMP5if.."mp5 "
				ldbRecord = ldbRecord..self.db.char[spec].HighestMP5if.."mp5 "
			end
		end
		self.strings.mp5String:SetText(mp5TempString)
		self.strings.mp5RecordString:SetText(mp5RecordTempString)
	end
	if (style.MP5auto) then
		ldbString = ldbString..HexColor("mp5")
		if (style.labels) then
			mp5TempString = mp5TempString..L["MP5:"].." "
			ldbString = ldbString..L["MP5:"].." "
		end
		if (isInFight) then
			mp5TempString = mp5TempString..casting.."mp5"
			ldbString = ldbString..casting.."mp5 "
		else
			mp5TempString = mp5TempString..base.."mp5"
			ldbString = ldbString..base.."mp5 "
		end
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("mp5")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..L["MP5:"].." "
				end
				if (isInFight) then
					mp5RecordTempString = mp5RecordTempString.."("..self.db.char[spec].HighestMP5if.."mp5)"
					ldbRecord = ldbRecord..self.db.char[spec].HighestMP5if.."mp5"
				else
					mp5RecordTempString = mp5RecordTempString.."("..self.db.char[spec].HighestMP5.."mp5)"
					ldbRecord = ldbRecord..self.db.char[spec].HighestMP5.."mp5"
				end
			else
				if (style.labels) then
					mp5RecordTempString = mp5RecordTempString..L["MP5:"].." "
					ldbRecord = ldbRecord..L["MP5:"].." "
				end
				if (isInFight) then
					mp5RecordTempString = mp5RecordTempString..self.db.char[spec].HighestMP5if.."mp5"
					ldbRecord = ldbRecord..self.db.char[spec].HighestMP5if.."mp5"
				else
					mp5RecordTempString = mp5RecordTempString..self.db.char[spec].HighestMP5.."mp5"
					ldbRecord = ldbRecord..self.db.char[spec].HighestMP5.."mp5"
				end
			end
		end
		self.strings.mp5String:SetText(mp5TempString)
		self.strings.mp5RecordString:SetText(mp5RecordTempString)
	end
	if (not style.MP5 and not style.MP5ic and not style.MP5auto) then
		self.strings.mp5String:SetText("")
		self.strings.mp5RecordString:SetText("")
	end
	if (style.Crit) then
		local critTempString = ""
		local critRecordTempString = ""
		ldbString = ldbString..HexColor("crit")
		if (style.labels) then
			critTempString = critTempString..CRIT_ABBR..": "
			ldbString = ldbString..CRIT_ABBR..": "
		end
		critTempString = critTempString..crit.."%"
		ldbString = ldbString..crit.."% "
		if (style.showRecords) then
			ldbRecord = ldbRecord..HexColor("crit")
			if (style.vertical) then
				if (style.labels) then
					ldbRecord = ldbRecord..CRIT_ABBR..": "
				end
				critRecordTempString = critRecordTempString.."("..self.db.char[spec].HighestCrit.."%)"
				ldbRecord = ldbRecord..self.db.char[spec].HighestCrit.."% "
			else
				if (style.labels) then
					critRecordTempString = critRecordTempString..CRIT_ABBR..": "
					ldbRecord = ldbRecord..CRIT_ABBR..": "
				end
				critRecordTempString = critRecordTempString..self.db.char[spec].HighestCrit.."%"
				ldbRecord = ldbRecord..self.db.char[spec].HighestCrit.."% "
			end
		end
		self.strings.critString:SetText(critTempString)
		self.strings.critRecordString:SetText(critRecordTempString)
	else
		self.strings.critString:SetText("")
		self.strings.critRecordString:SetText("")
	end
	--if (style.Mastery) then
	--	local masteryTempString = ""
	--	local masteryRecordTempString = ""
	--	ldbString = ldbString..HexColor("mastery")
	--	if (style.labels) then
	--		masteryTempString = masteryTempString..L["Mas:"].." "
	--		ldbString = ldbString..L["Mas:"].." "
	--	end
	--	masteryTempString = masteryTempString..mastery.."%"
	--	ldbString = ldbString..mastery.."% "
	--	if (style.showRecords) then
	--		ldbRecord = ldbRecord..HexColor("mastery")
	--		if (style.vertical) then
	--			if (style.labels) then
	--				ldbRecord = ldbRecord..L["Mas:"].." "
	--			end
	--			masteryRecordTempString = masteryRecordTempString.."("..self.db.char[spec].HighestMastery.."%)"
	--			ldbRecord = ldbRecord..self.db.char[spec].HighestMastery.."% "
	--		else
	--			if (style.labels) then
	--				masteryRecordTempString = masteryRecordTempString..L["Mas:"].." "
	--				ldbRecord = ldbRecord..L["Mas:"].." "
	--			end
	--			masteryRecordTempString = masteryRecordTempString..self.db.char[spec].HighestMastery.."%"
	--			ldbRecord = ldbRecord..self.db.char[spec].HighestMastery.."% "
	--		end
	--	end
	--	self.strings.masteryString:SetText(masteryTempString)
	--	self.strings.masteryRecordString:SetText(masteryRecordTempString)
	--else
	--	self.strings.masteryString:SetText("")
	--	self.strings.masteryRecordString:SetText("")
	--end
	--if (style.Versatility) then
	--	local versatilityTempString = ""
	--	local versatilityRecordTempString = ""
	--	ldbString = ldbString..HexColor("versatility")
	--	if (style.labels) then
	--		versatilityTempString = versatilityTempString..L["Vers:"].." "
	--		ldbString = ldbString..L["Vers:"].." "
	--	end
	--	versatilityTempString = versatilityTempString..versatility.."%"
	--	ldbString = ldbString..versatility.."% "
	--	if (style.showRecords) then
	--		ldbRecord = ldbRecord..HexColor("versatility")
	--		if (style.vertical) then
	--			if (style.labels) then
	--				ldbRecord = ldbRecord..L["Vers:"].." "
	--			end
	--			versatilityRecordTempString = versatilityRecordTempString.."("..self.db.char[spec].HighestVersatility.."%)"
	--			ldbRecord = ldbRecord..self.db.char[spec].HighestVersatility.."% "
	--		else
	--			if (style.labels) then
	--				versatilityRecordTempString = versatilityRecordTempString..L["Vers:"].." "
	--				ldbRecord = ldbRecord..L["Vers:"].." "
	--			end
	--			versatilityRecordTempString = versatilityRecordTempString..self.db.char[spec].HighestVersatility.."%"
	--			ldbRecord = ldbRecord..self.db.char[spec].HighestVersatility.."% "
	--		end
	--	end
	--	self.strings.versatilityString:SetText(versatilityTempString)
	--	self.strings.versatilityRecordString:SetText(versatilityRecordTempString)
	--else
	--	self.strings.versatilityString:SetText("")
	--	self.strings.versatilityRecordString:SetText("")
	--end

	if (style.LDBtext) then
		TCSBroker.text = ldbString..ldbRecord.."|r"
	else
		TCSBroker.text = ""
	end
end

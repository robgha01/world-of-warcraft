local L = LibStub("AceLocale-3.0"):NewLocale("TinyCasterStats", "frFR")
if not L then return end

L["(Only rating or percentage display possible!)"] = "(Seul l'affichage de taux ou de pourcentage est possible !)"
L["Alpha of the text"] = "Transparence du texte"
L["Announce records"] = "Annoncer les nouveaux records"
L["automatic"] = "automatique"
L["Automatically selects which mana regeneration to show"] = "S\195\169lectionne automatiquement la r\195\169g\195\169n\195\169ration de mana \195\160 montrer"
--Translation missing 
L["Broker Text"] = "Broker Text"
--Translation missing 
L["Clears your current color settings"] = "Clears your current color settings"
L["Clears your current records"] = "Efface vos records actuels"
L["Crit Chance"] = "Chance de critique"
L["Crit:"] = "Crit:"
L["Display stats vertically"] = "Montrer les stats verticalement"
--Translation missing 
L["Displays stats in the LDB text field."] = "Displays stats in the LDB text field."
L["Font"] = "Police"
L["Font border"] = "Bordure de la police"
L["Font size"] = "Taille de la police"
L["Haste Rating"] = "H\195\162te"
L["Haste:"] = "H\195\162te:"
--Translation missing 
L["Hide Frame"] = "Hide Frame"
--Translation missing 
L["Hide the text frame (to show stats only in the LDB text field)"] = "Hide the text frame (to show stats only in the LDB text field)"
L["Highest"] = "Plus haut"
L["Hit:"] = true
L["Hit Rate"] = "Taux de r\195\169ussite"
L["in combat"] = "En combat"
L["Lock Frame"] = "Verrouillage des frames"
L["Locks the position of the text frame"] = "Verrouiller la position du texte"
L["Mana Regeneration"] = "r\195\169g\195\169n\195\169ration de mana par 5 secondes"
--Translation missing 
L["Mas:"] = "Mas:"
L["MP5:"] = "MP5:"
L["MP5-ic:"] = "MP5-ic:"
L["NONE"] = "Aucun"
L["Open the configuration menu with /tcs or /tinycasterstats"] = "Ouvrir le menu de configuration avec |c00ff00ff/tcs|cffffd700 ou |c00ff00ff/tinycasterstats|r"
L["out of combat"] = "hors combat"
L["OUTLINE"] = "Contour"
L["Percent Haste"] = "Pourcentage de h\195\162te"
--Translation missing 
L["Play sound on record"] = "Play sound on record"
L["Record broken!"] = "Record battu !"
--Translation missing 
L["Reset colors"] = "Reset colors"
L["Reset position"] = "Remise \195\160 z\195\169ro de la position"
L["Reset records"] = "R\195\169initialiser les records"
L["Resets the frame's position"] = "R\195\169initialise la position de la frame"
L["Select which stats to show"] = "S\195\169lectionner les stats \195\160 afficher"
L["Show labels"] = "Montrer les labels"
L["Show records"] = "Montrer les records"
L["show/hide"] = "Afficher / Cacher"
--Translation missing 
L["Sound"] = "Sound"
L["Sp:"] = "SP:"
L["Spellpower"] = "Puissance des sorts"
--Translation missing 
L["Spi:"] = "Spi:"
L["Stats"] = "Stats"
L["Text"] = "Texte"
L["Text Alpha"] = "Transparence du texte"
L["Text is fixed. Uncheck Lock Frame in the options to move!"] = "Le texte est verrouill\195\169. D\195\169cochez l'option correspondante pour le d\195\169placer !"
L["Text settings"] = "Param\195\168tres du texte"
L["THICKOUTLINE"] = "Contour \195\169pais"
L["Whether or not to display a message when a record is broken"] = "Montrer ou ne pas montrer un message quand un record est battu"
--Translation missing 
L["Whether or not to play a sound when a record is broken"] = "Whether or not to play a sound when a record is broken"
L["Whether or not to show labels for each stat"] = "Affiche ou non les labels pour chaque statistiques"
L["Whether or not to show record values"] = "Afficher ou non les records"
L["Whether or not to show stats vertically"] = "Afficher ou non les stats verticalement"


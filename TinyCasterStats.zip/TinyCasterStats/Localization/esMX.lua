local L = LibStub("AceLocale-3.0"):NewLocale("TinyCasterStats", "esMX")
if not L then return end

L["(Only rating or percentage display possible!)"] = "(S\195\179lo n\195\186mero o porcentaje de visualizaci\195\179n posible!)"
L["Alpha of the text"] = "Alfa del texto"
L["Announce records"] = "Mostrar los nuevos registros"
L["automatic"] = "autom\195\161tico"
L["Automatically selects which mana regeneration to show"] = "Selecciona autom\195\161ticamente que la regeneraci\195\179n de man\195\161 para mostrar"
--Translation missing 
L["Broker Text"] = "Broker Text"
--Translation missing 
L["Clears your current color settings"] = "Clears your current color settings"
L["Clears your current records"] = "Borra los registros actuales"
L["Crit Chance"] = "Posibilidad cr\195\173ticas"
--Translation missing 
L["Crit:"] = "Crit:"
--Translation missing 
L["Display stats vertically"] = "Display stats vertically"
--Translation missing 
L["Displays stats in the LDB text field."] = "Displays stats in the LDB text field."
L["Font"] = "Fuente"
L["Font border"] = "Fuente frontera"
L["Font size"] = "Tama\195\177o de la fuente"
L["Haste Rating"] = "\195\173ndice de celeridad"
--Translation missing 
L["Haste:"] = "Haste:"
--Translation missing 
L["Hide Frame"] = "Hide Frame"
--Translation missing 
L["Hide the text frame (to show stats only in the LDB text field)"] = "Hide the text frame (to show stats only in the LDB text field)"
L["Highest"] = "M\195\161s alto"
L["Hit:"] = "Hit:" -- Requires localization
L["Hit Rate"] = "Tasa de aciertos" -- Needs review
L["in combat"] = "en combate"
L["Lock Frame"] = "Bloqueo Frame"
L["Locks the position of the text frame"] = "Bloquea la posici\195\179n del marco de texto"
L["Mana Regeneration"] = "Regeneraci\195\179n de man\195\161"
--Translation missing 
L["Mas:"] = "Mas:"
--Translation missing 
L["MP5:"] = "MP5:"
--Translation missing 
L["MP5-ic:"] = "MP5-ic:"
L["NONE"] = "Ninguno"
L["Open the configuration menu with /tcs or /tinycasterstats"] = "Abra el men\195\186 de configuraci\195\179n con /tcs o /tinycasterstats"
L["out of combat"] = "fuera de combate"
L["OUTLINE"] = "Esquema"
L["Percent Haste"] = "Porcentaje de Prisa"
--Translation missing 
L["Play sound on record"] = "Play sound on record"
L["Record broken!"] = "registro da\195\177ado!"
--Translation missing 
L["Reset colors"] = "Reset colors"
L["Reset position"] = "Perd\195\173 mi posici\195\179n"
L["Reset records"] = "Restablecer los registros"
L["Resets the frame's position"] = "Restablece el marco de la posici\195\179n"
L["Select which stats to show"] = "Seleccione las estad\195\173sticas para mostrar"
--Translation missing 
L["Show labels"] = "Show labels"
--Translation missing 
L["Show records"] = "Show records"
L["show/hide"] = "mostrar/ocultar"
--Translation missing 
L["Sound"] = "Sound"
--Translation missing 
L["Sp:"] = "Sp:"
L["Spellpower"] = "Poder con hechizos"
--Translation missing 
L["Spi:"] = "Spi:"
L["Stats"] = "Estad\195\173sticas"
L["Text"] = "Texto"
L["Text Alpha"] = "Definici\195\179n de textos"
L["Text is fixed. Uncheck Lock Frame in the options to move!"] = "El texto es fijo. Desactive la opci\195\179n de bloqueo en las opciones de moverse!"
L["Text settings"] = "Texto ajustes"
L["THICKOUTLINE"] = "Esquema gruesa"
L["Whether or not to display a message when a record is broken"] = "Si o no para mostrar un mensaje cuando se rompe un r\195\169cord"
--Translation missing 
L["Whether or not to play a sound when a record is broken"] = "Whether or not to play a sound when a record is broken"
--Translation missing 
L["Whether or not to show labels for each stat"] = "Whether or not to show labels for each stat"
--Translation missing 
L["Whether or not to show record values"] = "Whether or not to show record values"
--Translation missing 
L["Whether or not to show stats vertically"] = "Whether or not to show stats vertically"


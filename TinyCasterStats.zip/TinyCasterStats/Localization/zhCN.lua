local L = LibStub("AceLocale-3.0"):NewLocale("TinyCasterStats", "zhCN")
if not L then return end

L["(Only rating or percentage display possible!)"] = "\239\188\136\229\143\170\230\156\137\231\173\137\231\186\167\230\136\150\231\153\190\229\136\134\230\175\148\230\152\190\231\164\186\229\143\175\232\131\189\231\154\132\239\188\129\239\188\137"
L["Alpha of the text"] = "\233\152\191\229\176\148\230\179\149\230\150\135\230\156\172"
L["Announce records"] = "\230\152\190\231\164\186\230\150\176\232\174\176\229\189\149"
L["automatic"] = "\232\135\170\229\138\168"
L["Automatically selects which mana regeneration to show"] = "\232\135\170\229\138\168\233\128\137\230\139\169\230\152\190\231\164\186\231\154\132\230\179\149\229\138\155\229\134\141\231\148\159"
--Translation missing 
L["Broker Text"] = "Broker Text"
--Translation missing 
L["Clears your current color settings"] = "Clears your current color settings"
L["Clears your current records"] = "\230\184\133\233\153\164\230\130\168\231\154\132\229\189\147\229\137\141\232\174\176\229\189\149"
L["Crit Chance"] = "\229\133\179\233\148\174\230\156\186\228\188\154"
--Translation missing 
L["Crit:"] = "Crit:"
--Translation missing 
L["Display stats vertically"] = "Display stats vertically"
--Translation missing 
L["Displays stats in the LDB text field."] = "Displays stats in the LDB text field."
L["Font"] = "\229\173\151\228\189\147"
L["Font border"] = "\229\173\151\228\189\147\232\190\185\231\149\140"
L["Font size"] = "\229\173\151\228\189\147\229\164\167\229\176\143"
L["Haste Rating"] = "\230\128\165\233\128\159\231\173\137\231\186\167"
--Translation missing 
L["Haste:"] = "Haste:"
--Translation missing 
L["Hide Frame"] = "Hide Frame"
--Translation missing 
L["Hide the text frame (to show stats only in the LDB text field)"] = "Hide the text frame (to show stats only in the LDB text field)"
L["Highest"] = "\230\156\128\233\171\152"
L["Hit:"] = "Hit:" -- Requires localization
L["Hit Rate"] = "\229\145\189\228\184\173\231\142\135" -- Needs review
L["in combat"] = "\229\156\168\230\136\152\230\150\151\228\184\173"
L["Lock Frame"] = "\233\148\129\230\158\182"
L["Locks the position of the text frame"] = "\233\148\129\230\150\135\230\156\172\230\161\134\231\154\132\228\189\141\231\189\174"
L["Mana Regeneration"] = "\230\179\149\229\138\155\229\134\141\231\148\159"
--Translation missing 
L["Mas:"] = "Mas:"
--Translation missing 
L["MP5:"] = "MP5:"
--Translation missing 
L["MP5-ic:"] = "MP5-ic:"
L["NONE"] = "\230\151\160"
L["Open the configuration menu with /tcs or /tinycasterstats"] = "\230\137\147\229\188\128\228\184\142/tcs\230\136\150/tinycasterstats\233\133\141\231\189\174\232\143\156\229\141\149"
L["out of combat"] = "\232\132\177\231\166\187\230\136\152\230\150\151"
L["OUTLINE"] = "\230\166\130\232\166\129"
L["Percent Haste"] = "\231\153\190\229\136\134\230\175\148\229\147\136\230\150\175\231\137\185"
--Translation missing 
L["Play sound on record"] = "Play sound on record"
L["Record broken!"] = "\231\160\180\231\186\170\229\189\149\239\188\129"
--Translation missing 
L["Reset colors"] = "Reset colors"
L["Reset position"] = "\229\164\141\228\189\141\228\189\141\231\189\174"
L["Reset records"] = "\229\164\141\228\189\141\232\174\176\229\189\149"
L["Resets the frame's position"] = "\233\135\141\231\189\174\230\161\134\230\158\182\231\154\132\231\171\139\229\156\186"
L["Select which stats to show"] = "\233\128\137\230\139\169\229\147\170\228\186\155\231\187\159\232\174\161\230\152\190\231\164\186"
--Translation missing 
L["Show labels"] = "Show labels"
--Translation missing 
L["Show records"] = "Show records"
L["show/hide"] = "\230\152\190\231\164\186/\233\154\144\232\151\143"
--Translation missing 
L["Sound"] = "Sound"
--Translation missing 
L["Sp:"] = "Sp:"
L["Spellpower"] = "\230\179\149\230\156\175\229\188\186\229\186\166"
--Translation missing 
L["Spi:"] = "Spi:"
L["Stats"] = "\231\187\159\232\174\161"
L["Text"] = "\230\150\135\230\156\172"
L["Text Alpha"] = "\230\150\135\230\156\172\233\152\191\229\176\148\230\179\149"
L["Text is fixed. Uncheck Lock Frame in the options to move!"] = "\230\150\135\230\156\172\230\152\175\229\155\186\229\174\154\231\154\132\227\128\130\229\143\150\230\182\136\233\128\137\228\184\173\233\148\129\229\174\154\231\154\132\232\140\131\229\155\180\229\134\133\239\188\140\233\128\137\230\139\169\231\167\187\229\138\168\239\188\129"
L["Text settings"] = "\230\150\135\229\173\151\232\174\190\231\189\174"
L["THICKOUTLINE"] = "\229\142\154\229\164\167\231\186\178"
L["Whether or not to display a message when a record is broken"] = "\230\152\175\229\144\166\232\166\129\230\152\190\231\164\186\228\184\128\228\184\170\232\174\176\229\189\149\232\162\171\230\137\147\231\160\180\230\151\182\239\188\140\230\182\136\230\129\175"
--Translation missing 
L["Whether or not to play a sound when a record is broken"] = "Whether or not to play a sound when a record is broken"
--Translation missing 
L["Whether or not to show labels for each stat"] = "Whether or not to show labels for each stat"
--Translation missing 
L["Whether or not to show record values"] = "Whether or not to show record values"
--Translation missing 
L["Whether or not to show stats vertically"] = "Whether or not to show stats vertically"


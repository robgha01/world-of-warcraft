﻿local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore", "esMX" )

if not L then return end



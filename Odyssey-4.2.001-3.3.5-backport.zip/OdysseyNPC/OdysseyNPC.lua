﻿--[[	*** OdysseyNPC ***
Written by : Thaoky, EU-Marécages de Zangar
--]]

if not Odyssey then return end

local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

--[[	*** API ***

	addon:GetNPCName(npcID)							returns the NPC name
	addon:GetNPCList()									returns the complete list of NPCs	
	addon:GetNPCLocation(npcID)							returns location information
	addon:GetNPCLocationTable(npcID)						returns a full location table for this npc
	addon:GetNPCListByZone(continentID, zoneID)			returns the list of NPCs in a zone
	addon:NPCIsQuestGiver(npcID)						returns true if this NPC is a quest giver
--]]

local bAnd = bit.band
local bOr = bit.bor
local RShift = bit.rshift
local LShift = bit.lshift

local function TestBit(value, pos)
	-- note: this function works up to bit 51
	local mask = 2 ^ pos		-- 0-based indexing
	return value % (mask + mask) >= mask
end

local function RightShift(value, numBits)
	-- for bits beyond bit 31
	return math.floor(value / 2^numBits)
end

-- ** Constants **

-- NPC Types 
local NPC_CLASS_TRAINER = 1
local NPC_PROFESSION_TRAINER = 2
local NPC_BATTLEMASTER = 3
local NPC_STABLEMASTER = 4
local NPC_FLIGHTMASTER = 5
local NPC_SPIRITHEALER = 6
local NPC_INNKEEPER = 7

function addon:GetNPCName(npcID)
	if npcID then
		return addon.NPCList[npcID]
	end
end

function addon:GetNPCList()
	return addon.NPCList
end

function addon:GetNPCInfo(npcID)
	local attrib = addon.NPCAttrib[npcID]
	if not attrib then return end
	
	local faction = bAnd(attrib, 3)		-- bits 0 & 1, factions to which the npc reacts.
	local isQuestGiver = TestBit(attrib, 33)
	local isVendor = TestBit(attrib, 34)
	local canRepair = TestBit(attrib, 35)
end

function addon:GetNPCLocation(npcID)
	local attrib = addon.NPCAttrib[npcID]
	if not attrib then return end

	local mainCat = bAnd(RShift(attrib, 2), 15)	-- mask 1111
	local subCat = bAnd(RShift(attrib, 6), 63)			-- mask 111111 .. etc
	local x = bAnd(RShift(attrib, 12), 1023) / 10
	local y = bAnd(RShift(attrib, 22), 1023) / 10
	local hasMoreCoords = TestBit(attrib, 32)
	local isDuplicated
	
	if mainCat == 0 and subCat == 0 then
		-- most NPCs are present in only one zone (although they may have multiple coordinates), those which are duplicated have both continent & zone = 0
		isDuplicated = true
	end
	
	--return addon:GetContinentName(continent), addon:GetZoneName(continent, zone), x, y, isDuplicated
	return mainCat, subCat, x, y, hasMoreCoords, isDuplicated
end

function addon:GetNPCLocationTable(npcID, continentID, zoneID)
	-- continentID and zoneID are optional, if specified, only return locations from that zone
	local out = {}

	local continentNPC, zoneNPC, x, y, _, isDuplicated = addon:GetNPCLocation(npcID)
	if continentNPC and not isDuplicated then
		if not continentID or (continentID and continentID == continentNPC and zoneID and zoneID == zoneNPC) then
			table.insert(out, {
				["continentID"] = continentNPC,
				["zoneID"] = zoneNPC,
				["x"] = x,
				["y"] = y,
			})
		end
	end

	local loc = addon.NPCLoc[npcID]
	if loc then 
		for zoneLoc in loc:gmatch("([^-]+)") do	-- zones are separated by a dash '-'
			-- " continent / zone / locationList "
			continentNPC, zoneNPC, locationList = strsplit("/", zoneLoc)
			continentNPC = tonumber(continentNPC)
			zoneNPC = tonumber(zoneNPC)

			if not continentID or (continentID and continentID == continentNPC and zoneID and zoneID == zoneNPC) then
				local xLoc, yLoc
				-- " x , y | x , y | ... "
				for location in locationList:gmatch("([^|]+)") do
					xLoc, yLoc = strsplit(",", location)
					table.insert(out, {
						["continentID"] = continentNPC,
						["zoneID"] = zoneNPC,
						["x"] = (tonumber(xLoc) / 10),
						["y"] = (tonumber(yLoc) / 10),
					})
				end
			end
		end
	end
	
	return out
end

function addon:GetNPCListByZone(continentID, zoneID)
	local out = {}
	local mask = continentID + LShift(zoneID, 4)		-- prepare to compare both values (10 bits) at once.
	local attribMask
	
	for npcID, attrib in pairs(addon.NPCAttrib) do	-- browse all npc attributes
		attribMask = bAnd(RShift(attrib, 2), 1023)	-- mask over 10 bits (continent + zone)
		if attribMask == mask then
			table.insert(out, npcID)
		elseif attribMask == 0 then							-- if npc is present in multiple zones
			-- get the location table for this npc, and save it if is present in this zone
			for _, npc in pairs(addon:GetNPCLocationTable(npcID)) do
				if npc.continentID == continentID and npc.zoneID == zoneID then
					table.insert(out, npcID)
				end
			end
		end
	end
	return out
end

function addon:NPCIsQuestGiver(npcID)
	local attrib = addon.NPCAttrib[npcID]
	if attrib and TestBit(attrib, 33) then
		return true
	end
end

function addon:NPCIsVendor(npcID)
	local attrib = addon.NPCAttrib[npcID]
	if attrib and TestBit(attrib, 34) then
		return true
	end
end

function addon:NPCCanRepair(npcID)
	local attrib = addon.NPCAttrib[npcID]
	if attrib and TestBit(attrib, 35) then
		return true
	end
end

function addon:GetNPCType(npcID)
	local attrib = addon.NPCAttrib[npcID]
	if attrib then
		local NPCType = bAnd(RightShift(attrib, 36), 15)
		local NPCTypeExt = RightShift(attrib, 40)
	
		return NPCType, NPCTypeExt 
	end
end

function addon:NPCIsClassTrainer(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_CLASS_TRAINER then
		return true
	end
end

function addon:NPCIsProfessionTrainer(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_PROFESSION_TRAINER then
		return true
	end
end

function addon:NPCIsBattleMaster(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_BATTLEMASTER then
		return true
	end
end

function addon:NPCIsStableMaster(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_STABLEMASTER then
		return true
	end
end

function addon:NPCIsFlightMaster(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_FLIGHTMASTER then
		return true
	end
end

function addon:NPCIsSpiritHealer(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_SPIRITHEALER then
		return true
	end
end

function addon:NPCIsInnkeeper(npcID)
	local NPCType = addon:GetNPCType(npcID)
	if NPCType and NPCType == NPC_INNKEEPER then
		return true
	end
end


-- ** Class Trainers **
local englishClass = { "MAGE", "WARRIOR", "HUNTER", "ROGUE", "WARLOCK", "DRUID", "SHAMAN", "PALADIN", "PRIEST", "DEATHKNIGHT" }

function addon:GetEnglishClass(index)
	return englishClass[index]
end

function addon:GetEnglishClasses()
	return englishClass
end

local classTrainers = {
	L["Mage Trainer"],
	L["Warrior Trainer"],
	L["Hunter Trainer"],
	L["Rogue Trainer"],
	L["Warlock Trainer"],
	L["Druid Trainer"],
	L["Shaman Trainer"],
	L["Paladin Trainer"],
	L["Priest Trainer"],
	L["Death Knight Trainer"],
}

function addon:GetClassTrainerLabel(index)
	return classTrainers[index]
end

-- ** Profession Trainers **
local professionSpellIDs = {
	2259,		-- Alchemy
	3100,		-- Blacksmithing
	2550,		-- Cooking
	7411,		-- Enchanting
	4036,		-- Engineering
	3273,		-- First Aid
	7733,		-- Fishing
	2366,		-- Herbalism
	45357,	-- Inscription
	25229,	-- Jewelcrafting
	2108,		-- Leatherworking
	2575,		-- Mining
	8613,		-- Skinning
	3908,		-- Tailoring
}

function addon:GetProfessionList()
	return professionSpellIDs
end

function addon:GetTrainerSpellID(index)
	return professionSpellIDs[index]
end

local professionTrainers = {
	L["Alchemy Trainer"],
	L["Blacksmithing Trainer"],
	L["Cooking Trainer"],
	L["Enchanting Trainer"],
	L["Engineering Trainer"],
	L["First Aid Trainer"],
	L["Fishing Trainer"],
	L["Herbalism Trainer"],
	L["Inscription Trainer"],
	L["Jewelcrafting Trainer"],
	L["Leatherworking Trainer"],
	L["Mining Trainer"],
	L["Skinning Trainer"],
	L["Tailoring Trainer"],
}

function addon:GetProfessionTrainerLabel(index)
	return professionTrainers[index]
end

-- ** BattleMasters **
local battleMasters = {
	L["Alterac Valley Battlemaster"],
	L["Arathi Basin Battlemaster"],
	L["Arena Battlemaster"],
	L["Eye Of The Storm Battlemaster"],
	L["Strand of the Ancients Battlemaster"],
	L["Warsong Gulch Battlemaster"],
	L["Isle of Conquest Battlemaster"],
}

function addon:GetBattleMasterList()
	return battleMasters
end

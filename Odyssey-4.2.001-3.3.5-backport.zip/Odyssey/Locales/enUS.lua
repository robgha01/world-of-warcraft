﻿local debug = false
--[===[@debug@
debug = true
--@end-debug@]===]

local L = LibStub("AceLocale-3.0"):NewLocale("Odyssey", "enUS", true, debug)

--Core.lua
L['show'] = true
L["Shows the UI"] = true
L['hide'] = true
L["Hides the UI"] = true
L['toggle'] = true
L["Toggles the UI"] = true

L['showmap'] = true
L["Shows the map"] = true
L['hidemap'] = true
L["Hides the map"] = true

-- Odyssey.lua
L["Left-click to |cFF00FF00open"] = true
L["Right-click to |cFF00FF00drag"] = true
L["Left click to view"] = true
L["Shift+Left click to link"] = true
L["Maps"] = true
L["Database"] = true
L["Realm Summary"] = true
L["Quest Details"] = true
L["Get History"] = true
L["Continent"] = true
L["Modules successfully loaded."] = true
L["This quest is part of a series"] = true
L["Quest name missing"] = true
L["This quest is repeatable"] = true
L["This quest is a daily quest"] = true
L["This quest is a weekly quest"] = true
L["This quest gives no experience"] = true
L["This quest is a 'Go To' quest"] = true
L["This quest is a dungeon quest"] = true
L["This quest is a raid quest"] = true
L["This quest is a PVP quest"] = true
L["Quest Rewards"] = true
L["Quest Choices"] = true
L["RIGHTCLICK_TOMTOM_TRACKING"] = "Right-Click to track with TomTom"
L["Already Completed by"] = true
L["Could be completed by"] = true

-- QuestDatabase.lua
L["%s quests found in %s"] = true
L["(Showing %d-%d)"] = true
L["Both factions"] = true
L["N/A"] = true
L["Known locations"] = true
L["Click to view these locations on a map"] = true
L["Unfinished quests"] = true
L["Finished quests"] = true
L["All quests"] = true
L["Characters"] = true
L["Filters"] = true

L["Classes"] = true
L["Dungeons"] = true
L["Professions"] = true
L["Raid"] = true
L["World Events"] = true


L["ENABLE_ALL_FILTERS"] = "Enable all filters below"
L["DISABLE_ALL_FILTERS"] = "Disable all filters below"
L["SHOW_REPEATABLE"] = "Show repeatable quests"
L["SHOW_DAILY"] = "Show daily quests"
L["SHOW_WEEKLY"] = "Show weekly quests"
L["SHOW_DUNGEON"] = "Show dungeon quests"
L["SHOW_RAID"] = "Show raid quests"
L["SHOW_PVP"] = "Show PVP quests"
L["SHOW_OTHER_CLASSES"] = "Show other classes' quests"
L["SHOW_OTHER_RACES"] = "Show other races' quests"
L["SHOW_PROFESSIONS"] = "Show profession quests"
L["SHOW_STARTED_BY_ITEM"] = "Show quests started by an item"
L["SHOW_NOXP"] = "Show quests that give no XP"
L["SHOW_GOTO"] = "Show 'Go To' quests"
L["LAST_UPDATE"] = "Last Update"

-- QuestDetails.lua
L["Starts"] = true
L["Ends"] = true
L["Description"] = true

-- RealmSummary.lua
L["Quests completed"] = true
L["Last quest history update"] = true
L["%s%d%s leveling quests found"] = true
L["%s%d%s have been completed (%s%s%s)"] = true
L["%s%d%s have %snot%s been completed"] = true
L["Left-Click to view unfinished quests"] = true

-- TabMaps.lua
L["Your class"] = true
L["Other classes"] = true
L["Your professions"] = true
L["Other professions"] = true
L["Economy"] = true
L["Utility"] = true
L["Search Results"] = true

-- TabQuests.lua
L["Side"] = true

-- OdysseyPOI.lua
L["Auctioneer"] = true
L["Ammunition"] = true
L["Banker"] = true
L["Barber"] = true
L["Flight Master"] = true
L["Innkeeper"] = true
L["Mailbox"] = true
L["Reagents"] = true
L["Stable Master"] = true
L["Mage Trainer"] = true
L["Warrior Trainer"] = true
L["Hunter Trainer"] = true
L["Rogue Trainer"] = true
L["Warlock Trainer"] = true
L["Druid Trainer"] = true
L["Shaman Trainer"] = true
L["Paladin Trainer"] = true
L["Priest Trainer"] = true
L["Death Knight Trainer"] = true
L["Alchemy Trainer"] = true
L["Blacksmithing Trainer"] = true
L["Cooking Trainer"] = true
L["Enchanting Trainer"] = true
L["Engineering Trainer"] = true
L["First Aid Trainer"] = true
L["Fishing Trainer"] = true
L["Herbalism Trainer"] = true
L["Inscription Trainer"] = true
L["Jewelcrafting Trainer"] = true
L["Leatherworking Trainer"] = true
L["Mining Trainer"] = true
L["Skinning Trainer"] = true
L["Tailoring Trainer"] = true
L["Alchemy Lab"] = true
L["Altar Of Shadows"] = true
L["Anvil"] = true
L["Forge"] = true
L["Mana Loom"] = true
L["Moonwell"] = true
L["Alterac Valley Battlemaster"] = true
L["Arathi Basin Battlemaster"] = true
L["Arena Battlemaster"] = true
L["Eye Of The Storm Battlemaster"] = true
L["Strand of the Ancients Battlemaster"] = true
L["Warsong Gulch Battlemaster"] = true
L["Isle of Conquest Battlemaster"] = true

-- Search.lua
L["%s results found"] = true
L["Unknown location"] = true

-- ZoneMaps.lua
L["Starts quests"] = true


-- ** Options.lua **
-- General options
L["Move to change the angle of the minimap icon"] = true
L["Minimap Icon Angle"] = true
L["Move to change the radius of the minimap icon"] = true
L["Minimap Icon Radius"] = true
L["Show Minimap Icon"] = true
L["Transparency"] = true
L["Getting support"] = true
L["Memory used"] = true
L["Tooltip"] = true

-- Quest options
L["Show Level Zero Quests"] = true

-- tooltip options
L["TOOLTIP_QUESTSERIES_TEXT"] = "Show quest series information"
L["TOOLTIP_QUESTSERIES_TITLE"] = "Quest Series Information"
L["TOOLTIP_QUESTSERIES_ENABLED"] = "If a quest is part of a series, details about the whole series will be added to the tooltip."
L["TOOLTIP_QUESTSERIES_DISABLED"] = "Nothing will be added to the tooltip"
L["TOOLTIP_QUESTTYPE_TEXT"] = "Show quest type information"
L["TOOLTIP_QUESTTYPE_TITLE"] = "Quest Type Information"
L["TOOLTIP_QUESTTYPE_ENABLED"] = "Adds the quest type (daily, PVP, dungeon, etc..) to the tooltip."
L["TOOLTIP_QUESTTYPE_DISABLED"] = "Nothing will be added to the tooltip"
L["TOOLTIP_QUESTREWARDS_TEXT"] = "Show quest rewards"
L["TOOLTIP_QUESTREWARDS_TITLE"] = "Quest Reward Information"
L["TOOLTIP_QUESTREWARDS_ENABLED"] = "Adds quest rewards to the tooltip."
L["TOOLTIP_QUESTREWARDS_DISABLED"] = "Nothing will be added to the tooltip"
L["TOOLTIP_QUESTCHOICES_TEXT"] = "Show quest choices"
L["TOOLTIP_QUESTCHOICES_TITLE"] = "Quest Choice Information"
L["TOOLTIP_QUESTCHOICES_ENABLED"] = "Adds quest choices to the tooltip."
L["TOOLTIP_QUESTCHOICES_DISABLED"] = "Nothing will be added to the tooltip"
L["TOOLTIP_QUESTCOMPLETEDBY_TEXT"] = "Show quests completed by"
L["TOOLTIP_QUESTCOMPLETEDBY_TITLE"] = "Quest Completed By"
L["TOOLTIP_QUESTCOMPLETEDBY_ENABLED"] = "Shows a list of alts (on the current realm) who have also completed the quest."
L["TOOLTIP_QUESTCOMPLETEDBY_DISABLED"] = "Nothing will be added to the tooltip"

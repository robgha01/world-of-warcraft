﻿--[[	*** Odyssey ***
Written by : Thaoky, EU-Marécages de Zangar
Started on :March 31, 2009
--]]

local addonName = ...
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"
local GREEN		= "|cFF00FF00"
local YELLOW	= "|cFFFFFF00"
local CYAN		= "|cFF1CFAFE"
local ORANGE	= "|cFFFF7F00"
local RED		= "|cFFFF0000"

local function InitLocalization()
	-- tooltips
	OdysseyMinimapButton.tooltip = format("%s\n%s\n%s",	addonName, WHITE..L["Left-click to |cFF00FF00open"], WHITE..L["Right-click to |cFF00FF00drag"] )
	OdysseyFrameQuestDB_Options.tooltip = format("%s:|r %s", WHITE..GAMEOPTIONS_MENU, addonName)
	OdysseyFrameQuestDB_OptionsDataStore.tooltip = format("%s:|r %s", WHITE..GAMEOPTIONS_MENU, "DataStore")
	
	OdysseyFrameTab2:SetText(L["Maps"])
	OdysseyTabQuestsMenuItem1:SetText(L["Database"])
	OdysseyTabQuestsMenuItem2:SetText(L["Realm Summary"])
	OdysseyTabQuestsMenuItem3:SetText(L["Quest Details"])
	
	-- Quest DB
	OdysseyFrameQuestDB_GetHistory:SetText(L["Get History"])
	-- Realm Summary
	OdysseyFrameRealmSummaryText1:SetText(L["Continent"])
end

local function QueryItemInfo(itemID)
	GameTooltip:SetHyperlink("item:"..itemID..":0:0:0:0:0:0:0")	-- this line queries the server for an unknown id
	GameTooltip:ClearLines(); -- don't leave residual info in the tooltip after the server query
end

local function SafeLoadAddOn(name)
	if not IsAddOnLoaded(name) then
		LoadAddOn(name)
	end
end

-- local function OnWorldMapUpdate()
	-- if WorldMapFrame:IsVisible() then
		-- addon:CollectOverlays()
	-- end
-- end

function addon:OnEnable()
	InitLocalization()
	addon:SetupOptions()

	addon:InitZones()
	addon.Tabs.Quests:Init()
	
--	required only when scanning map overlays	
--	addon:RegisterEvent("WORLD_MAP_UPDATE", OnWorldMapUpdate)
	
	OdysseyFrameName:SetText("Odyssey |cFFFFFFFF".. addon.Version .. " by |cFF69CCF0Thaoky")

	if addon:GetOption("ShowMinimap") == 1 then
		addon:MoveMinimapIcon()
		OdysseyMinimapButton:Show();
	else
		OdysseyMinimapButton:Hide();
	end
end

function addon:OnDisable()
end

function addon:ToggleUI()
	if (OdysseyFrame:IsVisible()) then
		OdysseyFrame:Hide();
	else
		OdysseyFrame:Show();
	end
end

function addon:ToggleMap()
	SafeLoadAddOn("OdysseyMap")

	local map = OdysseyMapFrame
	
	if map then
		if map:IsVisible() then
			map:Hide();
		else
			map:Show();
		end
	end
end

local clientAddonsLoaded

function addon:OnShow()

	if not clientAddonsLoaded then
		SafeLoadAddOn("OdysseyNPC")
		SafeLoadAddOn("OdysseyQuests")
		SafeLoadAddOn("OdysseyPOI")
		addon:Print(L["Modules successfully loaded."])
		clientAddonsLoaded = true

		addon.Quests.Database:Init()
		addon.Tabs.Maps:Init()
	end
	
	SetPortraitTexture(OdysseyFramePortrait, "player");
	
	if not addon.Tabs.current then
		addon.Tabs.current = 1
		addon.Tabs.Quests:MenuItem_OnClick("QuestDB")
	end
end

-- *** Utility functions ***
function addon:ShowWidgetTooltip(frame)
	if not frame.tooltip then return end
	
	OdyTooltip:SetOwner(frame, "ANCHOR_LEFT");
	OdyTooltip:ClearLines();
	OdyTooltip:AddLine(frame.tooltip)
	OdyTooltip:Show(); 
end

function addon:SetItemButtonTexture(button, texture, width, height)
	-- wrapper for SetItemButtonTexture from ItemButtonTemplate.lua
	width = width or 36
	height = height or 36

	local itemTexture = _G[button.."IconTexture"]
	
	itemTexture:SetWidth(width);
	itemTexture:SetHeight(height);
	itemTexture:SetAllPoints(_G[button]);
	
	SetItemButtonTexture(_G[button], texture)
end

function addon:TextureToFontstring(name, width, height)
	return format("|T%s:%s:%s|t", name, width, height)
end

function addon:ClearScrollFrame(name, entry, lines, height)
	for i=1, lines do					-- Hides all entries of the scrollframe, and updates it accordingly
		_G[ entry..i ]:Hide()
	end
	FauxScrollFrame_Update( name, lines, lines, height);
end

function addon:UpdateSlider(frame, text, field)
	local name = frame:GetName()
	local value = frame:GetValue()

	_G[name .. "Text"]:SetText(format("%s (%d)", text, value))
	if addon.db and addon.db.global then 
		addon:SetOption(field, value)
		addon:MoveMinimapIcon()
	end
end

function addon:GetSpellIcon(spellID)
	return select(3, GetSpellInfo(spellID))
end

function addon:PlayerKnowsSpell(spellID)
	-- function taken from DagAssist
	
	-- Calling GetSpellInfo with the spellID will always return spell information.
	-- Calling GetSpellInfo with the spell name will only return a value if the player knows the spell
	-- By nesting two calls to GetSpellInfo, we can test if the player knows the spellId
	local value = GetSpellInfo(spellID);
	if value then
		return (GetSpellInfo(value) ~= nil);
	end
end

local QUEST_COMPLETE_ICON = "\124TInterface\\RaidFrame\\ReadyCheck-Ready:14\124t"
local QUEST_NOT_COMPLETED_ICON = "\124TInterface\\RaidFrame\\ReadyCheck-NotReady:14\124t"

function addon:ShowQuestTooltip(frame, questID, character)
	local link = addon:GetQuestLink(questID)
	if not link then return end			-- stop if no valid link
			
	character = character or DataStore:GetCharacter()
	
	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
	OdyTooltip:SetHyperlink(link)
	
	local level
	
	if addon:GetOption("TooltipSeries") == 1 then
		local first, pos, seriesLength = addon:GetSeriesInfo(questID)
		if first then		-- if quest is part of a series ..
			OdyTooltip:AddLine(" ")
			OdyTooltip:AddLine(format("%s (%d/%d)", L["This quest is part of a series"], pos, seriesLength))
			
			local colorInfo, colorID1, colorID2, icon
			local name, completed
			
			for _, id in ipairs(addon:GetQuestSeries(first)) do			-- peruse the series
				completed = DataStore:IsQuestCompletedBy(character, id)
				name = addon:GetQuestName(id) or L["Quest name missing"]
				level = addon:GetQuestLevel(id)
				
				colorInfo = (completed) and "|cFF33CC33" or "|cFF999999"
				icon = (completed) and QUEST_COMPLETE_ICON or QUEST_NOT_COMPLETED_ICON
				colorInfo = (id == questID) and YELLOW or colorInfo		-- display current quest in yellow
				colorID1 = (id == questID) and YELLOW or WHITE		-- display current quest in yellow
				colorID2 = (id == questID) and YELLOW or GREEN		-- display current quest in yellow

				OdyTooltip:AddDoubleLine(format("%s%s\[%d\] %s", colorInfo, icon, level, name), format("%sID: %s", colorID1, colorID2..id))
			end
		end
	end
	
	if addon:GetOption("TooltipQuestType") == 1 then
		local linefeed = "\n"		-- only needed once
		if addon:IsQuestRepeatable(questID) then
			OdyTooltip:AddLine(linefeed..CYAN..L["This quest is repeatable"])
			linefeed = ""
		end
			
		if addon:IsQuestDaily(questID) then
			OdyTooltip:AddLine(linefeed..CYAN..L["This quest is a daily quest"])
			linefeed = ""
		end
		
		if addon:IsQuestWeekly(questID) then
			OdyTooltip:AddLine(linefeed..CYAN..L["This quest is a weekly quest"])
			linefeed = ""
		end
		
		if addon:IsQuestGivingNoXP(questID) then
			OdyTooltip:AddLine(linefeed..ORANGE..L["This quest gives no experience"])
			linefeed = ""
		end
		
		if addon:IsGoToQuest(questID) then
			OdyTooltip:AddLine(linefeed..ORANGE..L["This quest is a 'Go To' quest"])
			linefeed = ""
		end
		
		if addon:IsDungeonQuest(questID) then
			OdyTooltip:AddLine(linefeed..GREEN..L["This quest is a dungeon quest"])
			linefeed = ""
		end
		
		if addon:IsRaidQuest(questID) then
			OdyTooltip:AddLine(linefeed..GREEN..L["This quest is a raid quest"])
			linefeed = ""
		end
		
		if addon:IsPVPQuest(questID) then
			OdyTooltip:AddLine(linefeed..GREEN..L["This quest is a PVP quest"])
			linefeed = ""
		end
	end
	
	if addon:GetOption("TooltipQuestRewards") == 1 then
		local rewards = addon:GetQuestRewards(questID)
		if rewards then
			OdyTooltip:AddLine(" ")
			OdyTooltip:AddLine(format("%s:", L["Quest Rewards"]))
			
			for _, reward in pairs(rewards) do
				local itemID, qty = strsplit(":", reward)
				itemID = tonumber(itemID)
				qty = tonumber(qty)

				local _, link = GetItemInfo(itemID)
				if link then
					local icon = addon:TextureToFontstring(GetItemIcon(itemID), 14, 14)
					OdyTooltip:AddLine(format("%s %s x%d", icon, link, qty or 1))
				else
					QueryItemInfo(itemID)
					OdyTooltip:AddLine("- "..UNKNOWN, 1, 1, 1)
				end
			end
		end
	end
	
	if addon:GetOption("TooltipQuestChoices") == 1 then
		local choices = addon:GetQuestChoices(questID)
		if choices then
			OdyTooltip:AddLine(" ")
			OdyTooltip:AddLine(format("%s:", L["Quest Choices"]))
			
			for _, choice in pairs(choices) do
				local itemID, qty = strsplit(":", choice)
				itemID = tonumber(itemID)
				qty = tonumber(qty)

				local _, link = GetItemInfo(itemID)
				if link then
					local icon = addon:TextureToFontstring(GetItemIcon(itemID), 14, 14)
					OdyTooltip:AddLine(format("%s %s x%d", icon, link, qty or 1))
				else
					QueryItemInfo(itemID)
					OdyTooltip:AddLine("- "..UNKNOWN, 1, 1, 1)
				end
			end
		end
	end
	
	if addon:GetOption("TooltipQuestCompletedBy") == 1 then
		local completed = {}
		local notCompleted = {}
		for _, characterKey in pairs(DataStore:GetCharacters()) do
			if DataStore:IsQuestCompletedBy(characterKey, questID) then
				table.insert(completed, DataStore:GetColoredCharacterName(characterKey))
			else
				table.insert(notCompleted, DataStore:GetColoredCharacterName(characterKey))
			end
		end
		
		if #completed > 0 then
			OdyTooltip:AddLine(" ")
			OdyTooltip:AddLine(format("%s: %s", L["Already Completed by"], table.concat(completed, ", ")), 1, 1, 1, 1)
		end
	
		if #notCompleted > 0 then
			OdyTooltip:AddLine(" ")
			OdyTooltip:AddLine(format("%s: %s", L["Could be completed by"], table.concat(notCompleted, ", ")), 1, 1, 1, 1)
		end
	end
	
	level = addon:GetQuestLevel(questID)	
	OdyTooltip:AddLine(" ")
	OdyTooltip:AddDoubleLine(WHITE .."QuestID: " .. GREEN .. questID, WHITE .. LEVEL .. " " .. GREEN.. level)
	OdyTooltip:AddLine(" ")
	OdyTooltip:AddLine(GREEN..L["Left click to view"])
	OdyTooltip:AddLine(GREEN..L["Shift+Left click to link"])
	OdyTooltip:Show()
end

function addon:LinkQuestToChat(questID)
	local chat = ChatEdit_GetLastActiveWindow()
	if chat:IsShown() then
		local link = addon:GetQuestLink(questID)
		if link then
			chat:Insert(link)
		end
	end
end

local ACTOR_UNKNOWN = 0
local ACTOR_NPC = 1
local ACTOR_OBJECT = 2
local ACTOR_ITEM = 3

function addon:GetActorLocationText(actorType, actorID)
	
	local GetLocation
	if actorType == ACTOR_NPC then
		GetLocation = addon.GetNPCLocation
	elseif actorType == ACTOR_OBJECT then
		GetLocation = addon.GetObjectLocation
	else
		return
	end
	
	local mainCat, subCat, _, _, _, isDuplicated = GetLocation(self, actorID)
	local mainCatName, subCatName
	
	if mainCat and subCat and not isDuplicated then
		mainCatName = addon:GetMainCategoryName(mainCat)
		subCatName = addon:GetSubCategoryName(mainCat, subCat)
	end
	
	return mainCatName, subCatName, isDuplicated
end

function addon:ShowNPCTooltip(frame, id)
	if id == 0 then return end

	if frame.actorType == ACTOR_ITEM then
		GameTooltip:SetOwner(frame, "ANCHOR_LEFT");
		local _, link = GetItemInfo(id)
		if link then
			GameTooltip:SetHyperlink(link);
		else
			QueryItemInfo(id)
		end
		GameTooltip:Show();
		return
	end
	
	local name, GetLocationTable
	
	if frame.actorType == ACTOR_NPC then
		name = addon:GetNPCName(id)
		GetLocationTable = addon.GetNPCLocationTable
		
	elseif frame.actorType == ACTOR_OBJECT then
		name = addon:GetObjectName(id)
		GetLocationTable = addon.GetObjectLocationTable
	end
	if not name then return end

	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
	OdyTooltip:AddLine(name)

	local mainCatName, subCatName, isDuplicated  = addon:GetActorLocationText(frame.actorType, id)
	
	if mainCatName and subCatName then
		OdyTooltip:AddLine(format("%s, %s", subCatName, mainCatName), 1, 1, 1)
	else
		if isDuplicated then
			OdyTooltip:AddLine("Multiple locations", 1, 1, 1)
		else
			OdyTooltip:AddLine(RED .. L["Unknown location"])
			OdyTooltip:Show()
			return
		end
	end
	
	OdyTooltip:AddLine(" ")
	OdyTooltip:AddLine(L["Known locations"] .. ":")
	
	for _, location in pairs(GetLocationTable(self, id)) do
		OdyTooltip:AddLine(format("%s%2.1f %s%2.1f", WHITE.."x:"..CYAN, location.x, WHITE.."y:"..CYAN, location.y), 1, 1, 1)
	end

	OdyTooltip:AddLine(" ")
	OdyTooltip:AddLine(L["Click to view these locations on a map"], 0, 1, 0, 1, 1)
	OdyTooltip:AddLine(L["RIGHTCLICK_TOMTOM_TRACKING"], 0, 1, 0, 1, 1)
	
	OdyTooltip:Show()
end

function addon:AddNPCToTomTom(npcID)
	if not TomTom or not npcID or npcID == 0 then return end
	
	local mainCat, subCat = addon:GetNPCLocation(npcID)
	if not mainCat or mainCat > addon:GetNumContinents() then return end
	
	local locationTable = addon:GetNPCLocationTable(npcID)
	if mainCat and subCat and (#locationTable > 0) then
		local name = addon:GetNPCName(npcID)
		TomTom:AddZWaypoint(mainCat, subCat, locationTable[1].x, locationTable[1].y, name or "")
	end
end

local ICON_FACTION_HORDE = "Interface\\Icons\\INV_BannerPVP_01"
local ICON_FACTION_ALLIANCE = "Interface\\Icons\\INV_BannerPVP_02"

function addon:GetSideIcon(side)
	local allianceIcon = addon:TextureToFontstring(ICON_FACTION_ALLIANCE, 14, 14) .. " "
	local hordeIcon = addon:TextureToFontstring(ICON_FACTION_HORDE, 14, 14) .. " "
	
	if side == 1 then
		return allianceIcon
	elseif side == 2 then
		return hordeIcon
	elseif side == 3 then
		return allianceIcon .. " " ..hordeIcon
	end
end

function addon:CreateButtonBorder(frame)
	if frame.border then return end

	local border = frame:CreateTexture(nil, "OVERLAY")
	border:SetWidth(67);
	border:SetHeight(67)
	border:SetPoint("CENTER", frame)
	border:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
	border:SetBlendMode("ADD")
	border:Hide()
	
	frame.border = border
end

function addon:Item_OnEnter(frame)
	local id = frame:GetID()
	if not id then return end
	
	GameTooltip:SetOwner(frame, "ANCHOR_LEFT");
	local _, link = GetItemInfo(id)
	
	if link then
		GameTooltip:SetHyperlink(link);
	else
		-- GameTooltip:AddLine(L["Unknown link, please relog this character"],1,1,1);
		GameTooltip:SetHyperlink("item:"..id..":0:0:0:0:0:0:0")	-- this line queries the server for an unknown id
		GameTooltip:ClearLines(); -- don't leave residual info in the tooltip after the server query
	end
	GameTooltip:Show();
end

function addon:Item_OnClick(frame, button)
	local id = frame:GetID()
	if not id or button ~= "LeftButton" then return end
	
	local _, link = GetItemInfo(id)
	if link then
		if IsControlKeyDown() then
			DressUpItemLink(link);
		elseif IsShiftKeyDown() then
			local chat = ChatEdit_GetLastActiveWindow()
			if chat:IsShown() then
				chat:Insert(link);
			end
		end
	end
end

-- DataStore Events
function addon:DATASTORE_QUEST_TURNED_IN(event, questID)
	addon.Quests.Database:InvalidateView()
	addon.Quests.RealmSummary:InvalidateView()
end

﻿local addonName = ...
local addon = _G[addonName]

local BZ = LibStub("LibBabble-Zone-3.0"):GetLookupTable()

-- source : http://www.wowwiki.com/LocalizedMapZones
-- map names can be found by browsing interface data, under Interface\Worldmap
--[[
	Important notes : 
	
	- DO NOT try to replace the "name" field with GetMapZones(continentID), it's not returning consistant names across localizations.
	- Cities SHOULD NOT have an lvMin or lvMax
--]]

local zones = {		-- only the "icon" attribute is there so far, more data will be added during init
	[1] = {		-- "Kalimdor"
		{ name = BZ["Ashenvale"], icon = "Achievement_Zone_Ashenvale_01", lvMin = 20, lvMax = 25 },
		{ name = BZ["Azshara"], icon = "Achievement_Zone_Azshara_01", lvMin = 10, lvMax = 20 },
		{ name = BZ["Azuremyst Isle"], icon = "Achievement_Zone_AzuremystIsle_01", lvMin = 1, lvMax = 10 },
		{ name = BZ["Bloodmyst Isle"], icon = "Achievement_Zone_BloodmystIsle_01", lvMin = 10, lvMax = 20 },
		{ name = BZ["Darkshore"], icon = "Achievement_Zone_Darkshore_01", lvMin = 10, lvMax = 20 },
		{ name = BZ["Darnassus"], icon = "Spell_Arcane_TeleportDarnassus", map = "Darnassus" },
		{ name = BZ["Desolace"], icon = "Achievement_Zone_Desolace", lvMin = 30, lvMax = 35 },
		{ name = BZ["Durotar"], icon = "Achievement_Zone_Durotar", lvMin = 1, lvMax = 10 },
		{ name = BZ["Dustwallow Marsh"], icon = "Achievement_Zone_DustwallowMarsh", lvMin = 35, lvMax = 40 },
		{ name = BZ["Felwood"], icon = "Achievement_Zone_Felwood", lvMin = 45, lvMax = 50 },
		{ name = BZ["Feralas"], icon = "Achievement_Zone_Feralas", lvMin = 35, lvMax = 40 },
		{ name = BZ["Moonglade"], icon = "SPELL_ARCANE_TELEPORTMOONGLADE" },
		--{ name = BZ["Mount Hyjal"], icon = "Achievement_Zone_Mount Hyjal", lvMin = 80, lvMax = 82 },
		{ name = BZ["Mulgore"], icon = "Achievement_Zone_Mulgore_01", lvMin = 1, lvMax = 10 },
		--{ name = BZ["Northern Barrens"], icon = "Achievement_Zone_Barrens_01", lvMin = 10, lvMax = 20 },
		{ name = BZ["Orgrimmar"], icon = "Spell_Arcane_TeleportOrgrimmar", map = "Orgrimmar" },
		{ name = BZ["Silithus"], icon = "Achievement_Zone_Silithus_01", lvMin = 55, lvMax = 60 },
		--{ name = BZ["Southern Barrens"], icon = "Achievement_Boss_CharlgaRazorflank", lvMin = 30, lvMax = 35 },
		{ name = BZ["Stonetalon Mountains"], icon = "Achievement_Zone_Stonetalon_01", lvMin = 25, lvMax = 30 },
		{ name = BZ["Tanaris"], icon = "Achievement_Zone_Tanaris_01", lvMin = 45, lvMax = 50 },
		{ name = BZ["Teldrassil"], icon = "Achievement_Zone_Darnassus", lvMin = 1, lvMax = 10 },
		{ name = BZ["The Exodar"], icon = "Spell_Arcane_TeleportExodar" },
		{ name = BZ["Thousand Needles"], icon = "Achievement_Zone_ThousandNeedles_01", lvMin = 40, lvMax = 45 },
		{ name = BZ["Thunder Bluff"], icon = "Spell_Arcane_TeleportThunderBluff", map = "thunderbluff" },
		--{ name = BZ["Uldum"], icon = "Achievement_Zone_Uldum", lvMin = 83, lvMax = 84 },
		{ name = BZ["Un'Goro Crater"], icon = "Achievement_Zone_UnGoroCrater_01", lvMin = 50, lvMax = 55 },
		{ name = BZ["Winterspring"], icon = "Achievement_Zone_Winterspring", lvMin = 50, lvMax = 55 },
	},
	[2] = {		-- "Eastern Kingdoms"
		{ name = BZ["Arathi Highlands"], icon = "Achievement_Zone_ArathiHighlands_01", lvMin = 25, lvMax = 30 },
		{ name = BZ["Badlands"], icon = "Achievement_Zone_Badlands_01", lvMin = 45, lvMax = 48 },
		{ name = BZ["Blasted Lands"], icon = "Achievement_Zone_BlastedLands_01", lvMin = 54, lvMax = 58 },
		{ name = BZ["Burning Steppes"], icon = "Achievement_Zone_BurningSteppes_01", lvMin = 50, lvMax = 52 },
		{ name = BZ["Deadwind Pass"], icon = "Achievement_Zone_DeadwindPass", lvMin = 70, lvMax = 70 },
		{ name = BZ["Dun Morogh"], icon = "Achievement_Zone_DunMorogh", lvMin = 1, lvMax = 10 },
		{ name = BZ["Duskwood"], icon = "Achievement_Zone_Duskwood", lvMin = 20, lvMax = 25 },
		{ name = BZ["Eastern Plaguelands"], icon = "Achievement_Zone_EasternPlaguelands", lvMin = 40, lvMax = 45 },
		{ name = BZ["Elwynn Forest"], icon = "Achievement_Zone_ElwynnForest", lvMin = 1, lvMax = 10 },
		{ name = BZ["Eversong Woods"], icon = "Achievement_Zone_EversongWoods", lvMin = 1, lvMax = 10 },
		{ name = BZ["Ghostlands"], icon = "Achievement_Zone_Ghostlands", lvMin = 10, lvMax = 20 },
		--{ name = BZ["Ruins of Gilneas"], icon = "Achievement_Zone_Gilneas_02", lvMin = 1, lvMax = 10 },
		--{ name = BZ["Gilneas City"], icon = "Achievement_Zone_Gilneas_02", map = "GilneasCity", lvMin = 1, lvMax = 10 },
		{ name = BZ["Hillsbrad Foothills"], icon = "Achievement_Zone_HillsbradFoothills", lvMin = 20, lvMax = 25 },
		{ name = BZ["Ironforge"], icon = "Achievement_Zone_Ironforge", map = "ironforge" },
		{ name = BZ["Isle of Quel'Danas"], icon = "Achievement_Zone_IsleOfQuelDanas", lvMin = 70, lvMax = 70 },
		{ name = BZ["Loch Modan"], icon = "Achievement_Zone_LochModan", lvMin = 10, lvMax = 20 },
		{ name = BZ["Northern Stranglethorn"], icon = "Achievement_Zone_Stranglethorn_01", map = "StranglethornJungle", lvMin = 25, lvMax = 30 },
		{ name = BZ["Redridge Mountains"], icon = "Achievement_Zone_RedridgeMountains", lvMin = 15, lvMax = 20 },
		{ name = BZ["Searing Gorge"], icon = "Achievement_Zone_SearingGorge_01", map = "SearingGorge", lvMin = 48, lvMax = 50 },
		{ name = BZ["Silvermoon City"], icon = "Spell_Arcane_TeleportSilvermoon", map = "silvermooncity" },
		{ name = BZ["Silverpine Forest"], icon = "Achievement_Zone_Silverpine_01", lvMin = 10, lvMax = 20 },
		{ name = BZ["Stormwind City"], icon = "Spell_Arcane_TeleportStormWind", map = "StormwindCity" },
		{ name = BZ["Swamp of Sorrows"], icon = "Achievement_Zone_SwampSorrows_01", lvMin = 52, lvMax = 54 },
		{ name = BZ["The Cape of Stranglethorn"], icon = "achievement_zone_stranglethorn_01", map = "TheCapeOfStranglethorn", lvMin = 30, lvMax = 35 },
		{ name = BZ["The Hinterlands"], icon = "Achievement_Zone_Hinterlands_01", lvMin = 30, lvMax = 35 },
		{ name = BZ["Tirisfal Glades"], icon = "Achievement_Zone_TirisfalGlades_01", lvMin = 1, lvMax = 10 },
		{ name = BZ["Twilight Highlands"], icon = "achievement_zone_twilighthighlands", lvMin = 84, lvMax = 85 },
		{ name = BZ["Undercity"], icon = "Spell_Arcane_TeleportUnderCity", map = "undercity" },
		{ name = format("%s: %s", BZ["Vashj'ir"], BZ["Abyssal Depths"]), icon = "Achievement_Zone_Vashjir", map = "VashjirDepths", lvMin = 80, lvMax = 82 },
		{ name = format("%s: %s", BZ["Vashj'ir"], BZ["Kelp'thar Forest"]), icon = "Achievement_Zone_Vashjir", map = "VashjirKelpForest", lvMin = 80, lvMax = 82 },
		{ name = format("%s: %s", BZ["Vashj'ir"], BZ["Shimmering Expanse"]), icon = "Achievement_Zone_Vashjir", map = "VashjirRuins", lvMin = 80, lvMax = 82 },
		{ name = BZ["Western Plaguelands"], icon = "Achievement_Zone_WesternPlaguelands_01", lvMin = 35, lvMax = 40 },
		{ name = BZ["Westfall"], icon = "Achievement_Zone_WestFall_01", lvMin = 10, lvMax = 15 },
		{ name = BZ["Wetlands"], icon = "Achievement_Zone_Wetlands_01", lvMin = 20, lvMax = 25 },
		--  { name = "Plaguelands: The Scarlet Enclave", icon = "Achievement_Zone_EasternPlaguelands", map = "scarletenclave" },
	},
	[3] = {		-- "Outland"
		[1] = { name = BZ["Blade's Edge Mountains"], icon = "Achievement_Zone_BladesEdgeMtns_01", lvMin = 65, lvMax = 68 },
		[2] = { name = BZ["Hellfire Peninsula"], icon = "Achievement_Zone_HellfirePeninsula_01", lvMin = 60, lvMax = 62 },
		[3] = { name = BZ["Nagrand"], icon = "Achievement_Zone_Nagrand_01", lvMin = 64, lvMax = 67 },
		[4] = { name = BZ["Netherstorm"], icon = "Achievement_Zone_Netherstorm_01", lvMin = 67, lvMax = 70 },
		[5] = { name = BZ["Shadowmoon Valley"], icon = "Achievement_Zone_Shadowmoon", lvMin = 67, lvMax = 70 },
		[6] = { name = BZ["Shattrath City"], icon = "Spell_Arcane_TeleportShattrath" },
		[7] = { name = BZ["Terokkar Forest"], icon = "Achievement_Zone_Terrokar", lvMin = 63, lvMax = 65 },
		[8] = { name = BZ["Zangarmarsh"], icon = "Achievement_Zone_Zangarmarsh", lvMin = 62, lvMax = 64 },
	},
	[4] = {		-- "Northrend"
		[1] = { name = BZ["Borean Tundra"], icon = "Achievement_Zone_BoreanTundra_02", lvMin = 70, lvMax = 72 },
		[2] = { name = BZ["Crystalsong Forest"], icon = "Achievement_Zone_CrystalSong_01" },
		[3] = { name = BZ["Dalaran"], icon = "Spell_Arcane_TeleportDalaran", map = "dalaran", tex = "dalaran1_" },
		[4] = { name = BZ["Dragonblight"], icon = "Achievement_Zone_DragonBlight_01", lvMin = 72, lvMax = 74 },
		[5] = { name = BZ["Grizzly Hills"], icon = "Achievement_Zone_GrizzlyHills_03", lvMin = 73, lvMax = 75 },
		[6] = { name = BZ["Howling Fjord"], icon = "Achievement_Zone_HowlingFjord_01", lvMin = 70, lvMax = 72 },
		[7] = { name = BZ["Hrothgar's Landing"], icon = "Achievement_Zone_IceCrown_03", lvMin = 77, lvMax = 80 },		-- todo : change this icon
		[8] = { name = BZ["Icecrown"], icon = "Achievement_Zone_IceCrown_03", lvMin = 77, lvMax = 80 },
		[9] = { name = BZ["Sholazar Basin"], icon = "Achievement_Zone_Sholazar_01", lvMin = 76, lvMax = 78 },
		[10] = { name = BZ["The Storm Peaks"], icon = "Achievement_Zone_StormPeaks_01", lvMin = 77, lvMax = 80 },
		[11] = { name = BZ["Wintergrasp"], icon = "Interface\\LFGFrame\\LFGIcon-VaultOfArchavon", lvMin = 77, lvMax = 80 },
		[12] = { name = BZ["Zul'Drak"], icon = "Achievement_Zone_ZulDrak_01", lvMin = 74, lvMax = 77 },
	},
	[5] = {		-- "The Maelstrom"
		{ name = BZ["Deepholm"], icon = "Achievement_Zone_DeepHolm", map = "Deepholm", lvMin = 82, lvMax = 83 },
		{ name = BZ["Kezan"], icon = "INV_Misc_Tabard_Kezan", map = "Kezan", lvMin = 1, lvMax = 6 },
		{ name = BZ["The Lost Isles"], icon = "INV_Misc_Tabard_Kezan", map = "TheLostIsles_terrain2", tex = "TheLostIsles_terrain1", lvMin = 6, lvMax = 12 },
	},
}

local zoneNames = {}		 -- allow revert lookup,  [8] = { name = "Icecrown" }   becomes : ["Icecrown" = 8

for continentID, continent in ipairs(zones) do
	for zoneID, zone in ipairs(continent) do		-- [8] = { name = "Icecrown" },
		zoneNames[zone.name] = zoneID			-- becomes : ["Icecrown"] = 8
	end
end

function addon:IsZoneIDValid(continentID, zoneID)
	if type(zoneID) == "number" and zoneID > 0 and zoneID <= addon:GetNumZones(continentID) then
		return true
	end
end

function addon:GetNumZones(continentID)
	if addon:IsContinentIDValid(continentID) then
		return #zones[continentID]
	end
end

function addon:GetContinentZones(continentID)
	if addon:IsContinentIDValid(continentID) then
		return zones[continentID]
	end
end

function addon:GetZone(continentID, zoneID)
	if addon:IsContinentIDValid(continentID) then
		if addon:IsZoneIDValid(continentID, zoneID) then
			return zones[continentID][zoneID]
		end
	end
end

function addon:GetZoneName(continentID, zoneID)
	local zone = addon:GetZone(continentID, zoneID)
	if zone then
		return zone.name
	end
end

function addon:GetZoneIcon(continentID, zoneID)
	local zone = addon:GetZone(continentID, zoneID)
	if zone then
		if string.find(zone.icon, "Interface") then
			-- icon has a full path
			return zone.icon
		else
			return "Interface\\Icons\\" .. zone.icon
		end
	end
end

function addon:GetZoneIDByName(name)
	return zoneNames[name]
end

function addon:GetZoneLevelRange(continentID, zoneID)
	local zone = addon:GetZone(continentID, zoneID)
	if zone then
		return zone.lvMin, zone.lvMax
	end
end


local function SetZoneHightlight(continentID, zoneID, fileName, textureX, textureY, scrollChildX, scrollChildY)
	local zone = addon:GetZone(continentID, zoneID)
	if not zone then return end
	
	zone.highlight = zone.highlight or {}
	local h = zone.highlight

	if not h[1] then		-- if it's not already known .. save it
		h[1] = fileName
		h[2] = textureX
		h[3] = textureY
		h[4] = scrollChildX
		h[5] = scrollChildY
	end
end

local adjustments = {}		-- list of manual adjustments to be made.Kept to compensate the detection issues with the genuine values.
local overlayNames = {}

local function ScanMapHighlight()
	local name, fileName, textureX, textureY, scrollChildX, scrollChildY
	local zoneID
	
	for continentID = 1, 4 do
		SetMapZoom(continentID)		-- sets the continent map

		adjustments[continentID] = {}

		for x = 0, 1, 0.05 do		-- 5% at a time to make sure all zones are collected. 10% missed some of them
			for y = 0, 1, 0.05 do
				name, fileName, _, _, textureX, textureY, scrollChildX, scrollChildY = UpdateMapHighlight(x, y)				
				--	textureX:	The width of the highlight texture as a proportion of the map's width (between 0 and 1) 
				--	textureY:	The height of the highlight texture as a proportion of the map's height (between 0 and 1)
				--	scrollChildX:	The X location of the start of the highlight texture as a proportion of the map's width (between 0 and 1) 
				--	scrollChildY:	The Y location of the start of the highlight texture as a proportion of the map's height (between 0 and 1)
				
				if fileName then
					zoneID = addon:GetZoneIDByName(name)
					if zoneID then
						SetZoneHightlight(continentID, zoneID, fileName, textureX, textureY, scrollChildX, scrollChildY)
					end
			 	end
			end
		end
	end
	
	-- manual adjustments, yes hardcoding sucks, but this is required to correctly detect zone when mousing over the continent map
	-- adjustments[1]["Barrens"] = { [2] = 0.08, [4] = 0.5	}
	-- adjustments[2]["WesternPlaguelands"] = { [2] = 0.06, [4] = 0.46	}
	-- adjustments[2]["Silverpine"] = { [2] = 0.05, [4] = 0.40 }
end

function addon:InitZones()
	ScanMapHighlight()
	
	for continentID, continent in ipairs(zones) do
		for zoneID, zone in ipairs(continent) do		-- [8] = { name = "Icecrown" , highlight = { [1] = "IcecrownGlacier" , ... },}
			if zone.highlight and zone.highlight[1] then
				overlayNames[zone.highlight[1]] = (continentID * 1000) + zoneID		-- becomes : ["IcecrownGlacier"] = 4008
			-- else
				-- fail silently for now, this happens for capital cities
				-- DEFAULT_CHAT_FRAME:AddMessage("HL not found for " ..zoneID .. " ".. zone.name)
			end
		end
	end
end

function addon:GetZoneHighlight(continentID, zoneID)
	local zone = addon:GetZone(continentID, zoneID)
	if zone then
		local h = zone.highlight
		if h then
			--	name, textureX, textureY, scrollChildX, scrollChildY
			return h[1], h[2], h[3], h[4], h[5]
		else
			return zone.map		-- capital cities might not have highlight data, return map name if available
		end
	end	
end

function addon:GetZoneHighlightByName(zone)
	if overlayNames[zone] then
		local continentID = floor(overlayNames[zone] / 1000)
		local zoneID = mod(overlayNames[zone], 1000)
		return addon:GetZoneHighlight(continentID, zoneID)
	end
end

function addon:GetMousedOverZoneName(continentID, zx, zy)
	-- zx & zy are the x & y coordinates of the mouse cursor in the 0 to 1 range
	local h
	
	for zoneID, zone in pairs(zones[continentID]) do
		h = zone.highlight
		
		if h then 	-- will be nil for capital cities
			if adjustments[continentID][h[1]] then		-- these are exceptions, assign local variables only in this case, do not make a generic use of them
				local p = adjustments[continentID][h[1]]
				
				local textureX = p[2] or h[2]
				local textureY = p[3] or h[3]
				local scrollChildX = p[4] or h[4]
				local scrollChildY = p[5] or h[5]
				
				if zx >= scrollChildX and (zx <= textureX + scrollChildX) then			-- horizontal range
					if zy >= scrollChildY and (zy <= textureY + scrollChildY) then		-- vertical range
						return zone.name, h[1]		-- real name, file name
					end
				end
			else
				if zx >= h[4] and (zx <= h[2] + h[4]) then			-- horizontal range
					if zy >= h[5] and (zy <= h[3] + h[5]) then		-- vertical range
						return zone.name, h[1]		-- real name, file name
					end
				end
			end
		end
	end
end

function addon:GetZoneTexture(continentID, zoneID, tile)
	local zone = addon:GetZone(continentID, zoneID)
	if not zone then return end
	
	local dirName = (zone.highlight) and zone.highlight[1] or zone.map
	local fileName = zone.tex or dirName	-- if a specific texture name is specified, use it, otherwise, same name as directory name
	
	return format("Interface\\WorldMap\\%s\\%s%d", dirName, fileName, tile)
end

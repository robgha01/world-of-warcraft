﻿local addonName = ...
local addon = _G[addonName]
local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local addonList = {
	"Odyssey",
	"OdysseyMap",
	"OdysseyNPC",
	"OdysseyPOI",
	"OdysseyQuests",
}

local WHITE		= "|cFFFFFFFF"
local TEAL		= "|cFF00FF9A"
local ORANGE   = "|cFFFF8400"
local GREEN		= "|cFF00FF00"
local RED		= "|cFFFF0000"

local url1 = "http://wow.curse.com/downloads/wow-addons/details/odyssey.aspx"
local url2 = "http://www.wowinterface.com/downloads/info8533-Altoholic.html"

local help = {
	{	name = "General",
		questions = {
			"What is the purpose of this addon?",
			"Does Odyssey support command line options?",
			"My minimap icon is gone, how do I get it back?",
			-- "What are the official homepages?",
		},
		answers = {
			"This addon is a quest database, it helps you track uncompleted quests accross your alts. Make sure to press the 'Get History' button the first time you load a character.",
			"Type /ody or /odyssey to get the list of command line options.",
			"Go into Odyssey's main option panel, and check 'Show Minimap Icon'.\nYou can also type /ody show.",
			-- format("%s%s\n%s\n%s", "The add-on is only released on these two sites, it is recommended NOT TO get it through other means:", GREEN, url1, url2 ),
		}
	},
	{	name = "Quests",
		questions = {
			"Some quests have no quest giver or quest ender, why is that?",
		},
		answers = {
			"Cataclysm introduced quests that are automatically started and/or completed, and thus do not require interaction with a NPC or an object. This may also be an error in the database.",
		}
	},
	-- {	name = "Localization",
		-- questions = {
			-- "I found a bad translation, how can I help fixing it?",
		-- },
		-- answers = {
			-- format("Use the CurseForge localization tool, at %s|r.", GREEN..url3),
		-- }
	-- },
}	


local support = {
	{	name = "Reporting Bugs",
		questions = {
			"I found an error, how/where do I report it?",
			"What should I do before reporting?",
			"I just upgraded to the latest version, and there are so many Lua errors, what the..??",
			"I have multiple Lua errors at login, should I report them all?",
		},
		answers = {
			"Both Curse and WoWInterface have a ticket section, I also read comments and respond as often as I materially can, so feel free to report in one of these places.",
			format("%s\n\n%s\n%s\n%s\n%s\n%s\n", 
				"A few things:",
				"1) Make sure you have the latest version of the add-on.",
				"2) If you suspect a conflict with another add-on, try to reproduce the issue with only Odyssey enabled. As the add-on deals with a lot of things, a conflict is always possible.",
				"3) Make sure your issue has not been reported by someone else.",
				"4) Never, ever, report that 'it does not work', this is the most useless sentence in the world! Be specific about what does not work.",
				"5) DO NOT copy the entire add-on list from Swatter. While conflicts are possible, they are the exception rather than the rule."
			),
			"I'm just human, I make mistakes. But because I'm human, I fix them too, so be patient. This is a project that I develop in my spare time, and it fluctuates a lot.",
			"No. Only the first error you will get is relevant, it means that something failed during the initialization process of the add-on, or of a library, and this is likely to cause several subsequent errors that are more often than not irrelevant.",
		}
	},
	{	name = "Live support",
		questions = {
			"Is there an IRC channel where I could get live support?",
		},
		answers = {
			format("Yes. Join the %s#altoholic|r IRC channel on Freenode : %sirc://irc.freenode.net:6667/|r", WHITE, GREEN),
		}
	},
}

function addon:GetOption(name)
	if addon.db and addon.db.global then
		return addon.db.global.options[name]
	end
end

function addon:SetOption(name, value)
	if addon.db and addon.db.global then 
		addon.db.global.options[name] = value
	end
end

function addon:ToggleOption(frame, option)
	addon:SetOption(option, (frame:GetChecked()) and 1 or 0)
end

function addon:SetupOptions()
	DataStore:AddOptionCategory(OdysseyGeneralOptions, addonName)
	LibStub("LibAboutPanel").new(addonName, addonName);
	DataStore:AddOptionCategory(OdysseyHelp, HELP_LABEL, addonName)
	DataStore:AddOptionCategory(OdysseySupport, L["Getting support"], addonName)
	DataStore:AddOptionCategory(OdysseyMemoryOptions, L["Memory used"], addonName)
	DataStore:AddOptionCategory(OdysseyQuestOptions, QUESTS_LABEL, addonName)
	DataStore:AddOptionCategory(OdysseyTooltipOptions, L["Tooltip"], addonName)

	DataStore:SetupInfoPanel(help, OdysseyHelp_Text)
	DataStore:SetupInfoPanel(support, OdysseySupport_Text)
	
	help = nil
	support = nil
	
	local value
	
	-- ** General **
	OdysseyGeneralOptions_Title:SetText(TEAL..format("%s %s", addonName, addon.Version))
	
	value = OdysseyGeneralOptions_SliderAngle:GetValue()
	OdysseyGeneralOptions_SliderAngle.tooltipText = L["Move to change the angle of the minimap icon"]
	OdysseyGeneralOptions_SliderAngleLow:SetText("1");
	OdysseyGeneralOptions_SliderAngleHigh:SetText("360"); 
	OdysseyGeneralOptions_SliderAngleText:SetText(format("%s (%s)", L["Minimap Icon Angle"], value))
	L["Move to change the angle of the minimap icon"] = nil
	
	value = OdysseyGeneralOptions_SliderRadius:GetValue()
	OdysseyGeneralOptions_SliderRadius.tooltipText = L["Move to change the radius of the minimap icon"]; 
	OdysseyGeneralOptions_SliderRadiusLow:SetText("1");
	OdysseyGeneralOptions_SliderRadiusHigh:SetText("200"); 
	OdysseyGeneralOptions_SliderRadiusText:SetText(format("%s (%s)", L["Minimap Icon Radius"], value))
	L["Move to change the radius of the minimap icon"] = nil
	
	OdysseyGeneralOptions_ShowMinimapText:SetText(L["Show Minimap Icon"])
	L["Show Minimap Icon"] = nil
	
	value = OdysseyGeneralOptions_SliderAlpha:GetValue()
	OdysseyGeneralOptions_SliderAlphaLow:SetText("0.1");
	OdysseyGeneralOptions_SliderAlphaHigh:SetText("1.0"); 
	OdysseyGeneralOptions_SliderAlphaText:SetText(format("%s (%1.2f)", L["Transparency"], value));

	-- ** Memory **
	OdysseyMemoryOptions_AddonsText:SetText(ORANGE..ADDONS)
	local list = ""
	for index, module in ipairs(addonList) do
		list = format("%s%s:\n", list, module)
	end

	list = format("%s\n%s", list, format("%s:", L["Memory used"]))
	
	OdysseyMemoryOptions_AddonsList:SetText(list)
	
	
	-- ** Quests **
	OdysseyQuestOptions_ShowLevelZeroQuestsText:SetText(L["Show Level Zero Quests"])
	
	-- ** Tooltip **
	OdysseyTooltipOptionsSeriesText:SetText(L["TOOLTIP_QUESTSERIES_TEXT"])
	OdysseyTooltipOptionsQuestTypeText:SetText(L["TOOLTIP_QUESTTYPE_TEXT"])
	OdysseyTooltipOptionsQuestRewardsText:SetText(L["TOOLTIP_QUESTREWARDS_TEXT"])
	OdysseyTooltipOptionsQuestChoicesText:SetText(L["TOOLTIP_QUESTCHOICES_TEXT"])
	OdysseyTooltipOptionsQuestCompletedByText:SetText(L["TOOLTIP_QUESTCOMPLETEDBY_TEXT"])
	
	DataStore:SetCheckBoxTooltip(OdysseyTooltipOptionsSeries, L["TOOLTIP_QUESTSERIES_TITLE"], L["TOOLTIP_QUESTSERIES_ENABLED"], L["TOOLTIP_QUESTSERIES_DISABLED"])
	DataStore:SetCheckBoxTooltip(OdysseyTooltipOptionsQuestType, L["TOOLTIP_QUESTTYPE_TITLE"], L["TOOLTIP_QUESTTYPE_ENABLED"], L["TOOLTIP_QUESTTYPE_DISABLED"])
	DataStore:SetCheckBoxTooltip(OdysseyTooltipOptionsQuestRewards, L["TOOLTIP_QUESTREWARDS_TITLE"], L["TOOLTIP_QUESTREWARDS_ENABLED"], L["TOOLTIP_QUESTREWARDS_DISABLED"])
	DataStore:SetCheckBoxTooltip(OdysseyTooltipOptionsQuestChoices, L["TOOLTIP_QUESTCHOICES_TITLE"], L["TOOLTIP_QUESTCHOICES_ENABLED"], L["TOOLTIP_QUESTCHOICES_DISABLED"])
	DataStore:SetCheckBoxTooltip(OdysseyTooltipOptionsQuestCompletedBy, L["TOOLTIP_QUESTCOMPLETEDBY_TITLE"], L["TOOLTIP_QUESTCOMPLETEDBY_ENABLED"], L["TOOLTIP_QUESTCOMPLETEDBY_DISABLED"])	
	
	-- Restore saved options to UI
	OdysseyGeneralOptions_SliderAngle:SetValue( addon:GetOption("MinimapIconAngle") )
	OdysseyGeneralOptions_SliderRadius:SetValue( addon:GetOption("MinimapIconRadius") )
	OdysseyGeneralOptions_ShowMinimap:SetChecked( addon:GetOption("ShowMinimap") )
	OdysseyGeneralOptions_SliderScale:SetValue( addon:GetOption("UIScale") )
	OdysseyFrame:SetScale( addon:GetOption("UIScale") )
	OdysseyGeneralOptions_SliderAlpha:SetValue( addon:GetOption("UITransparency") )
	
	OdysseyQuestOptions_ShowLevelZeroQuests:SetChecked( addon:GetOption("ShowLevelZeroQuests") )
	OdysseyTooltipOptionsSeries:SetChecked( addon:GetOption("TooltipSeries") )
	OdysseyTooltipOptionsQuestType:SetChecked( addon:GetOption("TooltipQuestType") )
	OdysseyTooltipOptionsQuestRewards:SetChecked( addon:GetOption("TooltipQuestRewards") )
	OdysseyTooltipOptionsQuestChoices:SetChecked( addon:GetOption("TooltipQuestChoices") )
	OdysseyTooltipOptionsQuestCompletedBy:SetChecked( addon:GetOption("TooltipQuestCompletedBy") )

end

function addon:UpdateMinimapIconCoords()
	-- Thanks to Atlas for this code, modified to fit this addon's requirements though
	local xPos, yPos = GetCursorPosition() 
	local left, bottom = Minimap:GetLeft(), Minimap:GetBottom() 

	xPos = left - xPos/UIParent:GetScale() + 70 
	yPos = yPos/UIParent:GetScale() - bottom - 70 

	local iconAngle = math.deg(math.atan2(yPos, xPos))
	if(iconAngle < 0) then
		iconAngle = iconAngle + 360
	end
	
	addon:SetOption("MinimapIconAngle", iconAngle)
	OdysseyGeneralOptions_SliderAngle:SetValue(iconAngle)
end

function addon:MoveMinimapIcon()
	local radius = addon:GetOption("MinimapIconRadius")
	local angle = addon:GetOption("MinimapIconAngle")
	
	OdysseyMinimapButton:SetPoint( "TOPLEFT", "Minimap", "TOPLEFT", 54 - (radius * cos(angle)), (radius * sin(angle)) - 55 );
end

function addon:UpdateMyMemoryUsage()
	DataStore:UpdateMemoryUsage(addonList, OdysseyMemoryOptions, format("%s:", L["Memory used"]))
end

local function ResizeScrollFrame(frame, width, height)
	-- just a small wrapper, nothing generic in here.
	
	local name = frame:GetName()
	_G[name]:SetWidth(width-45)
	_G[name.."_ScrollFrame"]:SetWidth(width-45)
	_G[name]:SetHeight(height-30)
	_G[name.."_ScrollFrame"]:SetHeight(height-30)
	_G[name.."_Text"]:SetWidth(width-80)
end

local OnSizeUpdate = {	-- custom resize functions
	OdysseyHelp = ResizeScrollFrame,
	OdysseySupport = ResizeScrollFrame,
	-- OdysseyWhatsNew = ResizeScrollFrame,
}

local OptionsPanelWidth, OptionsPanelHeight
local lastOptionsPanelWidth = 0
local lastOptionsPanelHeight = 0

function addon:OnUpdate(self, mandatoryResize)
	OptionsPanelWidth = InterfaceOptionsFramePanelContainer:GetWidth()
	OptionsPanelHeight = InterfaceOptionsFramePanelContainer:GetHeight()
	
	if not mandatoryResize then -- if resize is not mandatory, allow exit
		if OptionsPanelWidth == lastOptionsPanelWidth and OptionsPanelHeight == lastOptionsPanelHeight then return end		-- no size change ? exit
	end
		
	lastOptionsPanelWidth = OptionsPanelWidth
	lastOptionsPanelHeight = OptionsPanelHeight
	
	local frameName = self:GetName()
	if frameName and OnSizeUpdate[frameName] then
		OnSizeUpdate[frameName](self, OptionsPanelWidth, OptionsPanelHeight)
	end
end

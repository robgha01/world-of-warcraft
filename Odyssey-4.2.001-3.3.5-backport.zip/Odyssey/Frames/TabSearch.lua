local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"

local view

addon.Tabs.Search = {}

local ns = addon.Tabs.Search		-- ns = namespace

local function BuildView()
	view = {	QUESTS_LABEL, "NPCs", ZONE, "Points of Interest", }
	-- this will most likely turn into a dynamic list, with multiple levels, but a simple table will do for now
end

function ns:Update()
	if not view then
		BuildView()
	end

	local VisibleLines = 15

	local buttonWidth = 156
	if #view > 15 then
		buttonWidth = 136
	end
	
	local offset = FauxScrollFrame_GetOffset( _G[ "OdysseySearchMenuScrollFrame" ] );
	local itemButtom = "OdysseyTabSearchMenuItem"
	for i=1, VisibleLines do
		local line = i + offset
		
		if line > #view then
			_G[itemButtom..i]:Hide()
		else
			_G[itemButtom..i]:SetWidth(buttonWidth)
			_G[itemButtom..i.."NormalText"]:SetWidth(buttonWidth - 21)
			_G[itemButtom..i.."NormalText"]:SetText(WHITE .. view[line])
			_G[itemButtom..i]:Show()
		end
	end
	
	FauxScrollFrame_Update( _G[ "OdysseySearchMenuScrollFrame" ], #view, VisibleLines, 20);
end

function ns:Reset()
	OdysseyFrame_SearchEditBox:SetText("")
	OdysseyTabSearchStatus:SetText("")				-- .. the search results
	OdysseyFrameSearch:Hide()
	Odyssey.Search:ClearResults()

	self:Update()
end

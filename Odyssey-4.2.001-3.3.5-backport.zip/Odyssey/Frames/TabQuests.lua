local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local currentMode

local function SetMode(mode)
	currentMode = mode
	OdysseyTabQuestsStatus:SetText("")
	
	local Columns = addon.Tabs.Columns
	Columns:Init()
	
	if currentMode == 1 then
		Columns:Add(NAME, 130, function(self) addon.Quests.Database:Sort(self, "name") end)
		Columns:Add(LEVEL, 60, function(self) addon.Quests.Database:Sort(self, "level") end)
		Columns:Add(L["Side"], 60, function(self) addon.Quests.Database:Sort(self, "side") end)
		Columns:Add("Starts", 160, function(self) addon.Quests.Database:Sort(self, "starts") end)
		Columns:Add("Ends", 160, function(self) addon.Quests.Database:Sort(self, "ends") end)
	end
end

local childrenFrames = {
	"QuestDB",
	"RealmSummary",
	"QuestDetails",
}

local childrenObjects				-- these are the tables that actually contain the BuildView & Update methods. Not really OOP, but enough for our needs

local frameToID = {}
for index, name in ipairs(childrenFrames) do
	frameToID[name] = index
end

addon.Tabs.Quests = {}

local ns = addon.Tabs.Quests		-- ns = namespace

function ns:Init()
	childrenObjects = {
		addon.Quests.Database,
		addon.Quests.RealmSummary,
		addon.Quests.Details,
	}
end

function ns:MenuItem_OnClick(id)
	if type(id) == "string" then
		id = frameToID[id]
	end

	for _, name in pairs(childrenFrames) do			-- hide all frames
		_G[ "OdysseyFrame" .. name]:Hide()
	end

	SetMode(id)

	local f = _G[ "OdysseyFrame" .. childrenFrames[id]]
	local o = childrenObjects[id]
	
	f:Show()
	o:Update()
	
	for i=1, 3 do 
		_G[ "OdysseyTabQuestsMenuItem"..i ]:UnlockHighlight();
	end
	_G[ "OdysseyTabQuestsMenuItem"..id ]:LockHighlight();
end

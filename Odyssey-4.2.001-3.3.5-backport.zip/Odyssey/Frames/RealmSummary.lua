local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"
local GREEN		= "|cFF00FF00"
local YELLOW	= "|cFFFFFF00"
local RED		= "|cFFFF0000"

local currentContinentID = 1

local function ClassIcon_OnEnter(frame)
	local character = DataStore:GetCharacter(frame.CharName)
	
	OdyTooltip:SetOwner(frame, "ANCHOR_LEFT");
	OdyTooltip:ClearLines();
	OdyTooltip:AddDoubleLine(DataStore:GetColoredCharacterName(character), DataStore:GetColoredCharacterFaction(character))
	OdyTooltip:AddLine(format("%s %s |r%s %s", LEVEL, GREEN..DataStore:GetCharacterLevel(character), DataStore:GetCharacterRace(character), DataStore:GetCharacterClass(character)),1,1,1)
	OdyTooltip:AddLine(" ")
	
	local size, last = DataStore:GetQuestHistoryInfo(character)
	OdyTooltip:AddLine(format("%s : %s", WHITE..L["Quests completed"], GREEN..size))
	
	if last then
		last = YELLOW..date("%m/%d/%Y %H:%M", last)
	else
		last = RED..L["N/A"]
	end
	OdyTooltip:AddLine(format("%s : %s", WHITE..L["Last quest history update"], last))
	OdyTooltip:Show()
end

local function ShowClassIcons()
	local entry = "OdysseyFrameRealmSummaryClassesItem"
	local i = 1
	
	_G[entry .. "10"]:SetPoint("BOTTOMRIGHT", "OdysseyFrameRealmSummaryClasses", "BOTTOMRIGHT", -15, 0);
	for j=9, 1, -1 do
		_G[entry .. j]:SetPoint("BOTTOMRIGHT", entry .. (j + 1), "BOTTOMLEFT", -5, 0);
	end
	
	for characterName, character in pairs(DataStore:GetCharacters()) do
		local itemName = entry .. i;
		local itemButton = _G[itemName];
		itemButton:SetScript("OnEnter", ClassIcon_OnEnter)
		itemButton:SetScript("OnLeave", function(self) OdyTooltip:Hide() end)
		
		local _, class = DataStore:GetCharacterClass(character)
		local tc = CLASS_ICON_TCOORDS[class]
		local itemTexture = _G[itemName .. "IconTexture"]
		itemTexture:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes");
		itemTexture:SetTexCoord(tc[1], tc[2], tc[3], tc[4]);
		itemTexture:SetWidth(36);
		itemTexture:SetHeight(36);
		itemTexture:SetAllPoints(itemButton);
		
		addon:CreateButtonBorder(itemButton)

		if DataStore:GetCharacterFaction(character) == "Alliance" then
			itemButton.border:SetVertexColor(0.1, 0.25, 1, 0.5)
		else
			itemButton.border:SetVertexColor(1, 0, 0, 0.5)
		end
		itemButton.border:Show()
		
		itemButton.CharName = characterName
		itemButton:Show()
		
		i = i + 1
		if i > 10 then 	-- users of Symbolic Links might have more than 10 columns, prevent it
			break
		end
	end
	
	while i <= 10 do
		_G[ entry .. i ]:Hide()
		_G[ entry .. i ].CharName = nil
		i = i + 1
	end
end

local cachedCounts		-- table that will contain cached number of completed quests in a zone (rather static and potentially cpu intensive)
local cachedQuestCounts -- table containing the number of leveling quests in a specific zone

local function GetZoneCompletionInfo(character, continentID, zoneID)
	-- return values 
		-- 1: the completion rate for a given character/zone
		-- 2: the number of leveling quests in the zone
		-- 3: the number of quests completed
		-- 4: the number of quests not completed
	cachedCounts = cachedCounts or {}
	cachedQuestCounts = cachedQuestCounts or {}
	
	local key = format("%s.%s.%s", character, continentID, zoneID)	 -- ex: "Account.Realm.Thaoky.1.2"
	
	local questCount = cachedQuestCounts[key]	-- number of quests actually considered as leveling quests in this zone/faction
	local completedCount = cachedCounts[key]					-- among those, count how many have been completed
	local rate

	-- if we have cached values, return them
	if completedCount and questCount then
		if questCount == 0 and completedCount == 0 then
			rate = 0
		else
			rate = (completedCount / questCount) * 100
		end
		return rate, questCount, completedCount, questCount - completedCount
	end
	
	local quests = addon:GetCategoryQuests(continentID, zoneID)		-- get this zone's quests
	if not quests then
		return 0, 0, 0, 0
	end
	
	questCount = 0
	completedCount = 0
	
	local faction = (DataStore:GetCharacterFaction(character) == "Alliance") and 1 or 2
	local _, class = DataStore:GetCharacterClass(character)
	local _, race = DataStore:GetCharacterRace(character)

	local qf = addon.QuestFilters
	qf:SetFilterValue("Character", character)
	qf:SetFilterValue("Faction", faction)
	qf:SetFilterValue("Race", race)

	qf:EnableFilter("Repeatable")
	qf:EnableFilter("Daily")
	qf:EnableFilter("Weekly")
	qf:EnableFilter("Dungeon")
	qf:EnableFilter("Raid")
	qf:EnableFilter("PVP")
	qf:EnableFilter("NoXP")
	qf:EnableFilter("GoTo")
	qf:EnableFilter("Race")
	qf:EnableFilter("Faction")
	
	for _, questID in pairs(quests) do
		if qf:QuestPassesFilters(questID) then
			questCount = questCount + 1
			
			-- if it has been completed ..
			if DataStore:IsQuestCompletedBy(character, questID) then
				completedCount = completedCount + 1
			end
		end
	end
	qf:ClearFilters()

	cachedCounts[key] = completedCount
	cachedQuestCounts[key] = questCount

	if questCount == 0 and completedCount == 0 then
		rate = 0
	else
		rate = (completedCount / questCount) * 100
	end
	
	return rate, questCount, completedCount, questCount - completedCount
end

local clearCachePending

local function ClearCharacterCache(character)
	local name
	if cachedCounts then
		for key, _ in pairs(cachedCounts) do
			_, _, name = strsplit(".", key)
			if name == character then
				cachedCounts[key] = nil
			end
		end
	end

	if cachedQuestCounts then
		for key, _ in pairs(cachedQuestCounts) do
			_, _, name = strsplit(".", key)
			if name == character then
				cachedCounts[key] = nil
			end
		end
	end
end

addon.Quests.RealmSummary = {}

local ns = addon.Quests.RealmSummary		-- ns = namespace

function ns:Update()
	ShowClassIcons()
	
	if clearCachePending then
		ClearCharacterCache(UnitName("player"))
		clearCachePending = nil
	end
	
	local VisibleLines = 8
	local frame = "OdysseyFrameRealmSummary"
	local entry = frame.."Entry"
	
	local offset = FauxScrollFrame_GetOffset( _G[ frame.."ScrollFrame" ] );
	local numZones = addon:GetNumZones(currentContinentID)
	local character

	for i=1, VisibleLines do
		local line = i + offset
		if line <= numZones then	-- if the line is visible
			_G[entry..i.."Name"]:SetText(WHITE .. addon:GetZoneName(currentContinentID, line))
			_G[entry..i.."Name"]:SetJustifyH("LEFT")
			_G[entry..i.."Name"]:SetPoint("TOPLEFT", 15, 0)
			
			for j = 1, 10 do
				local itemName = entry.. i .. "Item" .. j;
				local itemButton = _G[itemName]
				
				local classButton = _G["OdysseyFrameRealmSummaryClassesItem" .. j]
				if classButton.CharName then
					character = DataStore:GetCharacter(classButton.CharName)
					
					local itemTexture = _G[itemName .. "_Background"]
					itemTexture:SetTexture(addon:GetZoneIcon(currentContinentID, line))
					
					local rate = GetZoneCompletionInfo(character, currentContinentID, line)
					
					local textOffset = 5
					
					if rate >= 100 then
						itemTexture:SetVertexColor(1.0, 1.0, 1.0);
						_G[itemName .. "Name"]:SetText("\124TInterface\\RaidFrame\\ReadyCheck-Ready:14\124t")
					elseif rate == 0 then
						itemTexture:SetVertexColor(0.4, 0.4, 0.4);
						_G[itemName .. "Name"]:SetText("\124TInterface\\RaidFrame\\ReadyCheck-NotReady:14\124t")
					else
						itemTexture:SetVertexColor(0.9, 0.6, 0.2);
						_G[itemName .. "Name"]:SetText(WHITE..format("%2d", floor(rate)) .. "%")
						textOffset = -5
					end
					
					_G[itemName .. "Name"]:SetPoint("BOTTOMRIGHT", textOffset, 0)
					
					itemButton.CharName = classButton.CharName
					itemButton:SetID(line)
					itemButton:Show()
				else
					itemButton:Hide()
					itemButton:SetID(0)
					itemButton.CharName = nil
				end
			end

			_G[ entry..i ]:Show()
		else
			_G[ entry..i ]:Hide()
		end
	end
	
	FauxScrollFrame_Update( _G[ frame.."ScrollFrame" ], numZones, VisibleLines, 41);
end

function ns:OnEnter(frame)
	local charName = frame.CharName
	local zoneID = frame:GetID()
	if not charName or zoneID == 0 then return end

	local character = DataStore:GetCharacter(charName)
	local rate, numQuests, numComplete, numIncomplete = GetZoneCompletionInfo(character, currentContinentID, zoneID)
	
	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_LEFT");
	OdyTooltip:AddDoubleLine(DataStore:GetColoredCharacterName(character), addon:GetZoneName(currentContinentID, zoneID));
	OdyTooltip:AddLine(" ")
	OdyTooltip:AddLine(format(L["%s%d%s leveling quests found"], GREEN, numQuests, WHITE));
	OdyTooltip:AddLine(format(L["%s%d%s have been completed (%s%s%s)"], GREEN, numComplete, WHITE, GREEN, format("%2d", floor(rate)) .. "%", WHITE));
	if numIncomplete and numIncomplete > 0 then
		OdyTooltip:AddLine(format(L["%s%d%s have %snot%s been completed"], GREEN, numIncomplete, WHITE, RED, WHITE));
	end
	OdyTooltip:AddLine(" ")
	OdyTooltip:AddLine(GREEN .. L["Left-Click to view unfinished quests"])
	OdyTooltip:Show()
end

function ns:OnClick(frame, button)
	local charName = frame.CharName
	local zoneID = frame:GetID()
	if not charName or zoneID == 0 then return end
	
	addon.Quests.Database:ShowZoneUnfinishedQuests(charName, currentContinentID, zoneID)
end

local function OnContinentChange(self)
	currentContinentID = self.value
	UIDropDownMenu_SetSelectedValue(OdysseyFrameRealmSummary_SelectContinent, self.value);
	ns:Update()
end

function ns:DropDownContinent_Initialize(self)
	local info = UIDropDownMenu_CreateInfo(); 
	
	for continentID = 1, addon:GetNumContinents() do
		info.text = addon:GetContinentName(continentID)
		info.value = continentID
		info.func = OnContinentChange
		info.checked = nil; 
		UIDropDownMenu_AddButton(info, 1); 
	end
end

function ns:InvalidateView()
	-- in this panel, invalidating the view means setting the cache values for the current player to nil, so that they will be re-assessed in the next pass
	clearCachePending = true	-- do not clear the cache every time, do it only when the view will be refreshed (in ns:Update())
	if OdysseyFrameRealmSummary:IsVisible() then
		ns:Update()
	end
end

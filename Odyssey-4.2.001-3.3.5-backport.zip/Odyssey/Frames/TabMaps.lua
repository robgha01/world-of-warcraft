local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"

local ICON_QUESTGIVERS = "Interface\\LFGFrame\\LFGIcon-Quest"
local ICON_FLIGHTMASTERS = "Interface\\Icons\\ability_mount_snowygryphon"
local ICON_INNKEEPERS = "Interface\\Icons\\INV_Misc_Rune_01"
local ICON_MAILBOXES = "Interface\\Icons\\INV_Letter_21"
local ICON_CLASSES = "Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes"
local ICON_PROFESSIONS = "Interface\\Icons\\Ability_Repair"
local ICON_ECONOMY = "Interface\\Icons\\INV_Misc_Coin_01"
local ICON_BATTLEMASTERS = "Interface\\Icons\\Achievement_BG_winWSG"
local ICON_SEARCH = "Interface\\Icons\\INV_Helmet_47"

local parent = "OdysseyTabMaps"
local rcMenuName = parent .. "RightClickMenu"	-- name of right click menu frames (add a number at the end to get it)

-- "Interface\\Icons\\"

-- local ClassIcons = {
	-- ["MAGE"] = "Interface\\Icons\\INV_Staff_13",
	-- ["WARRIOR"] = "Interface\\Icons\\INV_Sword_27",
	-- ["HUNTER"] = "Interface\\Icons\\INV_Weapon_Bow_07",
	-- ["ROGUE"] = "INV_ThrowingKnife_04",
	-- ["WARLOCK"] = "Interface\\Icons\\Spell_Nature_FaerieFire", 
	-- ["DRUID"] = "Interface\\Icons\\Ability_Druid_Maul", 
	-- ["SHAMAN"] = "Interface\\Icons\\Spell_Nature_BloodLust",
	-- ["PALADIN"] = "|cFFF58CBA", 
	-- ["PRIEST"] = "Interface\\Icons\\INV_Staff_30",
	-- ["DEATHKNIGHT"] = "Interface\\Icons\\Spell_Deathknight_ClassIcon"
-- }

local view
local expandedHeaders = {}
local isViewValid

local currentZoneID
local currentView

local function BuildView()
	view = view or {}
	wipe(view)
	
	for continentID = 1, addon:GetNumContinents() do
		-- add the continent name
		table.insert(view, continentID)
	
		if expandedHeaders[continentID] then
			for zoneID in ipairs(addon:GetContinentZones(continentID)) do
				table.insert(view, (continentID*100)+zoneID )
			end
		end	
	end
	
	isViewValid = true
end

local lastButton

local function StartAutoCastShine(button)
	local item = button:GetName()
	AutoCastShine_AutoCastStart(_G[ item .. "Shine" ]);
	lastButton = item
end

local function StopAutoCastShine()
	-- stop autocast shine on the last button that was clicked
	if lastButton then
		AutoCastShine_AutoCastStop(_G[ lastButton .. "Shine" ]);
	end
end

local function DDM_AddTitle(text)
	-- tiny wrapper
	local info = UIDropDownMenu_CreateInfo(); 

	info.isTitle	= 1
	info.text		= text
	info.checked	= nil
	info.notCheckable = 1
	info.icon		= nil
	UIDropDownMenu_AddButton(info, 1)
end

local function DDM_Add(text, value, func, icon)
	-- tiny wrapper
	local info = UIDropDownMenu_CreateInfo(); 
	
	info.text		= text
	info.value		= value
	info.func		= func
	info.checked	= nil
	info.icon		= icon
	UIDropDownMenu_AddButton(info, 1); 
end

local function DDM_AddCloseMenu()
	local info = UIDropDownMenu_CreateInfo(); 
	
	-- Close menu item
	info.text = CLOSE
	info.func = function() CloseDropDownMenus() end
	info.checked = nil
	info.notCheckable = 1
	info.icon		= nil
	UIDropDownMenu_AddButton(info, 1)
end

-- ** Right-Click menus Set/Get  **
local iconIDs = {
	["CLASS"] = 1,
	["PROFESSION"] = 2,
	["UTILITY"] = 3,
	["BATTLEMASTER"] = 4,
}

local function SetMenuValue(field, value)
	if field and iconIDs[field] then
		UIDropDownMenu_SetSelectedValue( _G[rcMenuName ..iconIDs[field]], value)
	end
end

local function GetMenuValue(field)
	if field and iconIDs[field] then
		return UIDropDownMenu_GetSelectedValue( _G[rcMenuName ..iconIDs[field]])
	end
end

addon.Tabs.Maps = {}

local ns = addon.Tabs.Maps		-- ns = namespace

function ns:Update()
	local VisibleLines = 15
	local buttonWidth = 156
	if #view > 15 then
		buttonWidth = 136
	end

	local offset = FauxScrollFrame_GetOffset( _G[ "OdysseyMapsMenuScrollFrame" ] );
	local itemButtom = parent .. "MenuItem"
	for i=1, VisibleLines do
		local line = i + offset
		
		if line > #view then
			_G[itemButtom..i]:Hide()
			_G[itemButtom..i]:SetID(0)
		else
			local id = view[line]
			
			_G[itemButtom..i]:SetID(id)
			_G[itemButtom..i]:SetWidth(buttonWidth)
			_G[itemButtom..i.."NormalText"]:SetWidth(buttonWidth - 21)
			
			if currentZoneID and currentZoneID == id then
				_G[itemButtom..i]:LockHighlight()
			else
				_G[itemButtom..i]:UnlockHighlight()
			end
			
			if id <= addon:GetNumContinents() then
				_G[itemButtom..i.."NormalText"]:SetText(WHITE .. addon:GetContinentName(id))
			else
				local zoneID = id % 100
				id = floor(id/100)
				_G[itemButtom..i.."NormalText"]:SetText("|cFFBBFFBB   " .. addon:GetZoneName(id, zoneID))
			end

			_G[itemButtom..i]:Show()
		end
	end
	
	FauxScrollFrame_Update( _G[ "OdysseyMapsMenuScrollFrame" ], #view, VisibleLines, 20);
end

function ns:OnClick(self)
	local id = self:GetID()
	if id == 0 then return end
	
	if id <= addon:GetNumContinents() then
		expandedHeaders[id] = not expandedHeaders[id]
		BuildView()
	else
		currentZoneID = id
		local zoneID = id % 100
		id = floor(id/100)
		OdysseyFrameZoneMaps:Show()
		addon.ZoneMaps:Draw(id, zoneID, currentView)
	end
	ns:Update()
end

local IconLabels = {
	QUESTS_LABEL,
	MINIMAP_TRACKING_FLIGHTMASTER,
	MINIMAP_TRACKING_INNKEEPER,
	MINIMAP_TRACKING_MAILBOX,
	MINIMAP_TRACKING_TRAINER_CLASS,
	MINIMAP_TRACKING_TRAINER_PROFESSION,
	format("%s & %s", L["Economy"], L["Utility"]),
	MINIMAP_TRACKING_BATTLEMASTER,
	L["Search Results"]
}

local ID_CLASSES_BUTTON = 5
local ID_BATTLEMASTERS_BUTTON = 8

function ns:Icon_OnEnter(frame)
	local id = frame:GetID()

	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
	OdyTooltip:AddLine(IconLabels[id], 1,1,1)
	OdyTooltip:Show()
	
	for i = 1, 4 do
		if _G[ rcMenuName .. i ].visible then
			ToggleDropDownMenu(1, nil, _G[ rcMenuName .. i ], frame:GetName(), 0, -5);	
			_G[ rcMenuName .. i ].visible = false
		end
	end
	
	if id >= ID_CLASSES_BUTTON and id <= ID_BATTLEMASTERS_BUTTON then
		ToggleDropDownMenu(1, nil, _G[ rcMenuName .. (id-4) ], frame:GetName(), 0, -5);	
		_G[ rcMenuName .. (id-4) ].visible = true
	end
end

function ns:Icon_OnLeave(frame)
	OdyTooltip:Hide();
end

function ns:Icon_OnClick(frame, button)
	local id = frame:GetID()
	currentView = id

	if button == "LeftButton" then
		StopAutoCastShine()
		StartAutoCastShine(frame)
	end
	
	for i = 1, 4 do
		if _G[ rcMenuName .. i ].visible then
			ToggleDropDownMenu(1, nil, _G[ rcMenuName .. i ], frame:GetName(), 0, -5);	
			_G[ rcMenuName .. i ].visible = false
		end
	end
	
	if not currentZoneID then return end
	
	local zoneID = currentZoneID % 100
	local continentID = floor(currentZoneID/100)

	OdysseyFrameZoneMaps:Show()
	addon.ZoneMaps:Draw(continentID, zoneID, currentView)
end

local function OnClassChange(self)
	SetMenuValue("CLASS", self.value)
	ns:Icon_OnClick(_G[parent .. "_ClassesIcon"], "LeftButton")
	CloseDropDownMenus()
end

local function OnProfessionChange(self)
	SetMenuValue("PROFESSION", self.value)
	ns:Icon_OnClick(_G[parent .. "_ProfessionsIcon"], "LeftButton")
	CloseDropDownMenus()
end

local function OnUtilityChange(self)
	SetMenuValue("UTILITY", self.value)
	ns:Icon_OnClick(_G[parent .. "_UtilityIcon"], "LeftButton")
	CloseDropDownMenus()
end

local function OnBattleMasterChange(self)
	SetMenuValue("BATTLEMASTER", self.value)
	ns:Icon_OnClick(_G[parent .. "_BattleMastersIcon"], "LeftButton")
	CloseDropDownMenus()
end

-- ** Menu Icons **
local function ClassesIcon_Initialize(self, level)
	DDM_Add(ALL, 0, OnClassChange)
	DDM_AddTitle(L["Your class"])
	
	local _, englishClass = UnitClass("player")
	
	for index, class in ipairs(addon:GetEnglishClasses()) do
		if class == englishClass then	-- add if equal only
			DDM_Add(WHITE .. addon:GetClassTrainerLabel(index), index, OnClassChange)
		end
	end
	
	DDM_AddTitle("")
	DDM_AddTitle(L["Other classes"])
	for index, class in ipairs(addon:GetEnglishClasses()) do
		if class ~= englishClass then	-- add if different
			DDM_Add(WHITE .. addon:GetClassTrainerLabel(index), index, OnClassChange)
		end
	end
	DDM_AddCloseMenu()
end

local function ProfessionsIcon_Initialize(self, level)
	DDM_Add(ALL, 0, OnProfessionChange)
	DDM_AddTitle(L["Your professions"])
	
	for index, spellID in ipairs(addon:GetProfessionList()) do
		if addon:PlayerKnowsSpell(spellID) then
			DDM_Add(WHITE .. addon:GetProfessionTrainerLabel(index), index, OnProfessionChange, addon:GetSpellIcon(spellID))
		end
	end

	DDM_AddTitle("")
	DDM_AddTitle(L["Other professions"])
	for index, spellID in ipairs(addon:GetProfessionList()) do
		if not addon:PlayerKnowsSpell(spellID) then
			DDM_Add(WHITE .. addon:GetProfessionTrainerLabel(index), index, OnProfessionChange, addon:GetSpellIcon(spellID))
		end
	end
	DDM_AddCloseMenu()
end

local function UtilityIcon_Initialize(self, level)
	-- DDM_Add(ALL, 0, OnUtilityChange)
	-- DDM_AddTitle(L["Economy"])
	-- for i = 4, 9 do
		-- DDM_Add(WHITE .. addon:GetPOITypeName(i), i, OnUtilityChange)
	-- end
	
	-- DDM_AddTitle("")
	-- DDM_AddTitle(L["Utility"])
	-- for i = 81, 86 do
		-- DDM_Add(WHITE .. addon:GetPOITypeName(i), i, OnUtilityChange)
	-- end
	DDM_AddCloseMenu()
end

local function BattleMastersIcon_Initialize(self, level)
	DDM_Add(ALL, 0, OnBattleMasterChange)
	-- for i = 91, 96 do
		-- DDM_Add(WHITE .. addon:GetPOITypeName(i), i, OnBattleMasterChange)
	-- end
	
	for index, label in ipairs(addon:GetBattleMasterList()) do
		DDM_Add(WHITE .. label, index, OnBattleMasterChange)
	end
	DDM_AddCloseMenu()
end

function ns:Init()
	BuildView()
	
	addon:SetItemButtonTexture(parent .. "_QuestGiversIcon", ICON_QUESTGIVERS, 30, 30)
	addon:SetItemButtonTexture(parent .. "_FlightMastersIcon", ICON_FLIGHTMASTERS, 30, 30)
	addon:SetItemButtonTexture(parent .. "_InnkeepersIcon", ICON_INNKEEPERS, 30, 30)
	addon:SetItemButtonTexture(parent .. "_MailboxesIcon", ICON_MAILBOXES, 30, 30)
	addon:SetItemButtonTexture(parent .. "_ClassesIcon", ICON_CLASSES, 30, 30)

	local _, englishClass = UnitClass("player")
	local tc = CLASS_ICON_TCOORDS[englishClass]
	_G[parent .. "_ClassesIconIconTexture"]:SetTexCoord(tc[1], tc[2], tc[3], tc[4]);
	
	addon:SetItemButtonTexture(parent .. "_ProfessionsIcon", ICON_PROFESSIONS, 30, 30)
	addon:SetItemButtonTexture(parent .. "_UtilityIcon", ICON_ECONOMY, 30, 30)
	addon:SetItemButtonTexture(parent .. "_BattleMastersIcon", ICON_BATTLEMASTERS, 30, 30)
	addon:SetItemButtonTexture(parent .. "_SearchIcon", ICON_SEARCH, 30, 30)
	
	UIDropDownMenu_SetSelectedValue(_G[rcMenuName .. "1"], 0)
	UIDropDownMenu_SetSelectedValue(_G[rcMenuName .. "2"], 0)
	UIDropDownMenu_SetSelectedValue(_G[rcMenuName .. "3"], 0)
	UIDropDownMenu_SetSelectedValue(_G[rcMenuName .. "4"], 0)
	
	UIDropDownMenu_Initialize(_G[rcMenuName.."1"], ClassesIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."2"], ProfessionsIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."3"], UtilityIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."4"], BattleMastersIcon_Initialize, "MENU")
end

function ns:ShowMap(continentID, zoneID)
	-- this function is called by other tabs, which "request" this tab to show itself & display a given map
	addon.Tabs:OnClick("Maps")		-- tab shows itself
	
	-- set the menu in the correct state
	wipe(expandedHeaders)
	expandedHeaders[continentID] = true

	currentZoneID = (continentID*100)+zoneID
	BuildView()
	ns:Update()
	
	OdysseyFrameZoneMaps:Show()
	addon.ZoneMaps:Draw(continentID, zoneID, currentView)
end

function ns:ShowNPC(continentID, zoneID, npcID, npcType)
	if not npcID or npcID == 0 then return end

	if addon:IsContinentIDValid(continentID) and addon:IsZoneIDValid(continentID, zoneID) then
		addon.ZoneMaps:ResetSearchResults()
		
		if npcType == "questStarter" then
			addon.ZoneMaps:AddQuestStarter(npcID)
		elseif npcType == "questEnder" then
			addon.ZoneMaps:AddQuestEnder(npcID)
		end
		addon.Tabs.Maps:ShowMap(continentID, zoneID)
		addon.Tabs.Maps:Icon_OnClick(_G[parent .. "_SearchIcon"], "LeftButton")
	end
end

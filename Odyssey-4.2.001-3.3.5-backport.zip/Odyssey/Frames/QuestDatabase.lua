local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"
local DARK_GREEN	= "|cFF00FF00"
local GREEN		= "|cFF00FF00"
local LIGHTBLUE = "|cFFB0B0FF"
local YELLOW	= "|cFFFFFF00"
local RED		= "|cFFFF0000"
local CYAN		= "|cFF1CFAFE"

local ICON_FACTIONS = "Interface\\Icons\\Achievement_BG_winWSG"
local ICON_QUESTS = "Interface\\LFGFrame\\LFGIcon-Quest"
local ICON_QUESTIONMARK = "Interface\\RaidFrame\\ReadyCheck-Waiting"

local ICON_CHARACTERS_ALLIANCE = "Interface\\Icons\\Achievement_Character_Gnome_Female"
local ICON_CHARACTERS_HORDE = "Interface\\Icons\\Achievement_Character_Orc_Male"
-- mini easter egg icons, if you read the code using these, please don't spoil it :)
local ICON_CHARACTERS_MIDSUMMER = "Interface\\Icons\\INV_Misc_Toy_07"
local ICON_CHARACTERS_HALLOWSEND_ALLIANCE = "Interface\\Icons\\INV_Mask_06"
local ICON_CHARACTERS_HALLOWSEND_HORDE = "Interface\\Icons\\INV_Mask_03"
local ICON_CHARACTERS_DOTD_ALLIANCE = "Interface\\Icons\\INV_Misc_Bone_HumanSkull_02"
local ICON_CHARACTERS_DOTD_HORDE = "Interface\\Icons\\INV_Misc_Bone_OrcSkull_01"
local ICON_CHARACTERS_WINTERVEIL_ALLIANCE = "Interface\\Icons\\Achievement_WorldEvent_LittleHelper"
local ICON_CHARACTERS_WINTERVEIL_HORDE = "Interface\\Icons\\Achievement_WorldEvent_XmasOgre"

local parent = "OdysseyFrameQuestDB"
local rcMenuName = parent .. "RightClickMenu"	-- name of right click menu frames (add a number at the end to get it)

local view
local viewSortField = "name"
local viewSortOrder = true
local isViewValid

local viewRepeatable = true
local viewDaily = true
local viewWeekly = true
local viewDungeon = true
local viewRaid = true
local viewPVP = true
local viewRace = true
local viewItems = true
local viewNoXP = true
local viewGoTo = true

local FactionLabels = {	FACTION_ALLIANCE,	FACTION_HORDE,	L["Both factions"] }
local QuestsLabels = { L["Unfinished quests"], L["Finished quests"], L["All quests"] }
local IconLabels = {	CONTINENT, ZONE, FACTION, QUESTS_LABEL, L["Characters"] }


local function SortByName(a, b)
	local nameA = addon:GetQuestName(a) or ""
	local nameB = addon:GetQuestName(b) or ""
	
	if viewSortOrder then
		return nameA < nameB
	else
		return nameA > nameB
	end
end

local function SortByLevel(a, b)
	local levelA = addon:GetQuestLevel(a)
	local levelB = addon:GetQuestLevel(b)
	
	if levelA == levelB then
		return SortByName(a, b)
	elseif viewSortOrder then
		return levelA < levelB
	else
		return levelA > levelB
	end
end

local function SortByFaction(a, b)
	local sideA = addon:GetQuestFaction(a)
	local sideB = addon:GetQuestFaction(b)
	
	if sideA == sideB then
		return SortByLevel(a, b)
	elseif viewSortOrder then
		return sideA < sideB
	else
		return sideA > sideB
	end
end

local function SortByStartNPC(a, b)
	local npcA = addon:GetQuestStarter(a)
	local npcB = addon:GetQuestStarter(b)
	
	if npcA == npcB then
		return SortByLevel(a, b)
	elseif viewSortOrder then
		return npcA < npcB
	else
		return npcA > npcB
	end
end

local function SortByEndNPC(a, b)
	local npcA = addon:GetQuestEnder(a)
	local npcB = addon:GetQuestEnder(b)
	
	if npcA == npcB then
		return SortByLevel(a, b)
	elseif viewSortOrder then
		return npcA < npcB
	else
		return npcA > npcB
	end
end

local PrimaryLevelSort = {	-- sort functions for the mains
	["name"] = SortByName,
	["level"] = SortByLevel,
	["side"] = SortByFaction,
	["starts"] = SortByStartNPC,
	["ends"] = SortByEndNPC,
}

-- ** Right-Click menus Set/Get  **
local iconIDs = {
	["MAINCAT"] = 1,
	["SUBCAT"] = 2,
	["FACTION"] = 3,
	["QUESTS"] = 4,
	["CHARACTER"] = 5,
}

local function SetMenuValue(field, value)
	if field and iconIDs[field] then
		UIDropDownMenu_SetSelectedValue( _G[rcMenuName ..iconIDs[field]], value)
	end
end

local function GetMenuValue(field)
	if field and iconIDs[field] then
		return UIDropDownMenu_GetSelectedValue( _G[rcMenuName ..iconIDs[field]])
	end
end

local VIEW_UNFINISHED_QUESTS = 1
local VIEW_FINISHED_QUESTS = 2
local VIEW_ALL_QUESTS = 3


-- *** Utility functions ***

local DDM_Add = addon.Helpers.DDM_Add
local DDM_AddTitle = addon.Helpers.DDM_AddTitle
local DDM_AddCloseMenu = addon.Helpers.DDM_AddCloseMenu
local DDMLv1_Add = addon.Helpers.DDMLv1_Add
local DDMLv2_Add = addon.Helpers.DDMLv2_Add


local function BuildView()
	view = view or {}
	wipe(view)
	
	local quests = addon:GetCategoryQuests(GetMenuValue("MAINCAT"), GetMenuValue("SUBCAT"))
	if not quests then return end

	local lvMin = _G[parent .. "_MinLevel"]:GetNumber()	-- 0 if nothing entered
	if lvMin == 0 and addon:GetOption("ShowLevelZeroQuests") == 0 then	-- hide lv 0 ?
		lvMin = 1
	end
	
	local lvMax = _G[parent .. "_MaxLevel"]:GetNumber()
	if lvMax == 0 then
		lvMax = MAX_PLAYER_LEVEL
	end
	
	local character = GetMenuValue("CHARACTER")
	local status = GetMenuValue("QUESTS")
	local faction = GetMenuValue("FACTION")
	local _, class = DataStore:GetCharacterClass(character)
	local _, race = DataStore:GetCharacterRace(character)
	
	local qf = addon.QuestFilters
	qf:SetFilterValue("Character", character)
	qf:SetFilterValue("MinLevel", lvMin)
	qf:SetFilterValue("Maxlevel", lvMax)
	qf:SetFilterValue("Status", status)
	qf:SetFilterValue("Faction", faction)
	qf:SetFilterValue("Class", class)
	qf:SetFilterValue("Race", race)
	
	-- only add the filter if it's unchecked, decreases overall processing
	if status ~= VIEW_ALL_QUESTS then qf:EnableFilter("Completed") end
	if not viewRepeatable then qf:EnableFilter("Repeatable") end
	if not viewDaily then qf:EnableFilter("Daily") end
	if not viewWeekly then qf:EnableFilter("Weekly") end
	if not viewDungeon then qf:EnableFilter("Dungeon") end
	if not viewRaid then qf:EnableFilter("Raid") end
	if not viewPVP then qf:EnableFilter("PVP") end
	if not viewItems then qf:EnableFilter("StartedByItem") end
	if not viewNoXP then qf:EnableFilter("NoXP") end
	if not viewGoTo then qf:EnableFilter("GoTo") end
	if not viewRace then qf:EnableFilter("Race") end
	
	if lvMin > 1 then qf:EnableFilter("MinLevel") end
	if lvMax < MAX_PLAYER_LEVEL then qf:EnableFilter("Maxlevel") end
	if faction ~= 3 then qf:EnableFilter("Faction") end
	
	for _, questID in pairs(quests) do
		if qf:QuestPassesFilters(questID) then
			table.insert(view, questID)
		end
	end
	
	table.sort(view, PrimaryLevelSort[viewSortField])
	qf:ClearFilters()
	isViewValid = true
end

local function DisplayQuestIcon(frame, questID)
	local tex = _G[frame:GetName().."_Texture"]
	if questID then
		tex:SetTexture("Interface\\Minimap\\OBJECTICONS")
		
		local r, g, b = 1, 1, 1
		if addon:IsQuestDaily(questID) or addon:IsQuestWeekly(questID) or addon:IsQuestRepeatable(questID) then
			tex:SetTexCoord(0.375, 0.500, 0.25, 0.5)		-- blue !
		elseif addon:IsDungeonQuest(questID) or addon:IsRaidQuest(questID) or addon:IsPVPQuest(questID) then
			tex:SetTexCoord(0.125, 0.250, 0.25, 0.5)		-- yellow ! appears in green with the vertex color
			r = 0
		elseif addon:IsQuestGivingNoXP(questID) or addon:IsGoToQuest(questID) then
			tex:SetTexCoord(0.125, 0.250, 0.25, 0.5)		-- yellow ! appears in red with the vertex color
			g, b = 0, 0
		else
			tex:SetTexCoord(0.125, 0.250, 0.25, 0.5)		-- yellow !
		end
		tex:SetVertexColor(r, g, b);
		tex:Show()
		frame:Show()
	else
		tex:Hide()
		frame:Hide()
	end
end

local function DisplayQuestTitle(frame, questID)
	if questID then
		frame:SetText(LIGHTBLUE .. (addon:GetQuestName(questID) or ""))
		frame:Show()
	else
		frame:Hide()
	end
end

local function DisplayQuestLevel(frame, questID)
	local level = addon:GetQuestLevel(questID)
	if level then
		frame:SetText(WHITE .. level)
		frame:Show()
	else
		frame:Hide()
	end
end

local function DisplayQuestFaction(frame, questID)
	local text
	local side = addon:GetQuestFaction(questID)
	if side ~= 0 then
		text = addon:GetSideIcon(side)
	end	
	
	if text then
		frame:SetText(text)
		frame:Show()
	else
		frame:Hide()
	end
end

local ACTOR_UNKNOWN = 0
local ACTOR_NPC = 1
local ACTOR_OBJECT = 2
local ACTOR_ITEM = 3

local actorLabels = {
	[ACTOR_OBJECT] = "Object",
	[ACTOR_ITEM] = "Item",
}

local function DisplayQuestStarter(frame, questID)
	local name, id, actorType = addon:GetQuestStarter(questID)
	
	frame:SetID(id or 0)
	frame.actorType = actorType
	
	if actorLabels[actorType] then
		name = format("%s%s: %s", WHITE, actorLabels[actorType], name or id)
	end
	
	local frameName = frame:GetName()
	_G[frameName.."NormalText"]:SetText(name or (RED..L["N/A"]))
end

local function DisplayQuestEnder(frame, questID)
	local name, id, actorType = addon:GetQuestEnder(questID)
	
	frame:SetID(id or 0)
	frame.actorType = actorType
	
	if actorLabels[actorType] then
		name = format("%s%s: %s", WHITE, actorLabels[actorType], name or id)
	end
	
	local frameName = frame:GetName()
	_G[frameName.."NormalText"]:SetText(name or (RED..L["N/A"]))
end

local function GetCharacterHistoryText(character)
	local size, last = DataStore:GetQuestHistoryInfo(character)
	size = size or 0

	if last then
		last = YELLOW..date("%m/%d/%Y %H:%M", last)
	else
		last = RED..L["N/A"]
	end
	return format("%s %s(%s%d%s %s, %s: %s%s)", DataStore:GetColoredCharacterName(character), WHITE, GREEN, size, WHITE, QUESTS_LABEL, L["LAST_UPDATE"], last, WHITE)
end


addon.Quests.Database = {}

local ns = addon.Quests.Database		-- ns = namespace

function ns:Update()
	if not isViewValid then
		BuildView()
	end

	local VisibleLines = 18
	local entry = parent.."Entry"
	
	if #view == 0 then 
		for i = 1, VisibleLines do
			_G[ entry..i ]:Hide()
		end
		_G[ parent.."ScrollFrame" ]:Hide()
		return
	end
	_G[ parent.."ScrollFrame" ]:Show()	
	
	local offset = FauxScrollFrame_GetOffset( _G[ parent.."ScrollFrame" ] );
	local i=1
	
	for index = 1, VisibleLines do
		if i > #view then
			break
		end
		
		local line = index + offset
		local questID = view[line]
		DisplayQuestIcon(_G[entry..i.."Icon"], questID)
		DisplayQuestTitle(_G[entry..i.."TitleNormalText"], questID)
		DisplayQuestLevel(_G[entry..i.."Level"], questID)
		DisplayQuestFaction(_G[entry..i.."Side"], questID)
		DisplayQuestStarter(_G[entry..i.."Starts"], questID)
		DisplayQuestEnder(_G[entry..i.."Ends"], questID)
		
		_G[ entry..i ]:SetID(line)
		_G[ entry..i ]:Show()
		
		i = i + 1
	end
	
	while i <= VisibleLines do
		_G[ entry..i ]:SetID(0)
		_G[ entry..i ]:Hide()
		i = i + 1
	end
	
	local last
	if (offset+VisibleLines) <= #view then
		last = offset+VisibleLines
	else
		last = #view
	end
	
	local found = format(L["%s quests found in %s"], GREEN..#view..WHITE, LIGHTBLUE.. addon:GetSubCategoryName(GetMenuValue("MAINCAT"), GetMenuValue("SUBCAT")))
	if #view > 0 then
		found = found .. "|r " .. format( L["(Showing %d-%d)"], offset+1, last )
	end
	OdysseyTabQuestsStatus:SetText(found)
	
	FauxScrollFrame_Update( _G[ parent.."ScrollFrame" ], #view, VisibleLines, 18);
end

function ns:Sort(self, field)
	viewSortField = field
	viewSortOrder = self.ascendingSort
	ns:InvalidateView()
end

function ns:InvalidateView()
	isViewValid = nil
	if _G[ parent ]:IsVisible() then
		ns:Update()
	end
end


-- ** icon events **
local NUM_RC_MENUS = 7

function ns:Icon_OnEnter(frame)
	local currentMenuID = frame:GetID()
	
	-- hide all
	for i = 1, NUM_RC_MENUS do
		if i ~= currentMenuID and _G[ rcMenuName .. i ].visible then
			ToggleDropDownMenu(1, nil, _G[ rcMenuName .. i ], frame:GetName(), 0, -5);	
			_G[ rcMenuName .. i ].visible = false
		end
	end

	-- show current
	ToggleDropDownMenu(1, nil, _G[ rcMenuName .. currentMenuID ], frame:GetName(), 0, -5);	
	_G[ rcMenuName .. currentMenuID ].visible = true
end

local function SetMainCategoryIcon(id)
	SetMenuValue("MAINCAT", id)
	addon:SetItemButtonTexture(parent .. "_ContinentIcon", addon:GetMainCategoryIcon(id), 30, 30)
end

local englishClasses = {
	"DEATHKNIGHT",
	"DRUID",
	"HUNTER",
	"MAGE",
	"PALADIN",
	"PRIEST",
	"ROGUE",
	"SHAMAN",
	"WARLOCK",
	"WARRIOR",
}

local function SetSubCategoryIcon(main, sub)
	SetMenuValue("SUBCAT", sub)
	
	local itemName = parent .. "_ZoneIcon"
	local itemTexture = _G[itemName .. "IconTexture"]
	
	if main == 7 then		-- it's a class icon
		local class = englishClasses[sub]
		local tc = CLASS_ICON_TCOORDS[class]
		
		itemTexture:SetTexture("Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes");
		itemTexture:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
	else
		addon:SetItemButtonTexture(parent .. "_ZoneIcon", addon:GetSubCategoryIcon(main, sub), 30, 30)
		itemTexture:SetTexCoord(0, 1, 0, 1)
	end
end

local function OnMainCategoryChange(self)
	local oldCategory = GetMenuValue("MAINCAT")
	local newCategory = self.value

	SetMainCategoryIcon(newCategory)

	if oldCategory and oldCategory ~= newCategory then		-- if continent changes...
		-- clear zone
		UIDropDownMenu_ClearAll(_G[rcMenuName .."2"]);
		SetMenuValue("SUBCAT", 0)
		
		local itemName = parent .. "_ZoneIcon"
		local itemTexture = _G[itemName .. "IconTexture"]
		
		addon:SetItemButtonTexture(itemName, ICON_QUESTIONMARK, 30, 30)
		itemTexture:SetTexCoord(0, 1, 0, 1)
	end
	ns:InvalidateView()
end

local function OnSubCategoryChange(self)
	local newCategory = self.value
	
	SetSubCategoryIcon(GetMenuValue("MAINCAT"), newCategory)
	OdysseyTabQuests_Sort1.ascendingSort = true
	ns:Sort(OdysseyTabQuests_Sort1, "name")
	CloseDropDownMenus()
end

local function OnFactionChange(self)
	SetMenuValue("FACTION", self.value)
	ns:InvalidateView()
end

local function OnQuestsChange(self)
	SetMenuValue("QUESTS", self.value)
	ns:InvalidateView()
end

local SHOW_ALL = 10
local HIDE_ALL = 11

local SHOW_REPEATABLE = 20
local SHOW_DAILY = 21
local SHOW_WEEKLY = 22
local SHOW_DUNGEON = 23
local SHOW_RAID = 24
local SHOW_PVP = 25
local SHOW_RACE = 26
local SHOW_ITEMS = 27
local SHOW_NOXP = 28
local SHOW_GOTO = 29

local XPackIDs = { 14864, 14865, 14866, 15072 }	-- for cataclysm

local function OnFilterChange(self)
	local filter = self.value

	-- simply toggle the filter that was clicked
	if filter == SHOW_ALL then
		viewRepeatable = true
		viewDaily = true
		viewWeekly = true
		viewDungeon = true
		viewRaid = true
		viewPVP = true
		viewRace = true
		viewItems = true
		viewNoXP = true
		viewGoTo = true
	elseif filter == HIDE_ALL then
		viewRepeatable = nil
		viewDaily = nil
		viewWeekly = nil
		viewDungeon = nil
		viewRaid = nil
		viewPVP = nil
		viewRace = nil
		viewItems = nil
		viewNoXP = nil
		viewGoTo = nil
	elseif filter == SHOW_REPEATABLE then
		viewRepeatable = not viewRepeatable
	elseif filter == SHOW_DAILY then
		viewDaily = not viewDaily
	elseif filter == SHOW_WEEKLY then
		viewWeekly = not viewWeekly
	elseif filter == SHOW_DUNGEON then
		viewDungeon = not viewDungeon
	elseif filter == SHOW_RAID then
		viewRaid = not viewRaid
	elseif filter == SHOW_PVP then
		viewPVP = not viewPVP
	elseif filter == SHOW_RACE then
		viewRace = not viewRace
	elseif filter == SHOW_ITEMS then
		viewItems = not viewItems
	elseif filter == SHOW_NOXP then
		viewNoXP = not viewNoXP
	elseif filter == SHOW_GOTO then
		viewGoTo = not viewGoTo
	end
	ns:InvalidateView()
end

local function OnCharacterChange(self)
	SetMenuValue("CHARACTER", self.value)
	ns:InvalidateView()
end

local function ShowOptionsCategory(self)
	addon:ToggleUI()
	InterfaceOptionsFrame_OpenToCategory(self.value)
end

-- ** Menu Icons **

local function ContinentIcon_Initialize(self, level)
	DDM_AddTitle(CONTINENT)
	for i = 1, 4 do
		DDM_Add(WHITE .. addon:GetMainCategoryName(i), i, OnMainCategoryChange)
	end
	DDM_AddTitle(OTHER)
	for i = 6, 11 do
		DDM_Add(WHITE .. addon:GetMainCategoryName(i), i, OnMainCategoryChange)
	end
	DDM_AddCloseMenu()
end

local function ZoneIcon_Initialize(self, level)
	local category = GetMenuValue("MAINCAT")
	
	if category then
		if category <= 2 then	-- special treatment for kalimdor & eastern kingdoms, since there are too many to fit on one screen
			local info = UIDropDownMenu_CreateInfo()
			if level == 1 then
				DDMLv1_Add("1-30", 1)
				DDMLv1_Add("31-60", 2)
				DDMLv1_Add("70+", 3)
				DDMLv1_Add("Cities", 4)

			elseif level == 2 then
				local lvMin, lvMax
				local zoneMin, zoneMax, text
				
				if UIDROPDOWNMENU_MENU_VALUE == 1 then
					lvMin, lvMax = 1, 30
				elseif UIDROPDOWNMENU_MENU_VALUE == 2 then
					lvMin, lvMax = 31, 60
				elseif UIDROPDOWNMENU_MENU_VALUE == 3 then
					lvMin, lvMax = 70, 85
				elseif UIDROPDOWNMENU_MENU_VALUE == 4 then
				
					for i = 1, addon:GetSubCategorySize(category) do
						zoneMin, zoneMax = addon:GetZoneLevelRange(category, i)		-- cities have no zone range
					
						if not zoneMin and not zoneMax then
							DDMLv2_Add(WHITE..addon:GetSubCategoryName(category, i), i, OnSubCategoryChange)
						end
					end
					return
				end
				
				for i = 1, addon:GetSubCategorySize(category) do
					zoneMin, zoneMax = addon:GetZoneLevelRange(category, i)
				
					if zoneMin and zoneMax and zoneMin >= lvMin and zoneMax <= lvMax then
						text = format("%s%s %s(%d-%d)", WHITE, addon:GetSubCategoryName(category, i), GREEN, zoneMin, zoneMax)
						DDMLv2_Add(text, i, OnSubCategoryChange)
					end
				end
			end
			return
		
		elseif category == 8 then	-- special treatment for dungeons, since there are too many to fit on one screen
			local info = UIDropDownMenu_CreateInfo()
			if level == 1 then
				for i = 1, #XPackIDs do
					DDMLv1_Add(GetCategoryInfo(XPackIDs[i]), i)
				end
			elseif level == 2 then
				for i = 1, addon:GetSubCategorySize(category) do
					if addon:GetDungeonXPack(i) == UIDROPDOWNMENU_MENU_VALUE then
						DDMLv2_Add(WHITE .. addon:GetSubCategoryName(category, i), i, OnSubCategoryChange)
					end
				end
			end
			return
		else
			local zoneMin, zoneMax, text
			for i = 1, addon:GetSubCategorySize(category) do
				zoneMin, zoneMax = addon:GetZoneLevelRange(category, i)
				
				if zoneMin and zoneMax then
					text = format("%s%s %s(%d-%d)", WHITE, addon:GetSubCategoryName(category, i), GREEN, zoneMin, zoneMax)
				else
					text = WHITE .. addon:GetSubCategoryName(category, i)
				end
				DDM_Add(text, i, OnSubCategoryChange)
			end
		end
	end
	DDM_AddCloseMenu()
end

local function FactionIcon_Initialize(self, level)
	DDM_AddTitle(FACTION)
	for index, label in ipairs(FactionLabels) do
		DDM_Add(WHITE .. label, index, OnFactionChange)
	end
	DDM_AddCloseMenu()
end

local function QuestIcon_Initialize(self, level)
	for index, label in ipairs(QuestsLabels) do
		DDM_Add(WHITE .. label, index, OnQuestsChange)
	end
	
	local redFlag = RED.."!! "
	local greenFlag = GREEN.."!! "
	local blueFlag = CYAN.."!! "
	
	DDM_AddTitle("")
	DDM_AddTitle(L["Filters"])
	DDM_Add(WHITE .. L["ENABLE_ALL_FILTERS"], SHOW_ALL, OnFilterChange)
	DDM_Add(WHITE .. L["DISABLE_ALL_FILTERS"], HIDE_ALL, OnFilterChange)
	DDM_AddTitle("")
	DDM_Add(blueFlag .. WHITE .. L["SHOW_REPEATABLE"], SHOW_REPEATABLE, OnFilterChange, nil, viewRepeatable)
	DDM_Add(blueFlag .. WHITE .. L["SHOW_DAILY"], SHOW_DAILY, OnFilterChange, nil, viewDaily)
	DDM_Add(blueFlag .. WHITE .. L["SHOW_WEEKLY"], SHOW_WEEKLY, OnFilterChange, nil, viewWeekly)
	DDM_Add(greenFlag .. WHITE .. L["SHOW_DUNGEON"], SHOW_DUNGEON, OnFilterChange, nil, viewDungeon)
	DDM_Add(greenFlag .. WHITE .. L["SHOW_RAID"], SHOW_RAID, OnFilterChange, nil, viewRaid)
	DDM_Add(greenFlag .. WHITE .. L["SHOW_PVP"], SHOW_PVP, OnFilterChange, nil, viewPVP)
	DDM_Add(WHITE .. L["SHOW_OTHER_RACES"], SHOW_RACE, OnFilterChange, nil, viewRace)
	DDM_Add(WHITE .. L["SHOW_STARTED_BY_ITEM"], SHOW_ITEMS, OnFilterChange, nil, viewItems)
	DDM_Add(redFlag .. WHITE .. L["SHOW_NOXP"], SHOW_NOXP, OnFilterChange, nil, viewNoXP)
	DDM_Add(redFlag .. WHITE .. L["SHOW_GOTO"], SHOW_GOTO, OnFilterChange, nil, viewGoTo)

	DDM_AddCloseMenu()
end

local function CharacterIcon_Initialize(self, level)

	DDM_AddTitle(L["Characters"])
	local nameList = {}		-- we want to list characters alphabetically
	for _, character in pairs(DataStore:GetCharacters()) do
		table.insert(nameList, character)	-- we can add the key instead of just the name, since they will all be like account.realm.name, where account & realm are identical
	end
	table.sort(nameList)
	
	for _, character in ipairs(nameList) do
		DDM_Add(GetCharacterHistoryText(character), character, OnCharacterChange)
	end

	wipe(nameList)
	
	-- add imported characters if any
	for accountName in pairs(DataStore:GetAccounts()) do
		if accountName ~= "Default" then
			for _, character in pairs(DataStore:GetCharacters(nil, accountName)) do		-- this realm, foreign accounts
				table.insert(nameList, character)
			end
		end
	end
	
	if #nameList > 0 then
		table.sort(nameList)
		DDM_AddTitle("")
		DDM_AddTitle("Imported Characters")
		
		for _, character in ipairs(nameList) do
			DDM_Add(GetCharacterHistoryText(character), character, OnCharacterChange)
		end
	end
	DDM_AddCloseMenu()
end

local function OdysseyOptionsIcon_Initialize(self, level)
	DDM_AddTitle(format("%s: %s", GAMEOPTIONS_MENU, addonName))
	
	DDM_Add(GENERAL, OdysseyGeneralOptions, ShowOptionsCategory)
	DDM_Add(QUESTS_LABEL, OdysseyQuestOptions, ShowOptionsCategory)
	DDM_Add(L["Tooltip"], OdysseyTooltipOptions, ShowOptionsCategory)
	
	DDM_AddTitle(" ")	
	DDM_AddTitle(OTHER)	
	DDM_Add("Getting support", OdysseySupport, ShowOptionsCategory)
	DDM_Add(L["Memory used"], OdysseyMemoryOptions, ShowOptionsCategory)
	DDM_Add(HELP_LABEL, OdysseyHelp, ShowOptionsCategory)
	DDM_AddCloseMenu()
end

local addonList = {
	"DataStore_Auctions",
	"DataStore_Characters",
	"DataStore_Inventory",
	"DataStore_Mails",
	"DataStore_Quests",
}

local function DataStoreOptionsIcon_Initialize(self, level)
	DDM_AddTitle(format("%s: %s", GAMEOPTIONS_MENU, "DataStore"))
	
	for _, module in ipairs(addonList) do
		if _G[module] then	-- only add loaded modules
			DDM_Add(module, module, ShowOptionsCategory)
		end
	end
	
	DDM_AddTitle(" ")	
	DDM_Add(HELP_LABEL, DataStoreHelp, ShowOptionsCategory)
	DDM_AddCloseMenu()
end

function ns:Init()
	-- continent
	local continentID = addon:GetCurrentContinent()
	SetMenuValue("MAINCAT", continentID)
	addon:SetItemButtonTexture(parent .. "_ContinentIcon", addon:GetContinentIcon(continentID), 30, 30)
	
	-- current zone
	local zoneName = GetRealZoneText()
	if zoneName then
		-- f = OdysseyTabQuests_SelectZone
		local zoneID = addon:GetZoneIDByName(zoneName)
		if not zoneID or zoneID <= 1 then
			zoneID = 1		-- value won't be acceptable if player is in a dungeon, so default it to 1
		end
		SetMenuValue("SUBCAT", zoneID)
		addon:SetItemButtonTexture(parent .. "_ZoneIcon", addon:GetZoneIcon(continentID, zoneID), 30, 30)
	end
	
	-- faction
	local faction = UnitFactionGroup("player")
	SetMenuValue("FACTION", (faction == "Alliance") and 1 or 2)
	addon:SetItemButtonTexture(parent .. "_FactionIcon", ICON_FACTIONS, 30, 30)
	
	-- quests
	SetMenuValue("QUESTS", 1)		-- 1 = unfinished quests
	addon:SetItemButtonTexture(parent .. "_QuestIcon", ICON_QUESTS, 30, 30)
	
	-- characters
	SetMenuValue("CHARACTER", DataStore:GetCharacter())
	
	-- mini easter egg, change the icon depending on the time of year :)
	-- if you find this code, please don't spoil it :)
	local day = (tonumber(date("%m")) * 100) + tonumber(date("%d"))	-- ex: dec 15 = 1215, for easy tests below
	local icon = (faction == "Alliance") and ICON_CHARACTERS_ALLIANCE or ICON_CHARACTERS_HORDE

	if (day >= 1215) or (day <= 102) then				-- winter veil
		icon = (faction == "Alliance") and ICON_CHARACTERS_WINTERVEIL_ALLIANCE or ICON_CHARACTERS_WINTERVEIL_HORDE
	elseif (day >= 621) and (day <= 704) then			-- midsummer
		icon = ICON_CHARACTERS_MIDSUMMER
	elseif (day >= 1018) and (day <= 1031) then		-- hallow's end
		icon = (faction == "Alliance") and ICON_CHARACTERS_HALLOWSEND_ALLIANCE or ICON_CHARACTERS_HALLOWSEND_HORDE
	elseif (day >= 1101) and (day <= 1102) then		-- day of the dead
		icon = (faction == "Alliance") and ICON_CHARACTERS_DOTD_ALLIANCE or ICON_CHARACTERS_DOTD_HORDE
	end
	
	addon:SetItemButtonTexture(parent .. "_CharacterIcon", icon, 30, 30)
	
	UIDropDownMenu_Initialize(_G[rcMenuName.."1"], ContinentIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."2"], ZoneIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."3"], FactionIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."4"], QuestIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."5"], CharacterIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."6"], OdysseyOptionsIcon_Initialize, "MENU")
	UIDropDownMenu_Initialize(_G[rcMenuName.."7"], DataStoreOptionsIcon_Initialize, "MENU")
end


-- ** data frame events **
function ns:Title_OnClick(frame, button)
	if button == "LeftButton" then
		local questID = view[frame:GetParent():GetID()]
		
		if IsShiftKeyDown() then
			addon:LinkQuestToChat(questID)
			return
		end
		
		addon.Quests.Details:SetQuestID(questID)
		addon.Tabs.Quests:MenuItem_OnClick("QuestDetails")
	end
end

function ns:Title_OnEnter(frame)
	addon:ShowQuestTooltip(frame, view[frame:GetParent():GetID()], GetMenuValue("CHARACTER"))
end

function ns:NPC_OnClick(frame, button, npcType)
	local npcID = frame:GetID()
	if button == "LeftButton" then 
		local continentID, zoneID = addon:GetNPCLocation(npcID)
		addon.Tabs.Maps:ShowNPC(continentID, zoneID, npcID, npcType)
	elseif button == "RightButton" then
		addon:AddNPCToTomTom(npcID)
	end
end


-- ** Get History **
function ns:GetHistory()
	DataStore:QueryQuestHistory()
	ns:InvalidateView()
	addon.Quests.RealmSummary:InvalidateView()
end

function ns:ShowZoneUnfinishedQuests(charName, continentID, zoneID)
	-- called from the realm summary, this sets filters to view unfinished leveling quests for a given character
	
	-- set filters
	SetMainCategoryIcon(continentID)
	SetSubCategoryIcon(continentID, zoneID)
	
	local character = DataStore:GetCharacter(charName)
	local faction = (DataStore:GetCharacterFaction(character) == "Alliance") and 1 or 2
	SetMenuValue("FACTION", faction)
	SetMenuValue("QUESTS", 1)				-- 1 = unfinished quests
	viewRepeatable = nil
	viewDaily = nil
	viewWeekly = nil
	viewRace = nil
	viewItems = true
	viewNoXP = nil
	viewGoTo = nil
	viewDungeon = nil
	viewRaid = nil
	viewPVP = nil
	
	SetMenuValue("CHARACTER", character)
	
	addon.Tabs.Quests:MenuItem_OnClick("QuestDB")
	ns:InvalidateView()
end

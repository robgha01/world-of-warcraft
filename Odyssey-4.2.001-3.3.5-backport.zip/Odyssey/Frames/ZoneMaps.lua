local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"
local GREY		= "|cFF808080"
local CYAN		= "|cFF1CFAFE"

local ICON_FACTION_HORDE = "Interface\\Icons\\INV_BannerPVP_01"
local ICON_FACTION_ALLIANCE = "Interface\\Icons\\INV_BannerPVP_02"
local ICON_INNKEEPERS = "Interface\\Icons\\INV_Misc_Rune_01"
local ICON_MAILBOXES = "Interface\\Icons\\INV_Letter_21"
local ICON_CLASSES = "Interface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes"
local ICON_BATTLEMASTERS = "Interface\\Icons\\Achievement_BG_winWSG"

local MAP_WIDTH = 1002
local MAP_HEIGHT = 668
local MAP_SCALE = 112/256 	-- since my tiles are 112*112 instead of 256*256, the scale is 112/256, or 0.44...
local SCALED_MAP_WIDTH = MAP_WIDTH * MAP_SCALE
local SCALED_MAP_HEIGHT = MAP_HEIGHT * MAP_SCALE

local POI_FLIGHTMASTER		= 1
local POI_INNKEEPER			= 2
local POI_MAILBOX				= 3

local searchResults
local currentContinent
local currentZone

local SEARCH_TYPE_QUESTSTARTER = 1
local SEARCH_TYPE_QUESTENDER = 2

-- NPC Types 
local NPC_CLASS_TRAINER = 1
local NPC_PROFESSION_TRAINER = 2
local NPC_BATTLEMASTER = 3
local NPC_STABLEMASTER = 4
local NPC_FLIGHTMASTER = 5
local NPC_SPIRITHEALER = 6
local NPC_INNKEEPER = 7


local function SortByLevel(a, b)
	local levelA = addon:GetQuestLevel(a)
	local levelB = addon:GetQuestLevel(b)
	return levelA < levelB
end

-- *** Buttons ***
local buttonList = {}	-- list of buttons that will be recycled to display quest givers, innkeepers, etc...
local buttonCount

local function ResetButtonCount()
	buttonCount = 0
end

local function DrawButton(x, y, texture, width, height)
	buttonCount = buttonCount + 1

	local id = buttonCount	
	local itemButton = buttonList[id]
	local itemTexture
	
	if not itemButton then		-- button frame does not exist yet ? create it
		buttonList[id] = CreateFrame("Button", "OdyZoneMapsButton"..id, OdysseyFrameZoneMaps)
		itemButton = buttonList[id]
		itemButton:RegisterForClicks("LeftButtonDown", "RightButtonDown")
		itemTexture = itemButton:CreateTexture("OdyZoneMapsButton"..id.."_Texture", "OVERLAY");
	else
		itemTexture = _G["OdyZoneMapsButton"..id.."_Texture"]
	end

	-- offset x * (x*SCALED_MAP_WIDTH/100) , but  withdraw half of the texture width to make sure it's centered, same on y-axis
	itemButton:SetPoint("TOPLEFT", OdysseyFrameZoneMapsTile1, "TOPLEFT",
		(x*SCALED_MAP_WIDTH/100)-(width/2),
		-(y*SCALED_MAP_HEIGHT/100)+(height/2));
	itemButton:SetWidth(width);
	itemButton:SetHeight(height);

	itemTexture:SetTexture(texture);
	itemTexture:SetAllPoints(itemButton);
	itemTexture:Show()
	itemButton:Show()

	return itemButton, itemTexture
end

local function HideUnusedButtons()
	buttonCount = buttonCount + 1
	while buttonCount <= #buttonList do
		_G["OdyZoneMapsButton" .. buttonCount]:Hide()
		_G["OdyZoneMapsButton" .. buttonCount]:SetID(0)	
		buttonCount = buttonCount + 1
	end
	buttonCount = nil
end



-- *** OnClick ***
local function NPCButton_OnClick(frame, button)
	if button == "RightButton" then
		addon:AddNPCToTomTom(frame:GetID())
	end
end

local function MailBox_OnClick(frame, button)
	if button ~= "RightButton" or not TomTom then return end
	
	local id = frame:GetID()
	local pos = id % 100
	local zoneID = floor((id % 10000) / 100)
	local continentID = floor(id/10000)

	local loc = addon:GetPOILocations(continentID, zoneID, POI_MAILBOX)
	if loc and loc[pos] then
		TomTom:AddZWaypoint(continentID, zoneID, loc[pos].x, loc[pos].y, MINIMAP_TRACKING_MAILBOX)
	end	
end

-- *** OnEnter ***
local function QuestGiver_OnEnter(frame)
	local npcID = frame:GetID()
	local npcName = addon:GetNPCName(npcID)
	if not npcName then return end

	local questList = addon:GetNPCQuests(npcID)
	if not questList then return end
	
	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
	OdyTooltip:AddDoubleLine(npcName, format("%s%2.1f %s%2.1f", WHITE.."x:"..CYAN, frame.xLoc, WHITE.."y:"..CYAN, frame.yLoc) )
	OdyTooltip:AddLine(L["Starts quests"] ..":", 1, 1, 1)
	OdyTooltip:AddLine(" ")
	
	local name, level, side
	local color, icon
	local allianceIcon = addon:TextureToFontstring(ICON_FACTION_ALLIANCE, 18, 18)
	local hordeIcon = addon:TextureToFontstring(ICON_FACTION_HORDE, 18, 18)
	
	table.sort(questList, SortByLevel)
	
	for _, questID in pairs( questList ) do
		name = addon:GetQuestName(questID)
		level = addon:GetQuestLevel(questID)
		side = addon:GetQuestFaction(questID)

		color = (level == 0) and GREY or WHITE
		
		if side == 1 then
			icon = allianceIcon
		elseif side == 2 then
			icon = hordeIcon
		elseif side == 3 then
			icon = allianceIcon .. " " ..hordeIcon
		else
			icon = ""
		end
		
		OdyTooltip:AddLine(format("%s %s[%s] %s (ID: %s)", icon, color, level, name, questID))
	end
	
	OdyTooltip:Show()
end

local function FlightMaster_OnEnter(frame)
--	to do:
	--	clean up this function, 
	--	list connections to other flights + time,
	--	list faction if possible,
	--	list already known by this char or not, 
	--	keep "starts quests" if any
	
	local npcID = frame:GetID()
	local npcName = addon:GetNPCName(npcID)
	if not npcName then return end

	local questList = addon:GetNPCQuests(npcID)
	if not questList then return end
	
	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
	OdyTooltip:AddDoubleLine(npcName, format("%s%2.1f %s%2.1f", WHITE.."x:"..CYAN, frame.xLoc, WHITE.."y:"..CYAN, frame.yLoc) )
	if #questList == 0 then
		OdyTooltip:Show()
		return
	end
	
	OdyTooltip:AddLine(L["Starts quests"] ..":", 1, 1, 1)
	OdyTooltip:AddLine(" ")
	
	local name, level, side
	local color, icon
	local allianceIcon = addon:TextureToFontstring(ICON_FACTION_ALLIANCE, 18, 18)
	local hordeIcon = addon:TextureToFontstring(ICON_FACTION_HORDE, 18, 18)
	
	table.sort(questList, SortByLevel)
	
	for _, questID in pairs( questList ) do
		name = addon:GetQuestName(questID)
		level = addon:GetQuestLevel(questID)
		side = addon:GetQuestFaction(questID)
		
		color = (level == 0) and GREY or WHITE
		
		if side == 1 then
			icon = allianceIcon
		elseif side == 2 then
			icon = hordeIcon
		elseif side == 3 then
			icon = allianceIcon .. " " ..hordeIcon
		else
			icon = ""
		end
		
		OdyTooltip:AddLine(format("%s %s[%s] %s (ID: %s)", icon, color, level, name, questID))
	end
	
	OdyTooltip:Show()
end

local function Innkeeper_OnEnter(frame)
--	to do:
	--	clean up this function, 
	--	list connections to other flights + time,
	--	list faction if possible,
	--	list already known by this char or not, 
	--	keep "starts quests" if any

	local npcID = frame:GetID()
	local npcName = addon:GetNPCName(npcID)
	if not npcName then return end

	local questList = addon:GetNPCQuests(npcID)
	if not questList then return end
	
	OdyTooltip:ClearLines();
	OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
	OdyTooltip:AddDoubleLine(npcName, format("%s%2.1f %s%2.1f", WHITE.."x:"..CYAN, frame.xLoc, WHITE.."y:"..CYAN, frame.yLoc) )
	if #questList == 0 then
		OdyTooltip:Show()
		return
	end
	
	OdyTooltip:AddLine(L["Starts quests"] ..":", 1, 1, 1)
	OdyTooltip:AddLine(" ")
	
	local name, level, side
	local color, icon
	local allianceIcon = addon:TextureToFontstring(ICON_FACTION_ALLIANCE, 18, 18)
	local hordeIcon = addon:TextureToFontstring(ICON_FACTION_HORDE, 18, 18)
	
	table.sort(questList, SortByLevel)
	
	for _, questID in pairs( questList ) do
		name = addon:GetQuestName(questID)
		level = addon:GetQuestLevel(questID)
		side = addon:GetQuestFaction(questID)
		
		color = (level == 0) and GREY or WHITE
		
		if side == 1 then
			icon = allianceIcon
		elseif side == 2 then
			icon = hordeIcon
		elseif side == 3 then
			icon = allianceIcon .. " " ..hordeIcon
		else
			icon = ""
		end
		
		OdyTooltip:AddLine(format("%s %s[%s] %s (ID: %s)", icon, color, level, name, questID))
	end
	
	OdyTooltip:Show()
end

local function Mailbox_OnEnter(frame)
	local id = frame:GetID()
	local pos = id % 100
	local zoneID = floor((id % 10000) / 100)
	local continentID = floor(id/10000)

	local loc = addon:GetPOILocations(continentID, zoneID, POI_MAILBOX)
	if loc and loc[pos] then
		OdyTooltip:ClearLines();    	-- must be cleared and anchored to work
		OdyTooltip:SetOwner(frame, "ANCHOR_RIGHT");
		OdyTooltip:AddDoubleLine(MINIMAP_TRACKING_MAILBOX, 
			format("%s%2.1f %s%2.1f", WHITE.."x:"..CYAN, loc[pos].x, WHITE.."y:"..CYAN, loc[pos].y) )
		OdyTooltip:Show()
	end
end

-- *** OnLeave ***
local function HideTooltip()
	OdyTooltip:Hide()
end

-- ***  Show functions ***
local function ShowQuestGivers(continentID, zoneID)
	ResetButtonCount()
	
	local button, texture
	for _, npcID in pairs(addon:GetNPCListByZone(continentID, zoneID)) do		-- browse all NPC's in the zone
		if addon:NPCIsQuestGiver(npcID) then
			local locationTable = addon:GetNPCLocationTable(npcID, continentID, zoneID)
			if #locationTable > 0 then
				local x = locationTable[1].x
				local y = locationTable[1].y
		
				button, texture = DrawButton(x, y, "Interface\\Minimap\\OBJECTICONS", 16, 16)
				texture:SetTexCoord(0.125, 0.250, 0.25, 0.5);
				button:SetID(npcID)
				button:SetScript("OnClick", NPCButton_OnClick)
				button:SetScript("OnEnter", QuestGiver_OnEnter)
				button:SetScript("OnLeave", HideTooltip)
				button.xLoc = x
				button.yLoc = y
			end
		end
	end
	HideUnusedButtons()
end

local function ShowFlightMasters(continentID, zoneID)
	ResetButtonCount()
	
	local button, texture
	for _, npcID in pairs(addon:GetNPCListByZone(continentID, zoneID)) do		-- browse all NPC's in the zone
		if addon:NPCIsFlightMaster(npcID) then
			local locationTable = addon:GetNPCLocationTable(npcID, continentID, zoneID)
			if #locationTable > 0 then
				local x = locationTable[1].x
				local y = locationTable[1].y
		
				button, texture = DrawButton(x, y, "Interface\\Minimap\\OBJECTICONS", 16, 16)
				texture:SetTexCoord(0.625, 0.750, 0.25, 0.5)
				button:SetID(npcID)
				button:SetScript("OnClick", NPCButton_OnClick)
				button:SetScript("OnEnter", FlightMaster_OnEnter)
				button:SetScript("OnLeave", HideTooltip)
				button.xLoc = x
				button.yLoc = y
			end
		end
	end
	HideUnusedButtons()
end

local function ShowInnkeepers(continentID, zoneID)
	ResetButtonCount()
	
	local button, texture
	for _, npcID in pairs(addon:GetNPCListByZone(continentID, zoneID)) do		-- browse all NPC's in the zone
		if addon:NPCIsInnkeeper(npcID) then
			local locationTable = addon:GetNPCLocationTable(npcID, continentID, zoneID)
			if #locationTable > 0 then
				local x = locationTable[1].x
				local y = locationTable[1].y
		
				button, texture = DrawButton(x, y, ICON_INNKEEPERS, 16, 16)
				texture:SetTexCoord(0, 1, 0, 1)
				button:SetID(npcID)
				button:SetScript("OnClick", NPCButton_OnClick)
				button:SetScript("OnEnter", Innkeeper_OnEnter)
				button:SetScript("OnLeave", HideTooltip)
				button.xLoc = x
				button.yLoc = y
			end
		end
	end
	HideUnusedButtons()
end

local function ShowMailboxes(continentID, zoneID)
	ResetButtonCount()
	
	local locationTable = addon:GetPOILocations(continentID, zoneID, POI_MAILBOX)
	if not locationTable then
		HideUnusedButtons()
		return
	end

	local button, texture

	for index, location in pairs(locationTable) do
		button, texture = DrawButton(location.x, location.y, ICON_MAILBOXES, 16, 16)
		texture:SetTexCoord(0, 1, 0, 1);
		button:SetID((continentID*10000)+(zoneID*100)+index)
		button:SetScript("OnClick", MailBox_OnClick)
		button:SetScript("OnEnter", Mailbox_OnEnter)
		button:SetScript("OnLeave", HideTooltip)
	end
	
	HideUnusedButtons()
end

local function ShowClassTrainers(continentID, zoneID)
	ResetButtonCount()
	
	local trainers = UIDropDownMenu_GetSelectedValue(OdysseyTabMapsRightClickMenu1)
	local NPCType, NPCTypeExt
	local button, texture
	local tc
	
	for _, npcID in pairs(addon:GetNPCListByZone(continentID, zoneID)) do		-- browse all NPC's in the zone
		NPCType, NPCTypeExt = addon:GetNPCType(npcID)
	
		if NPCType and NPCTypeExt and NPCType == NPC_CLASS_TRAINER then
			if trainers == 0 or (NPCTypeExt == (trainers-1)) then		-- if all trainers, or just the specific one we want .. proceed
				local locationTable = addon:GetNPCLocationTable(npcID, continentID, zoneID)
				if #locationTable > 0 then
					local x = locationTable[1].x
					local y = locationTable[1].y
					
					button, texture = DrawButton(x, y, ICON_CLASSES, 16, 16)
					tc = CLASS_ICON_TCOORDS[addon:GetEnglishClass(NPCTypeExt+1)]
					texture:SetTexCoord(tc[1], tc[2], tc[3], tc[4])
					
					button:SetID(npcID)
					button:SetScript("OnClick", NPCButton_OnClick)
					button:SetScript("OnEnter", Innkeeper_OnEnter)
					button:SetScript("OnLeave", HideTooltip)
					button.xLoc = x
					button.yLoc = y
				end
			end
		end
	end
	HideUnusedButtons()
end

local function ShowProfessionTrainers(continentID, zoneID)
	ResetButtonCount()
	
	local trainers = UIDropDownMenu_GetSelectedValue(OdysseyTabMapsRightClickMenu2)
	local NPCType, NPCTypeExt
	local button, texture
	local tc
	
	for _, npcID in pairs(addon:GetNPCListByZone(continentID, zoneID)) do		-- browse all NPC's in the zone
		NPCType, NPCTypeExt = addon:GetNPCType(npcID)
	
		if NPCType and NPCTypeExt and NPCType == NPC_PROFESSION_TRAINER then
			if trainers == 0 or (NPCTypeExt == (trainers-1)) then		-- if all trainers, or just the specific one we want .. proceed
				local locationTable = addon:GetNPCLocationTable(npcID, continentID, zoneID)
				if #locationTable > 0 then
					local x = locationTable[1].x
					local y = locationTable[1].y
					
					button, texture = DrawButton(x, y, addon:GetSpellIcon(addon:GetTrainerSpellID(NPCTypeExt+1)), 16, 16)
					texture:SetTexCoord(0, 1, 0, 1)
				
					button:SetID(npcID)
					button:SetScript("OnClick", NPCButton_OnClick)
					button:SetScript("OnEnter", Innkeeper_OnEnter)
					button:SetScript("OnLeave", HideTooltip)
					button.xLoc = x
					button.yLoc = y
				end
			end
		end
	end
	HideUnusedButtons()
end

local function ShowUtilityNPCs(continentID, zoneID)
	ResetButtonCount()
	
	-- local poiTypes = {}
	-- local trainers = UIDropDownMenu_GetSelectedValue(OdysseyTabMapsRightClickMenu3)
	-- if trainers == 0 then
		-- for i = 4, 9 do	table.insert(poiTypes, i) end
		-- for i = 81, 86 do	table.insert(poiTypes, i) end
	-- else
		-- table.insert(poiTypes, trainers)
	-- end
	
	-- local npcID
	-- local button, texture
	
	-- for _, poiType in pairs(poiTypes) do
		-- local locationTable = addon:GetPOILocations(continentID, zoneID, poiType)
		-- local NPCList = addon:GetPOIRawLocations(continentID, zoneID, poiType)
		
		-- if locationTable and NPCList then
			-- for index, location in pairs(locationTable) do
				-- button, texture = DrawButton(location.x, location.y, addon:GetPOIIconPath(poiType), 16, 16)
				-- if poiType == 7 then	-- exception : barber is a dwarf icon :D, so different texcoords
					-- texture:SetTexCoord(0.125, 0.250, 0, 0.250);
				-- else
					-- texture:SetTexCoord(0, 1, 0, 1);
				-- end
				
				-- npcID = select(index, strsplit("`", NPCList))
				-- button:SetID(tonumber(npcID) or 0)
				-- button:SetScript("OnClick", NPCButton_OnClick)
				-- button:SetScript("OnEnter", Innkeeper_OnEnter)
				-- button:SetScript("OnLeave", HideTooltip)
			-- end
		-- end
	-- end
	HideUnusedButtons()
end

local function ShowBattleMasters(continentID, zoneID)
	ResetButtonCount()
	
	local poiTypes = {}
	local battelMasters = UIDropDownMenu_GetSelectedValue(OdysseyTabMapsRightClickMenu4)
	if battelMasters == 0 then
		for index, _ in ipairs(addon:GetBattleMasterList()) do
			table.insert(poiTypes, index)
		end
	else
		table.insert(poiTypes, battelMasters)
	end
	
	for _, npcID in pairs(addon:GetNPCListByZone(continentID, zoneID)) do
		NPCType, NPCTypeExt = addon:GetNPCType(npcID)
	
		if NPCType and NPCTypeExt and NPCType == NPC_BATTLEMASTER then
			if battelMasters == 0 or (NPCTypeExt == (battelMasters-1)) then		-- if all battelMasters, or just the specific one we want .. proceed
				local locationTable = addon:GetNPCLocationTable(npcID, continentID, zoneID)
				if #locationTable > 0 then
					local x = locationTable[1].x
					local y = locationTable[1].y
			
					button, texture = DrawButton(x, y, ICON_BATTLEMASTERS, 16, 16)
					texture:SetTexCoord(0, 1, 0, 1)
					button:SetID(npcID)
					button:SetScript("OnClick", NPCButton_OnClick)
					button:SetScript("OnEnter", Innkeeper_OnEnter)
					button:SetScript("OnLeave", HideTooltip)
					button.xLoc = x
					button.yLoc = y
				end
			end
		end
	end
	
	HideUnusedButtons()
end

local function ShowSearchResults(continentID, zoneID)
	if not searchResults then return end
	ResetButtonCount()
	
	local button, texture
	local left, right, top, bottom
	
	for _, result in pairs(searchResults) do
		if result.resultType == SEARCH_TYPE_QUESTSTARTER then
			left, right, top, bottom = 0.125, 0.250, 0.25, 0.5
		elseif result.resultType == SEARCH_TYPE_QUESTENDER then
			left, right, top, bottom = 0.250, 0.375, 0.25, 0.5
		end
		
		local locationTable = addon:GetNPCLocationTable(result.id, continentID, zoneID)
		for _, location in pairs(locationTable) do
			button, texture = DrawButton(location.x, location.y, "Interface\\Minimap\\OBJECTICONS", 16, 16)
	
			texture:SetTexCoord(left, right, top, bottom);
			button:SetID(result.id)
			button:SetScript("OnClick", NPCButton_OnClick)
			button:SetScript("OnEnter", QuestGiver_OnEnter)
			button:SetScript("OnLeave", HideTooltip)
			button.xLoc = location.x
			button.yLoc = location.y
		end
	end
	HideUnusedButtons()
end

local views = {
	ShowQuestGivers,
	ShowFlightMasters,
	ShowInnkeepers,
	ShowMailboxes,
	ShowClassTrainers,
	ShowProfessionTrainers,
	ShowUtilityNPCs,
	ShowBattleMasters,
	ShowSearchResults,
}

local overlayFrames = {}		-- the overlay textures of a zone are into a common frame, these frames are saved into this table
local currentFrame

addon.ZoneMaps = {}

local ns = addon.ZoneMaps		-- ns = namespace

function ns:Draw(continentID, zoneID, selectedView)
	currentContinent = continentID
	currentZone = zoneID
	
	if currentFrame then
		currentFrame:Hide()
	end
	
	-- Draw the background map
	local zone = addon:GetZoneHighlight(continentID, zoneID)
	local tex
	--for i = 1, NUM_WORLDMAP_DETAIL_TILES do
	for i = 1, 12 do
		tex = addon:GetZoneTexture(continentID, zoneID, i)
		local t = _G["OdysseyFrameZoneMapsTile" ..i]
		t:SetTexture(tex);
	end
	
	-- Draw overlays
	local f = addon:InitZoneOverlays(zone, "OdyZoneMap_", overlayFrames, OdysseyFrameZoneMaps)
	
	f:SetPoint("TOPLEFT", OdysseyFrameZoneMapsTile1, "TOPLEFT", 0, 0)
	f:SetScale(MAP_SCALE)
	f:Show()
	currentFrame = f
	
	if selectedView and views[selectedView] then
		views[selectedView](continentID, zoneID)
	end
end

function ns:ResetSearchResults()
	searchResults = searchResults or {}
	wipe(searchResults)
end

function ns:AddQuestStarter(npcID)
	table.insert(searchResults, {	resultType = SEARCH_TYPE_QUESTSTARTER, id = npcID })
end

function ns:AddQuestEnder(npcID)
	table.insert(searchResults, {	resultType = SEARCH_TYPE_QUESTENDER, id = npcID })
end

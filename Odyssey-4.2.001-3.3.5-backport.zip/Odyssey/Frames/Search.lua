local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local GREEN		= "|cFF00FF00"
local TEAL		= "|cFF00FF9A"
local RED		= "|cFFFF0000"

local ICON_QUESTGIVERS = "Interface\\LFGFrame\\LFGIcon-Quest"
local ICON_NPC = "Interface\\TutorialFrame\\TutorialFrame-QuestionMark"

local RESULT_TYPE_QUEST			= 1
local RESULT_TYPE_NPC			= 2
local RESULT_TYPE_ZONE			= 3

-- ** Results **
local results

local function ClearResults()
	results = results or {}
	wipe(results)
end

local function AddResult(t)
	table.insert(results, t)
end

local function GetNumResults()
	return #results or 0
end

local function GetResult(n)
	if n then
		return results[n]
	end
end

addon.Search = {}

local ns = addon.Search		-- ns = namespace

function ns:Update()
	local VisibleLines = 7
	local frame = "OdysseyFrameSearch"
	local entry = frame.."Entry"
	
	local numResults = GetNumResults()
	
	if numResults == 0 then
		addon:ClearScrollFrame( _G[ frame.."ScrollFrame" ], entry, VisibleLines, 41)
		return
	end

	local offset = FauxScrollFrame_GetOffset( _G[ frame.."ScrollFrame" ] );
	
	local texture, name, location
	local continent, zone
	
	for i=1, VisibleLines do
		local line = i + offset
		local result = GetResult(line)

		if result then
			if result.Type == RESULT_TYPE_QUEST then
				texture = ICON_QUESTGIVERS
				name = addon:GetQuestName(result.questID)
				local _, startID, startType = addon:GetQuestStarter(result.questID)
				if startID and startType == 1 then
					continent, zone = addon:GetNPCLocation(startID)
				end
				
			elseif result.Type == RESULT_TYPE_NPC then
				texture = ICON_NPC
				name = addon:GetNPCName(result.npcID)
				continent, zone = addon:GetNPCLocation(result.npcID)
				
			elseif result.Type == RESULT_TYPE_ZONE then
				
				texture = addon:GetZoneIcon(result.continentID, result.zoneID)
				name = addon:GetZoneName(result.continentID, result.zoneID)
			end
			
			_G[ entry..i.."ItemIconTexture" ]:SetTexture(texture);
			_G[ entry..i.."Name" ]:SetText(name)

			local continentName = addon:GetContinentName(continent)
			local zoneName = addon:GetZoneName(continent, zone)
			if continentName and zoneName then
				location = TEAL .. zoneName .. ", " ..continentName
			else
				location = RED .. L["Unknown location"]
			end
			
			_G[ entry..i.."Location" ]:SetText(location)
			_G[ entry..i.."Item" ]:SetID(line)
			_G[ entry..i ]:Show()
		else
			_G[ entry..i ]:Hide()
		end
	end

	local last
	if (offset+VisibleLines) <= numResults then
		last = offset+VisibleLines
	else
		last = numResults
	end
	
	local found = format(L["%s results found"], GREEN..numResults.. "|r" )
	if numResults > 0 then
		found = found .. " " .. format( L["(Showing %d-%d)"], offset+1, last )
	end
	OdysseyTabSearchStatus:SetText(found)
	
	FauxScrollFrame_Update( _G[ frame.."ScrollFrame" ], numResults, VisibleLines, 41);
	
	if not OdysseyFrameSearch:IsVisible() then
		OdysseyFrameSearch:Show()
	end
end

local ongoingSearch

function ns:Find()
	if ongoingSearch then
		return		-- if a search is already happening .. then exit
	end
	ongoingSearch = true
	
	local value = OdysseyFrame_SearchEditBox:GetText()
	if not value or strlen(value) == 0 then return end
	
	local searchString = strlower(value)			-- the value being searched
	ClearResults()
	
	-- quests
	for id, name in pairs(addon:GetQuestList()) do
		if string.find(strlower(name), searchString, 1, true) ~= nil then
			AddResult( { Type = RESULT_TYPE_QUEST, questID = id } )
		end
	end
	
	-- npcs
	
	for id, name in pairs(addon:GetNPCList()) do
		if string.find(strlower(name), searchString, 1, true) ~= nil then
			AddResult( { Type = RESULT_TYPE_NPC, npcID = id } )
		end		
	end
	
	-- zones
	for continentID = 1, addon:GetNumContinents() do
		for zoneID = 1, addon:GetNumZones(continentID) do
			-- zone names
			if string.find(strlower(addon:GetZoneName(continentID, zoneID)), searchString, 1, true) ~= nil then
				AddResult( { Type = RESULT_TYPE_ZONE, ["continentID"] = continentID, ["zoneID"] = zoneID, } )
			end
		end
	end
	
	-- POI
	-- for id, name in pairs() do
		-- if string.find(strlower(name), searchString, 1, true) ~= nil then
			-- DEFAULT_CHAT_FRAME:AddMessage(name)
		-- end
	-- end
	
	ongoingSearch = nil 	-- search done
	
	if not OdysseyTabSearch:IsVisible() then
		addon.Tabs:OnClick("Search")
	end
	ns:Update()
end

function ns:ClearResults()
	ClearResults()
end

function ns:Item_OnEnter(frame)
	local result = GetResult(frame:GetID())
	
	if result.Type == RESULT_TYPE_QUEST then
		addon:ShowQuestTooltip(frame, result.questID)
	elseif result.Type == RESULT_TYPE_NPC then
		addon:ShowNPCTooltip(frame, result.npcID)
	end
end

function ns:Item_OnClick(frame, button)
	local result = GetResult(frame:GetID())
	local continentID = result.continentID
	local zoneID = result.zoneID
	
	if result.Type == RESULT_TYPE_QUEST and button == "LeftButton" then
		local questID = result.questID
		
		if IsShiftKeyDown() then			-- link to chat ..
			addon:LinkQuestToChat(questID)
			return
		end
		
		-- ..or send to quest details
		addon.Quests.Details:SetQuestID(questID)
		addon.Tabs:OnClick("Quests")
		addon.Tabs.Quests:MenuItem_OnClick("QuestDetails")
		
	elseif result.Type == RESULT_TYPE_NPC then
		local npcID = result.npcID

		if button == "LeftButton" then 
			local continentID, zoneID = addon:GetNPCLocation(npcID)
			addon.Tabs.Maps:ShowNPC(continentID, zoneID, npcID, "questStarter")		-- todo : replace "questStarter" by a simple dot on the map, the green/yellow one
		elseif button == "RightButton" then
			addon:AddNPCToTomTom(npcID)
		end
	end
end

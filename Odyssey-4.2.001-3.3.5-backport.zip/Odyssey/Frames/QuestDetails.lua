local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

local WHITE		= "|cFFFFFFFF"
local GREEN		= "|cFF00FF00"
local YELLOW	= "|cFFFFFF00"
local RED		= "|cFFFF0000"

local NUM_ICONS = 8		-- number of icons for rewards & choices

local ACTOR_UNKNOWN = 0
local ACTOR_NPC = 1
local ACTOR_OBJECT = 2
local ACTOR_ITEM = 3

local actorLabels = {
	[ACTOR_OBJECT] = "Object",
	[ACTOR_ITEM] = "Item",
}

local currentQuestID
local parent = "OdysseyFrameQuestDetails"
local browsingHistory
local currentQuestIndex		-- which quest in the browsingHistory are we showing.

local function HideIconsFrom(index, itemType)
	while index <= NUM_ICONS do
		_G[ parent..itemType..index ]:Hide()
		index = index + 1
	end
end

local function GetActorLocationText(actorType, actorID)
	local mainCatName, subCatName, isDuplicated  = addon:GetActorLocationText(actorType, actorID)
	
	if mainCatName and subCatName then
		return format("%s, %s", YELLOW..subCatName, mainCatName)
	else
		if isDuplicated then
			return WHITE .. "Multiple locations"
		end
	end
	
	return RED .. L["Unknown location"]
end

local function DisplayButtonBorder(frame, itemID)
	if not itemID then return end
	
	addon:CreateButtonBorder(frame)
	
	local _, _, rarity = GetItemInfo(itemID)
	if rarity and rarity >= 2 then
		local r, g, b = GetItemQualityColor(rarity)
		frame.border:SetVertexColor(r, g, b, 0.5)
		frame.border:Show()
	else
		frame.border:Hide()
	end
end

local function DisplayItemCount(frame, count)
	if count and count > 1 then
		frame:SetText(count);
		frame:Show();
	else
		frame:Hide();
	end
end

local function DisplayIconList(list, itemType)
	local index = 1
	local itemName, itemButton
	
	for _, listValue in pairs(list) do
		itemName = parent..itemType..index
		itemButton = _G[itemName]
		
		local itemID, qty = strsplit(":", listValue)
		itemID = tonumber(itemID)
		qty = tonumber(qty) or 1

		itemButton:SetID(itemID)
		addon:SetItemButtonTexture(itemName, GetItemIcon(itemID), 18, 18);
		
		DisplayButtonBorder(itemButton, itemID)
		DisplayItemCount(_G[itemName .. "Count"], qty)
		
		itemButton:Show()
		index = index + 1
	end
	HideIconsFrom(index, itemType)
end



local function DisplayQuestStarter(frame, questID)
	local name, id, actorType = addon:GetQuestStarter(questID)
	
	frame:SetID(id or 0)
	frame.actorType = actorType
	
	if actorLabels[actorType] then
		name = format("%s%s: %s", WHITE, actorLabels[actorType], name or id)
	end
	
	local loc = GetActorLocationText(frame.actorType, id)
	local frameName = frame:GetName()
	_G[frameName.."NormalText"]:SetText(format("%s:|r %s\n  %s", WHITE..L["Starts"], name or (RED..L["N/A"]), loc ))
end

local function DisplayQuestEnder(frame, questID)
	local name, id, actorType = addon:GetQuestEnder(questID)
	
	frame:SetID(id or 0)
	frame.actorType = actorType
	
	if actorLabels[actorType] then
		name = format("%s%s: %s", WHITE, actorLabels[actorType], name or id)
	end
	
	local loc = GetActorLocationText(frame.actorType, id)
	local frameName = frame:GetName()
	_G[frameName.."NormalText"]:SetText(format("%s:|r %s\n  %s", WHITE..L["Ends"], name or (RED..L["N/A"]), loc ))
end

addon.Quests.Details = {}

local ns = addon.Quests.Details		-- ns = namespace

function ns:Update()
	local questID = currentQuestID
	if not questID then return end

	if currentQuestIndex == 1 then
		OdysseyFrameQuestDetailsGoBack:Disable()
	else
		OdysseyFrameQuestDetailsGoBack:Enable()
	end
	
	if currentQuestIndex == #browsingHistory then
		OdysseyFrameQuestDetailsGoForward:Disable()
	else
		OdysseyFrameQuestDetailsGoForward:Enable()
	end
	
	local title = addon:GetQuestName(questID)
	_G[ parent .. "QuestTitle"]:SetText(title)
	
	local level = addon:GetQuestLevel(questID)
	local side = addon:GetQuestFaction(questID)
	_G[ parent .. "QuestInfo"]:SetText(format("%s: %s    %s: %s    %s: %s", WHITE..LEVEL, GREEN..level, WHITE.."ID", GREEN..questID, WHITE.."Side", addon:GetSideIcon(side)))
	
	local desc = format("%s:\n", L["Description"])
	local link = addon:GetQuestLink(questID)
	if link then
		OdyTooltip:ClearLines();
		OdyTooltip:SetOwner(OdysseyFrame, "ANCHOR_LEFT");
		OdyTooltip:SetHyperlink(link)
		
		local color
		for i = 2, OdyTooltip:NumLines() do
			local tooltipLine = _G[ "OdyTooltipTextLeft" .. i]:GetText()
			if tooltipLine then
				if tooltipLine == QUEST_TOOLTIP_REQUIREMENTS then
					color = "|r"
				else
					color = WHITE
				end
				desc = format("%s%s%s\n", desc, color, tooltipLine)
			end
		end
		_G[ parent .. "QuestDesc"]:SetText(desc)
		OdyTooltip:Hide();	-- mandatory hide after processing	
	end
	
	-- ** rewards **
	local rewards = addon:GetQuestRewards(questID)
	if rewards then
		DisplayIconList(rewards, "Reward")
		_G[ parent .. "QuestRewards"]:SetText(format("%s:", L["Quest Rewards"]))
	else
		HideIconsFrom(1, "Reward")
		_G[ parent .. "QuestRewards"]:SetText(format("%s: %s", L["Quest Rewards"], WHITE..NONE))
	end
	
	-- ** choices **
	local choices = addon:GetQuestChoices(questID)
	if choices then
		DisplayIconList(choices, "Choice")
		_G[ parent .. "QuestChoices"]:SetText(format("%s:", L["Quest Choices"]))
	else
		HideIconsFrom(1, "Choice")
		_G[ parent .. "QuestChoices"]:SetText(format("%s: %s", L["Quest Choices"], WHITE..NONE))
	end
	
	-- ** Start / End NPC **
	DisplayQuestStarter(_G[parent.."Starts"], questID)
	DisplayQuestEnder(_G[parent.."Ends"], questID)
	
	-- ** Series **
	ns:UpdateSeries()
end

local view

local function BuildView(first)
	view = view or {}
	wipe(view)
	
	for _, id in ipairs(addon:GetQuestSeries(first)) do			-- peruse the series
		table.insert(view, id)
	end
end

function ns:UpdateSeries()
	local frame = parent .. "Series"
	
	local VisibleLines = 6
	local questID = currentQuestID
	local first, pos, seriesLength = addon:GetSeriesInfo(questID)
	
	if not first then		-- if quest is part of a series ..
		_G[ frame .. "Title" ]:Hide()
		_G[ frame ]:Hide()
		return
	end
	
	_G[ frame .. "Title" ]:SetText(format("%s (%d/%d)", L["This quest is part of a series"], pos, seriesLength))
	_G[ frame .. "Title" ]:Show()
	_G[ frame ]:Show()
	
	local entry = frame.."Entry"
	local offset = FauxScrollFrame_GetOffset( _G[ frame.."ScrollFrame" ] );
	local i=1
	
	BuildView(first)
	
	local line, lineQuestID
	local name, level, color
	
	for index = 1, VisibleLines do
		if i > #view then
			break
		end
		
		line = index + offset
		lineQuestID = view[line]
		
		name = addon:GetQuestName(lineQuestID) or L["Quest name missing"]
		level = addon:GetQuestLevel(lineQuestID)
		
		if questID == lineQuestID then
			color = WHITE
		else
			color = ""
		end
		
		_G[entry..i.."NameNormalText"]:SetText(format("%s)|r %s\[%d\] %s", GREEN..line, color, level, name))
		_G[entry..i.."Name"]:SetID(lineQuestID)
		
		_G[ entry..i ]:SetID(line)
		_G[ entry..i ]:Show()
		i = i + 1
	end
	
	while i <= VisibleLines do
		_G[ entry..i ]:SetID(0)
		_G[ entry..i ]:Hide()
		i = i + 1
	end

	FauxScrollFrame_Update( _G[ frame.."ScrollFrame" ], seriesLength, VisibleLines, 18);
end

function ns:Series_OnClick(frame, button)
	if button ~= "LeftButton" then return end
	
	local questID = frame:GetID()
	if IsShiftKeyDown() then
		addon:LinkQuestToChat(questID)
		return
	end
		
	if questID ~= currentQuestID then
		ns:SetQuestID(questID)
		ns:Update()
	end
end

function ns:NPC_OnClick(frame, button, npcType)
	local npcID = frame:GetID()
	if button == "LeftButton" then 
		local continentID, zoneID = addon:GetNPCLocation(npcID)
		addon.Tabs.Maps:ShowNPC(continentID, zoneID, npcID, npcType)
	elseif button == "RightButton" then
		addon:AddNPCToTomTom(npcID)
	end
end

function ns:SetQuestID(id, useHistory)
	currentQuestID = id
	browsingHistory = browsingHistory or {}
	
	if not useHistory then		-- if we don't use the history, id contains the questID
		table.insert(browsingHistory, id)
		currentQuestIndex = #browsingHistory
	end
end

function ns:GoBack()
	currentQuestIndex = currentQuestIndex - 1
	if currentQuestIndex < 1 then
		currentQuestIndex = 1
	end
	ns:UseHistoryItem(currentQuestIndex)
	ns:Update()
end

function ns:GoForward()
	currentQuestIndex = currentQuestIndex + 1
	if currentQuestIndex > #browsingHistory then
		currentQuestIndex = #browsingHistory
	end
	ns:UseHistoryItem(currentQuestIndex)
	ns:Update()
end

function ns:UseHistoryItem(index)
	currentQuestID = browsingHistory[index]
end

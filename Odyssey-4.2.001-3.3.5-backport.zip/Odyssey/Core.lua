﻿local addonName = ...

_G[addonName] = LibStub("AceAddon-3.0"):NewAddon(addonName, "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")

local addon = _G[addonName]

addon.Version = "v4.2.001"
addon.VersionNum = 402001

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)

BINDING_HEADER_ODYSSEY = addonName;
BINDING_NAME_ODYSSEY_TOGGLE = "Toggle UI";
BINDING_NAME_ODYSSEY_TOGGLEMAP = "Toggle Map";

local options = { 
	type= "group",
	args = {
		show = {
			type = "execute",
			name = L['show'],
			desc = L["Shows the UI"],
			func = function() OdysseyFrame:Show() end
		},
		hide = {
			type = "execute",
			name = L['hide'],
			desc = L["Hides the UI"],
			func = function() OdysseyFrame:Hide() end
		},
		toggle = {
			type = "execute",
			name = L['toggle'],
			desc = L["Toggles the UI"],
			func = function() addon:ToggleUI() end
		},
		-- showmap = {
			-- type = "execute",
			-- name = L['showmap'],
			-- desc = L["Shows the map"],
			-- func = function() OdyMapFrame:Show() end
		-- },
		-- hidemap = {
			-- type = "execute",
			-- name = L['hidemap'],
			-- desc = L["Hides the map"],
			-- func = function() OdyMapFrame:Hide() end
		-- },

	},
}

local AddonDB_Defaults = {
	global = {
		options = {
			MinimapIconAngle = 300,
			MinimapIconRadius = 78,
			ShowMinimap = 1,
			UIScale = 1.0,
			UITransparency = 1.0,
			ShowLevelZeroQuests = 0,			-- do not list level 0 quests (ex: in the database)
			
			TooltipSeries = 1,					-- show quest series in the tooltip
			TooltipQuestType = 1,				-- show quest type info in the tooltip (pvp, repeatable, etc..)
			TooltipQuestRewards = 1,			-- show quest reward info in the tooltip
			TooltipQuestChoices = 1,			-- show quest choices info in the tooltip
			TooltipQuestCompletedBy = 1,		-- show which other alts have completed a quest
		},
		data = {
			DataA = 0,
		},
		Collect = {},
	}
}

-- ** LDB Launcher **
LibStub:GetLibrary("LibDataBroker-1.1"):NewDataObject(addonName, {
	type = "launcher",
	icon = "Interface\\Icons\\Spell_Arcane_TeleportTheramore",
	OnClick = function(clickedframe, button)
		addon:ToggleUI()
	end,
	text = (Broker2FuBar) and addonName or nil,		-- only for fubar,  not for ldb
	label = addonName,
})

function addon:OnInitialize()
	addon.db = LibStub("AceDB-3.0"):New(addonName .. "DB", AddonDB_Defaults)
	LibStub("AceConfig-3.0"):RegisterOptionsTable(addonName, options)

	addon:RegisterChatCommand("Odyssey", "ChatCommand")
	addon:RegisterChatCommand("Ody", "ChatCommand")
	
	addon:RegisterMessage("DATASTORE_QUEST_TURNED_IN")
end

function addon:ChatCommand(input)
	if not input then
		LibStub("AceConfigDialog-3.0"):Open(addonName)
	else
		LibStub("AceConfigCmd-3.0").HandleCommand(addon, "Ody", "Odyssey", input)
	end
end

addon.Quests = {}  -- to do: check if this is still used.

-- ** Tabs **
local tabList = {
	"Quests",
	"Maps",
	"Search",
}

local frameToID = {}
for index, name in ipairs(tabList) do
	frameToID[name] = index
end

addon.Tabs = {}

function addon.Tabs:HideAll()
	for _, tabName in pairs(tabList) do
		_G[addonName.."Tab" .. tabName]:Hide();
	end
end

function addon.Tabs:OnClick(index)
	if type(index) == "string" then
		index = frameToID[index]
	end

	PanelTemplates_SetTab(_G[addonName.."Frame"], index);
	self:HideAll()
	self.current = index
	self.Columns.prefix = addonName.."Tab"..tabList[index].."_Sort"
	_G[addonName.."Tab" .. tabList[index]]:Show()
end

addon.Tabs.Columns = {}

function addon.Tabs.Columns:Init()
	local i = 1
	local prefix = self.prefix or "OdysseyTabQuests_Sort"
	local button = _G[ prefix .. i ]
	local arrow = _G[ prefix .. i .. "Arrow"]
	
	while button do
		arrow:Hide()
		button.ascendingSort = nil		-- not sorted by default
		button:Hide()
		
		i = i + 1
		button = _G[ prefix .. i ]
		arrow = _G[ prefix .. i .. "Arrow"]
	end
	self.count = 0
	self.prefix = prefix
end

function addon.Tabs.Columns:Add(title, width, func)
	local prefix = self.prefix
	self.count = self.count + 1
	local button = _G[ prefix..self.count ]

	if not title then		-- no title ? count the column, but hide it
		button:Hide()
		return
	end
	
	button:SetText(title)
	button:SetWidth(width)
	button:SetScript("OnClick", function(self)
			local prefix = addon.Tabs.Columns.prefix
			local i = 1
			local arrow = _G[ prefix .. i .. "Arrow"]
			
			while arrow do		-- hide all arrows
				arrow:Hide()
				i = i + 1
				arrow = _G[ prefix .. i .. "Arrow"]
			end

			arrow = _G[ prefix .. self:GetID() .. "Arrow"]
			arrow:Show()	-- show selected arrow
			
			if not self.ascendingSort then
				self.ascendingSort = true
				arrow:SetTexCoord(0, 0.5625, 1.0, 0);		-- arrow pointing up
			else
				self.ascendingSort = nil
				arrow:SetTexCoord(0, 0.5625, 0, 1.0);		-- arrow pointing down
			end
	
			func(self)
		end)
	button:Show()
end

tinsert(UISpecialFrames, "OdysseyFrame");

﻿--[[	*** Odyssey ***
Written by : Thaoky, EU-Marécages de Zangar
Started on :March 31, 2009
--]]

local addonName = ...
local addon = _G[addonName]

local VIEW_UNFINISHED_QUESTS = 1
local VIEW_FINISHED_QUESTS = 2
local VIEW_ALL_QUESTS = 3

local filters = {}

-- quest filtering functions
local function FilterCompleted(questID)
	local completed = DataStore:IsQuestCompletedBy(filters["Character"], questID)
	if filters["Status"] == VIEW_UNFINISHED_QUESTS and not completed then
		return true
	elseif filters["Status"] == VIEW_FINISHED_QUESTS and completed then
		return true
	end
end

local function FilterMinimumLevel(questID)
	local level = addon:GetQuestLevel(questID)
	if level >= filters["MinLevel"] then
		return true		-- keep the quest if level is known and above minimum
	end
end

local function FilterMaximumLevel(questID)
	local level = addon:GetQuestLevel(questID)
	if level <= filters["Maxlevel"] then
		return true		-- keep the quest if level is known and above maximum
	end
end

local function FilterRepeatable(questID)
	return not addon:IsQuestRepeatable(questID)
end

local function FilterDailies(questID)
	return not addon:IsQuestDaily(questID)
end

local function FilterWeeklies(questID)
	return not addon:IsQuestWeekly(questID)
end

local function FilterDungeons(questID)
	return not addon:IsDungeonQuest(questID)
end

local function FilterRaid(questID)
	return not addon:IsRaidQuest(questID)
end

local function FilterPVP(questID)
	return not addon:IsPVPQuest(questID)
end

local function FilterStartedByItem(questID)
	return not addon:IsStartedByItem(questID)
end

local function FilterNoXP(questID)
	return not addon:IsQuestGivingNoXP(questID)
end

local function FilterGoTo(questID)
	return not addon:IsGoToQuest(questID)
end

local function FilterFaction(questID)
	local side = addon:GetQuestFaction(questID)
	if filters["Faction"] == side or side == 3 then
		return true	-- keep the quest if same side
	end	
end

local function FilterRace(questID)
	local races = addon:IsRaceQuest(questID)
	if not races or races:find(filters["Race"]) then
		return true	-- if it's not a race quest, or if it is for our race, keep it
	end
end

local filterFunctions = {
	["Completed"] = FilterCompleted,
	["MinLevel"] = FilterMinimumLevel,
	["Maxlevel"] = FilterMaximumLevel,
	["Repeatable"] = FilterRepeatable,
	["Daily"] = FilterDailies,
	["Weekly"] = FilterWeeklies,
	["Dungeon"] = FilterDungeons,
	["Raid"] = FilterRaid,
	["PVP"] = FilterPVP,
	["StartedByItem"] = FilterStartedByItem,
	["NoXP"] = FilterNoXP,
	["GoTo"] = FilterGoTo,
	["Faction"] = FilterFaction,
	["Race"] = FilterRace,
}

addon.QuestFilters = {}

local ns = addon.QuestFilters		-- ns = namespace

function ns:SetFilterValue(field, value)
	filters[field] = value
end

function ns:GetFilterValue(field)
	return filters[field]
end

function ns:EnableFilter(filter)
	if filterFunctions[filter] then
		filters.list = filters.list or {}
		table.insert(filters.list, filterFunctions[filter])
	end
end

function ns:QuestPassesFilters(questID)
	-- Exclusive approach:
	-- 	by default, it is considered that no quest if filtered out unless a specific filter is enabled.
	-- 	ex: if a user unchecks the quest type "Daily" in the UI, it means he doesn't want to see dailies, so the filter "Daily" is enabled, and all daily quests are filtered out.

	if filters.list then		-- there might not be any filter
		for _, func in pairs(filters.list) do
			if not func(questID) then		-- if any of the filters returns false/nil, exit
				return
			end
		end
	end
	return true			-- return true if all filters have returned true
end

function ns:ClearFilters()
	wipe(filters)
end

﻿local addonName = ...
local addon = _G[addonName]

local continents = {			-- continentID = GetCurrentMapContinent() 
	[1] = { icon = "Interface\\Icons\\Achievement_Zone_Kalimdor_01", map = "Kalimdor" },
	[2] = { icon = "Interface\\Icons\\Achievement_Zone_EasternKingdoms_01", map = "Azeroth" },
	[3] = { icon = "Interface\\Icons\\Achievement_Zone_Outland_01", map = "Expansion01" },
	[4] = { icon = "Interface\\Icons\\Achievement_Zone_Northrend_01", map = "Northrend" },
	--[5] = { icon = "Interface\\Icons\\Achievement_Zone_Cataclysm", map = "Northrend" },
}

local list = { GetMapContinents() };		-- this gets localized names, also avoids hardcoding them.

for index, name in ipairs(list) do
	continents[index].name = name
end
list = nil	

function addon:IsContinentIDValid(id)
	if type(id) == "number" and id > 0 and id <= addon:GetNumContinents() then
		return true
	end
end

function addon:GetNumContinents()
	return #continents
end

function addon:GetContinent(id)
	if addon:IsContinentIDValid(id) then
		return continents[id]
	end
end

function addon:GetContinentName(id)
	if addon:IsContinentIDValid(id) then
		return continents[id].name
	end
end

function addon:GetContinentMap(id)
	if addon:IsContinentIDValid(id) then
		return continents[id].map
	end
end

function addon:GetContinentIcon(id)
	if addon:IsContinentIDValid(id) then
		return continents[id].icon
	end
end

function addon:GetCurrentContinent()
	local continentID = GetCurrentMapContinent()
	if continentID and continentID >= 1 and continentID <= addon:GetNumContinents() then
		return continentID		-- value won't be acceptable if player is in a dungeon, so default it to 1
	end
	return 1	-- if no valid value, return 1
end

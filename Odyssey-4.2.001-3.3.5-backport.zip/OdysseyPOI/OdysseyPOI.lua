﻿--[[	*** OdysseyPOI ***
Written by : Thaoky, EU-Marécages de Zangar
--]]

if not Odyssey then return end

local addonName = "Odyssey"
local addon = _G[addonName]

--[[	*** API ***

	addon:GetPOITypeID(name)							returns the id of a given POI type (ex: innkeeper = id 2)
	addon:GetPOITypeName(id)							returns the name of a given POI (ex: 2 returns "innkeeper" (localized))
	addon:GetPOIEnglishClass(id)							returns the english class of a given POI (ex: 21 = mage trainer, so return "MAGE")
	addon:GetPOIProfessionID(id)							returns the profession spell id of a given POI (ex: 51 = alchemy, so return 2259)
	addon:GetPOIIconPath(id)								returns the icon path of a given POI
	addon:GetPOIList()									returns the address of the table containing the POI
	addon:GetPOIRawLocations(continentID, zoneID, poiType)	returns raw data about a given POI
	addon:GetPOILocations(continentID, zoneID, poiType)		returns a table of known locations for a given POI
	
--]]

local bAnd = bit.band
local bOr = bit.bor
local RShift = bit.rshift
local LShift = bit.lshift

local function TestBit(value, pos)
	-- note: this function works up to bit 51
	local mask = 2 ^ pos		-- 0-based indexing
	return value % (mask + mask) >= mask
end

local function RightShift(value, numBits)
	-- for bits beyond bit 31
	return math.floor(value / 2^numBits)
end


function addon:GetObjectName(id)
	if id then
		return addon.ObjectList[id]
	end
end

function addon:GetObjectList()
	return addon.ObjectList
end

function addon:GetObjectLocation(id)
	local attrib = addon.ObjectAttrib[id]
	if not attrib then return end

	local mainCat = bAnd(RShift(attrib, 2), 15)	-- mask 1111
	local subCat = bAnd(RShift(attrib, 6), 63)			-- mask 111111 .. etc
	local x = bAnd(RShift(attrib, 12), 1023) / 10
	local y = bAnd(RShift(attrib, 22), 1023) / 10
	local hasMoreCoords = TestBit(attrib, 32)
	local isDuplicated
	
	if mainCat == 0 and subCat == 0 then
		-- most NPCs are present in only one zone (although they may have multiple coordinates), those which are duplicated have both continent & zone = 0
		isDuplicated = true
	end
	
	--return addon:GetContinentName(continent), addon:GetZoneName(continent, zone), x, y, isDuplicated
	return mainCat, subCat, x, y, hasMoreCoords, isDuplicated
end

function addon:GetObjectLocationTable(id, continentID, zoneID)
	-- continentID and zoneID are optional, if specified, only return locations from that zone
	local out = {}

	local continentObject, zoneObject, x, y, _, isDuplicated = addon:GetObjectLocation(id)
	if continentObject and not isDuplicated then
		if not continentID or (continentID and continentID == continentObject and zoneID and zoneID == zoneObject) then
			table.insert(out, {
				["continentID"] = continentObject,
				["zoneID"] = zoneObject,
				["x"] = x,
				["y"] = y,
			})
		end
	end

	local loc = addon.ObjectLoc[id]
	if loc then 
		for zoneLoc in loc:gmatch("([^-]+)") do	-- zones are separated by a dash '-'
			-- " continent / zone / locationList "
			continentObject, zoneObject, locationList = strsplit("/", zoneLoc)
			continentObject = tonumber(continentObject)
			zoneObject = tonumber(zoneObject)

			if not continentID or (continentID and continentID == continentObject and zoneID and zoneID == zoneObject) then
				local xLoc, yLoc
				-- " x , y | x , y | ... "
				for location in locationList:gmatch("([^|]+)") do
					xLoc, yLoc = strsplit(",", location)
					table.insert(out, {
						["continentID"] = continentObject,
						["zoneID"] = zoneObject,
						["x"] = (tonumber(xLoc) / 10),
						["y"] = (tonumber(yLoc) / 10),
					})
				end
			end
		end
	end
	
	return out
end

-- OK jusqu'ici


function addon:GetPOITypeID(name)
	if name then	-- returns the id of a given POI type (ex: innkeeper = id 2)
		return addon.POITypeIDs[name]		
	end
end

local revTypes

function addon:GetPOITypeName(id)
	if not revTypes then		-- if the reverse lookup table does not exist yet ..
		revTypes = {}			-- ..create it
		
		for name, poiID in pairs(addon.POITypeIDs) do
			revTypes[poiID] = name
		end
	end
	
	return revTypes[id]
end

function addon:GetPOIIconPath(id)
	if id then		-- returns the icon path of a given POI
		return addon.POIToIconPath[id]
	end
end

function addon:GetPOIList()
	return addon.POIList
end

function addon:GetPOIRawLocations(continentID, zoneID, poiType)
	-- returns raw data for this POI (if available)
		-- ex ["1|8|27"] = "3157`3173"		the string is returned as-is
	return addon.POIList[format("%s|%s|%s", continentID, zoneID, poiType)]
end

function addon:GetPOILocations(continentID, zoneID, poiType)
	-- ["1|8|27"] = "3157`3173",
	-- means : continent 1, zone 8, poi type 27  = npc 3157 and 3173

	-- ["2|14|4"] = "260,494",
	-- not npc based (like a mailbox), so direct x & y loc
	
	local locations = addon:GetPOIRawLocations(continentID, zoneID, poiType)
	if not locations then return end
	
	local locationTable = {}
	local arg1, arg2
	for strLocation in locations:gmatch("([^`]+)") do
		arg1, arg2 = strsplit(",", strLocation)
		
		arg1 = tonumber(arg1)
		
		if arg2 then		-- there is a 2nd argument, it's not NPC based, so arg1 = x & arg2 = y
			table.insert(locationTable, { x = (arg1 / 10), y = (tonumber(arg2) / 10) })
		else		-- it's an npc, get its location
			local _, _, npcLoc = addon:GetNPCLocation(arg1)
			if npcLoc then
				for _, location in pairs(npcLoc) do
					table.insert(locationTable, { x = location.x, y = location.y })
				end
			end
		end
	end
	
	return locationTable
end

﻿--[[	*** OdysseyQuests ***
Written by : Thaoky, EU-Marécages de Zangar
--]]

if not Odyssey then return end

local addonName = "Odyssey"
local addon = _G[addonName]

local L = LibStub("AceLocale-3.0"):GetLocale(addonName)
local BZ = LibStub("LibBabble-Zone-3.0"):GetLookupTable()
local BI = LibStub("LibBabble-Inventory-3.0"):GetLookupTable()

-- ** main / sub categories **
local XPACK_WOW = 1
local XPACK_BC = 2
local XPACK_LK = 3
local XPACK_CATA = 4

local ICON_QUESTIONMARK = "Interface\\RaidFrame\\ReadyCheck-Waiting"

local BASE_CATEGORIES = 5	-- category names provided by the game, ie: continents
local CAT_DUNGEONS = 8
local CAT_PROFESSIONS = 9
local CAT_RAIDS = 10
local CAT_WORLDEVENTS = 11

local mainCat = {
	-- [1] = { name = kalimdor },
	-- [2] = { name = eastern kingdoms },
	-- [3] = { name = outland },
	-- [4] = { name = northrend },
	-- [5] = { name = maelstrom },
	[6] = { name = BATTLEGROUNDS, icon = "Interface\\Icons\\Achievement_PVP_A_15" },
	[7] = { name = L["Classes"], icon = "Interface\\Icons\\Achievement_GuildPerk_Everyones a Hero_rank2" },
	[8] = { name = L["Dungeons"], icon = "Interface\\Icons\\Spell_Holy_SummonChampion" },
	[9] = { name = L["Professions"], icon = "Interface\\Icons\\Ability_Repair" },
	[10] = { name = L["Raid"], icon = "Interface\\Icons\\INV_Helmet_06" },
	[11] = { name = L["World Events"], icon = "Interface\\Icons\\Achievement_Halloween_Witch_01" },
}

local subCat = {
	[6] = {
		{ name = BZ["Alterac Valley"], icon = "Interface\\Icons\\Achievement_BG_winAV" },
		{ name = BZ["Arathi Basin"], icon = "Interface\\Icons\\Achievement_BG_winAB" },
		{ name = BATTLEGROUNDS, icon = "Interface\\Icons\\Achievement_PVP_P_15" },
		{ name = BZ["Eye of the Storm"], icon = "Interface\\Icons\\Achievement_BG_winEOS" },
		{ name = BZ["Isle of Conquest"], icon = "Interface\\Icons\\INV_Shield_61" },
		{ name = BZ["Strand of the Ancients"], icon = "Interface\\Icons\\Achievement_BG_winSOA" },
		{ name = BZ["Warsong Gulch"], icon = "Interface\\Icons\\Achievement_BG_captureflag_WSG" },
	},
	[7] = {
		{ name = BI["Death Knight"], icon = ICON_QUESTIONMARK },
		{ name = BI["Druid"], icon = ICON_QUESTIONMARK },
		{ name = BI["Hunter"], icon = ICON_QUESTIONMARK },
		{ name = BI["Mage"], icon = ICON_QUESTIONMARK },
		{ name = BI["Paladin"], icon = ICON_QUESTIONMARK },
		{ name = BI["Priest"], icon = ICON_QUESTIONMARK },
		{ name = BI["Rogue"], icon = ICON_QUESTIONMARK },
		{ name = BI["Shaman"], icon = ICON_QUESTIONMARK },
		{ name = BI["Warlock"], icon = ICON_QUESTIONMARK },
		{ name = BI["Warrior"], icon = ICON_QUESTIONMARK },
	},
	[8] = {
		{ xpack = XPACK_LK, id = 481 },	-- Ahn'kahet: The Old Kingdom
		{ xpack = XPACK_BC, id = 666 },	-- Auchenai Crypts
		{ xpack = XPACK_LK, id = 480 },	-- Azjol-Nerub
		{ xpack = XPACK_WOW, id = 632 },	-- Blackfathom Deeps
		{ xpack = XPACK_WOW, id = 642 },	-- Blackrock Depths
		{ name = BZ["Blackrock Spire"], xpack = XPACK_WOW, id = 1307 },
		{ name = BZ["Caverns of Time"], xpack = XPACK_BC, id = 851 },	-- tanariss icon
		{ name = BZ["Coilfang Reservoir"], xpack = XPACK_BC, icon = "Interface\\Icons\\Achievement_Zone_Zangarmarsh" },
		{ name = BZ["Dire Maul"], xpack = XPACK_WOW, id = 644 },
		{ xpack = XPACK_LK, id = 482 },	-- Drak'Tharon Keep
		{ xpack = XPACK_WOW, id = 634 },	-- Gnomeregan
		{ xpack = XPACK_LK, id = 484 },	-- Gundrak
		{ xpack = XPACK_LK, id = 486 },	-- Halls of Lightning
		{ xpack = XPACK_LK, id = 4518 },	-- Halls of Reflection
		{ xpack = XPACK_LK, id = 485 },	-- Halls of Stone
		{ xpack = XPACK_BC, id = 647 },	-- Hellfire Ramparts
		{ xpack = XPACK_BC, id = 661 },	-- Magisters' Terrace
		{ xpack = XPACK_BC, id = 651 },	-- Mana-Tombs
		{ xpack = XPACK_WOW, id = 640 },	-- Maraudon
		{ xpack = XPACK_BC, id = 652 },	-- Old Hillsbrad Foothills
		{ xpack = XPACK_LK, id = 4517 },	-- Pit of Saron
		{ xpack = XPACK_WOW, id = 629 },	-- Ragefire Chasm
		{ xpack = XPACK_WOW, id = 636 },	-- Razorfen Downs
		{ xpack = XPACK_WOW, id = 635 },	-- Razorfen Kraul
		{ xpack = XPACK_WOW, id = 637 },	-- Scarlet Monastery
		{ xpack = XPACK_WOW, id = 645 },	-- Scholomance
		{ xpack = XPACK_BC, id = 653 },	-- Sethekk Halls
		{ xpack = XPACK_BC, id = 654 },	-- Shadow Labyrinth
		{ xpack = XPACK_WOW, id = 631 },	-- Shadowfang Keep
		{ xpack = XPACK_WOW, id = 646 },	-- Stratholme
		{ xpack = XPACK_WOW, id = 641 },	-- Sunken Temple
		{ xpack = XPACK_BC, id = 660 },	-- The Arcatraz
		{ xpack = XPACK_BC, id = 655 },	-- The Black Morass
		{ xpack = XPACK_BC, id = 648 },	-- The Blood Furnace
		{ xpack = XPACK_BC, id = 659 },	-- The Botanica
		{ xpack = XPACK_LK, id = 479 },	-- The Culling of Stratholme
		{ xpack = XPACK_WOW, id = 628 },	-- The Deadmines
		{ xpack = XPACK_LK, id = 4516 },	-- The Forge of Souls
		{ xpack = XPACK_BC, id = 658 },	-- The Mechanar
		{ xpack = XPACK_LK, id = 478 },	-- The Nexus
		{ xpack = XPACK_LK, id = 487 },	-- The Oculus
		{ xpack = XPACK_BC, id = 657 },	-- The Shattered Halls
		{ xpack = XPACK_BC, id = 649 },	-- The Slave Pens
		{ xpack = XPACK_BC, id = 656 },	-- The Steamvault
		{ xpack = XPACK_WOW, id = 633 },	-- The Stockade
		{ xpack = XPACK_BC, id = 650 },	-- The Underbog
		{ xpack = XPACK_LK, id = 483 },	-- The Violet Hold
		{ xpack = XPACK_LK, id = 4296 },	-- Trial of the Champion
		{ xpack = XPACK_WOW, id = 638 },	-- Uldaman
		{ xpack = XPACK_LK, id = 477 },	-- Utgarde Keep
		{ xpack = XPACK_LK, id = 488 },	-- Utgarde Pinnacle
		{ xpack = XPACK_WOW, id = 630 },	-- Wailing Caverns
		{ xpack = XPACK_WOW, id = 639 },	-- Zul'Farrak
		{ xpack = XPACK_CATA, id = 4833 },	--  Blackrock caverns
		{ xpack = XPACK_CATA, id = 4840 },	-- Grim Batol
		{ xpack = XPACK_CATA, id = 4841 },	-- Halls of Origination
		{ xpack = XPACK_CATA, id = 4848 },	-- Lost City of Tolvir
		{ xpack = XPACK_CATA, id = 4846 },	-- Stonecore
		{ xpack = XPACK_CATA, id = 4839 },	-- Throne of tides
		{ xpack = XPACK_CATA, id = 4847 },	-- Vortex Pinnacle
	},
	[9] = {
		{ id = 2259 },		-- alchemy
		{ id = 78670 },		-- archaeology
		{ id = 3100 },		-- blacksmithing
		{ id = 2550 },		-- cooking
		{ id = 4036 },		-- engineering
		{ id = 3273 },		-- first aid
		{ id = 71691 },	-- fishing
		{ id = 13614 },	-- herbalism
		{ id = 45357 },	-- inscription
		{ id = 25229 },	-- jewelcrafting
		{ id = 2108 },		-- leatherworking
		{ id = 3908 },		-- tailoring
	},
	[10] = {
		{ id = 697 },	-- Black Temple
		{ id = 685 },	-- Blackwing Lair
		{ id = 695 },	-- Hyjal Summit
		{ name = BZ["Icecrown Citadel"], id = 4530 },
		{ id = 690 },	-- Karazhan
		{ id = 693 },	-- Magtheridon's Lair
		{ id = 686 },	-- Molten Core
		{ name = BZ["Naxxramas"], id = 574 },
		{ name = BZ["Onyxia's Lair"], id = 4396 },
		{ id = 689 },	-- Ruins of Ahn'Qiraj
		{ id = 698 },	-- Sunwell Plateau
		{ id = 696 },	-- Tempest Keep
		{ id = 687 },	-- Temple of Ahn'Qiraj
		{ name = BZ["The Eye of Eternity"], id = 622 },	-- Malygos
		{ name = BZ["The Obsidian Sanctum"], id = 1876 },
		{ name = BZ["The Ruby Sanctum"], id = 4817 },	-- Halion
		{ name = BZ["Trial of the Crusader"], id = 3917 },
		{ name = BZ["Ulduar"], id = 2982 },
		{ id = 691 },	-- Zul'Aman
		{ id = 688 },	-- Zul'Gurub
	},
	[11] = {
		{ name = GetCategoryInfo(162), id = 1684 },	-- brewfest
		{ name = GetCategoryInfo(163), id = 1793 },	-- children's week
		{ name = "Darkmoon Faire", icon = "Interface\\Icons\\INV_Misc_Ticket_Darkmoon_01" },		-- WORLDEVENTS_DARKMOON_FAIRE,
		{ name = "Day of the Dead", id = 3456 },	-- WORLDEVENTS_DAY_OF_THE_DEAD,
		{ name = GetCategoryInfo(158), id = 1656 },	-- hallow's end,
		{ name = "Harvest Festival", icon = "Interface\\Icons\\INV_Misc_Herb_05" },	-- WORLDEVENTS_HARVEST_FESTIVAL,
		{ name = GetCategoryInfo(187), id = 1693 },	-- love is in the air
		{ name = GetCategoryInfo(160), id = 913 },	-- lunar festival
		{ name = GetCategoryInfo(161), id = 1038 },	-- midsummer
		{ name = "New Year's Eve", icon = "Interface\\Icons\\INV_Misc_MissileLarge_Blue" },
		{ name = GetCategoryInfo(14981), id = 3478 },	-- pilgrim's bounty
		{ name = GetCategoryInfo(159), id = 2797 },	-- noblegarden
		{ name = GetCategoryInfo(156), id = 1692 },	-- winterveil
	},
}

function addon:GetMainCategoryName(id)
	if id >= 1 and id <= BASE_CATEGORIES then
		return addon:GetContinentName(id)
	else
		return mainCat[id].name
	end
end

function addon:GetMainCategoryIcon(id)
	if id >= 1 and id <= BASE_CATEGORIES then
		return addon:GetContinentIcon(id)
	else
		return mainCat[id].icon or ICON_QUESTIONMARK
	end
end

function addon:GetSubCategoryName(main, sub)
	if main >= 1 and main <= BASE_CATEGORIES then			-- if main category is a continent, use API
		return addon:GetZoneName(main, sub)
	end
	
	local cat = subCat[main][sub]
	if cat.name then		-- if category has a specific name, return it
		return cat.name
	end

	if main == CAT_PROFESSIONS then
		return GetSpellInfo(cat.id)
	elseif main == CAT_DUNGEONS or main == CAT_RAIDS then
		return select(2, GetAchievementInfo(cat.id))
	end
	
	return "not found !"	-- should not happen !!
end

function addon:GetSubCategoryIcon(main, sub)
	if main >= 1 and main <= BASE_CATEGORIES then			-- if main category is a continent, use API
		return addon:GetZoneIcon(main, sub)
	end
	
	local cat = subCat[main][sub]
	if cat.icon then		-- if category has a specific icon, return it
		return cat.icon
	end
	
	if main == CAT_PROFESSIONS then
		return select(3, GetSpellInfo(cat.id))
	elseif main == CAT_DUNGEONS or main == CAT_RAIDS or main == CAT_WORLDEVENTS then
		return select(10, GetAchievementInfo(cat.id))
	end
	
	-- no icon found ? return default (question mark)
	return ICON_QUESTIONMARK
end

function addon:GetSubCategorySize(main)
	if main >= 1 and main <= BASE_CATEGORIES then
		return addon:GetNumZones(main)
	end
	return #subCat[main]
end

function addon:GetDungeonXPack(sub)
	return subCat[CAT_DUNGEONS][sub].xpack
end

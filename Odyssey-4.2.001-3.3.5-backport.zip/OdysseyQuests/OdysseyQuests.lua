﻿--[[	*** OdysseyQuests ***
Written by : Thaoky, EU-Marécages de Zangar
--]]

if not Odyssey then return end

local addonName = "Odyssey"
local addon = _G[addonName]

--[[	*** API ***

	addon:GetQuestName(questID, level)					returns the quest name
	addon:GetQuestList()									returns a complete list of all known quests (those for which we have a name)
	addon:GetQuestFaction(questID)						returns the faction of a quest (0: unknown, 1: alliance, 2: horde, 3: both)
	addon:GetQuestLevel(questID)							returns the quest level
	addon:GetQuestLink(questID)							returns the quest link
	addon:GetQuestStarter(questID)						returns the name, id and type of the quest starter
	addon:GetQuestEnder(questID)							returns the name, id and type of the quest ender
	addon:GetCategoryQuests(mainCat, subCat)				returns a table containing the quest ids belonging to a given category (main cat + sub cat)
	addon:GetNPCQuests(npcID)							returns a table containing the quest ids started by a given npc
	addon:GetSeriesInfo(questID)							returns the first quest in the series, the position of the quest in the series, and the length of the series
	addon:GetQuestSeries(questID)							returns an ordered table containing the list of quests in a series
	addon:GetRaceQuests(race)							returns a table of quests of a given race (use englishRaceName)
	addon:IsRaceQuest(questID)							returns the race if a quest is a race quest (any race)
	addon:IsSpecificRaceQuest(questID, race)				returns true if a quest is specific to a race (passed as parameter)
	addon:IsQuestRepeatable(questID)						returns true if a quest is repeatable
	addon:IsQuestDaily(questID)							returns true if a quest is a daily quest
	addon:IsQuestWeekly(questID)							returns true if a quest is a weekly quest
	addon:IsDungeonQuest(questID)						returns true if a quest is a dungeon quest
	addon:IsPVPQuest(questID)							returns true if a quest is a PVP quest
	addon:IsRaidQuest(questID)							returns true if a quest is a raid quest
	addon:IsGoToQuest(questID)							returns true if a quest is a "go to" quest
	addon:IsQuestGivingNoXP(questID)						returns true if a quest gives no xp
	addon:IsLevelingQuest(questID)						returns true if a quest is a leveling quest
	addon:IsStartedByItem(questID)						returns true if a quest is started by an item
	addon:GetQuestChoices(questID)						returns a list of quest choices
	addon:GetQuestRewards(questID)						returns a list of quest rewards

	TODO : Dungeon Quests ( by dungeon), review zone quests
	
--]]

--[[	*** Quest Attributes : documentation ***

	Quest information is saved into 4 tables : 
	
	1) addon.QuestList (file QuestDB_xxXX.lua, where xxXX = locale)
		format: [id] = "quest name"
		
	2) addon.QuestAttrib (file QuestAttributes.lua)
		format [id] = attribute (number, to be read bit by bit)
		
		'attribute' :
			bit 0 : alliance quest
			bit 1 : horde quest
			bits 2-8 : quest level
			bits 9-12 : quest category (kalimdor, profession, world event, etc..)
			bits 13-18: quest sub-category (zone, class, etc..)
			bit 19 : isRepeatable
			bit 20: isDaily
			bit 21 : isWeekly
			bit 22 : isDungeon
			bit 23 : isPVP
			bit 24 : isRaid
			bit 25 : isGoTo	(note: a 'goto' quest is a quest that disappears if you've already reached the destination hub (typically quests that send you to the next quest hub are of this type))
			bit 26 : earnsNoXP (true if quest earns no xp)
			
			bit 27 : true if the quest is ended by the same npc/object that started it (saves space, 5000+ quests / 8000 meet this criteria !)
			bits 28-29 : starter Type:	0 = unknown, 1 = npc, 2 = object, 3 = item
			bits 30-45 : a 16-bit value containing the id of the npc/object/item that starts the quest
				if this value is 0, then the id was too big to fit into a 16-bit value, and is save in addon.QuestStarters (see point 3).
			
	3) addon.QuestStarters (file QuestStarters.lua)
		format [id] = starter id
		
		entries in this table all have value higher than 65535, saves a lot of space since only ~200 quests are concerned.
		
	4) addon.QuestEnders (file QuestEnders.lua)
		format [id] = ender attrib
			bits 0-1 : ender Type:	0 = unknown, 1 = npc, 2 = object
			bits 2- : ender id
		
		only ~3000 quests are ended by a different actor than the one that started it; those quests are in this table

	addon.QuestStarters & addon.QuestEnders must be viewed as complements to table addon.QuestAttrib
--]]


local bAnd = bit.band
local bOr = bit.bor
local RShift = bit.rshift
local LShift = bit.lshift

local function TestBit(value, pos)
	-- note: this function works up to bit 51
	local mask = 2 ^ pos		-- 0-based indexing
	return value % (mask + mask) >= mask
end

local function RightShift(value, numBits)
	-- for bits beyond bit 31
	return math.floor(value / 2^numBits)
end

-- ** utility functions **
local function StrToNumTable(s, delim)
	-- converts a delimited list of numbers to a table of numbers
	--	ex: "10|20|30" --> { 10, 20, 30 }
	local out = { strsplit(delim, s) }
	for k, v in pairs(out) do
		out[k] = tonumber(v)
	end
	return out
end

local function GetSeriesSize(questID)
	return select(2, string.gsub(addon.QuestSeries[questID], ",", ",")) + 2
end

function addon:GetQuestName(questID, level)
	if addon.QuestList[questID] then
		return addon.QuestList[questID]
	end
	
	if not level then return end		-- level MUST be provided
	-- otherwise, keep looking using the same technique I used in altoholic to parse item stats also works for quests (found it in cartographer)

	-- note: the correct level must be passed when getting a quest title for the first time, if it's called later, a level of 0 still returns the correct title, 
	-- but this does not work the first time.
	local link = "|cffffff00|Hquest:"..questID..":"..level.."|h[dummy]|h|r"
	
	OdyTooltip:ClearLines();    	-- must be cleared and anchored to work
	OdyTooltip:SetOwner(OdysseyFrame, "ANCHOR_LEFT");
	OdyTooltip:SetHyperlink(link)

	local title = OdyTooltipTextLeft1:GetText()
	OdyTooltip:Hide()
	
	if title then
		return title
	end
end

function addon:GetQuestList()
	return addon.QuestList
end

function addon:GetQuestFaction(questID)
	-- bit 0 = alliance, bit 1 = horde
	-- returns : 
		-- 0 = unknown faction
		-- 1 = alliance
		-- 2 = horde
		-- 3 = both
		
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return bAnd(attrib, 3)	
	end
	return 0
end

function addon:GetQuestLevel(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return bAnd(RShift(attrib, 2), 127)	-- 7-bits mask
	end
	return 0
end

function addon:GetQuestLink(questID)
	local title = addon:GetQuestName(questID)
	local level = addon:GetQuestLevel(questID)
	
	if title and level then
		return "|cffffff00|Hquest:"..questID..":"..level.."|h[" .. title .. "]|h|r"
	end
end

function addon:GetQuestStarter(questID)
	-- returns the name, id and type of the quest starter
	local attrib = addon.QuestAttrib[questID]
	if not attrib then return end
	
	local starterType = bAnd(RightShift(attrib, 28), 3)
	local id = bAnd(RightShift(attrib, 30), 65535)
	if id == 0 then
		id = addon.QuestStarters[questID]
	end
	
	local name
	if starterType == 1 then		-- npc
		name = addon:GetNPCName(id)
	elseif starterType == 2 then	-- object
		name = addon:GetObjectName(id)
	elseif starterType == 3 then	-- item
		name = GetItemInfo(id)
	end
	
	return name or "", id or 0, starterType
end

function addon:GetQuestEnder(questID)
	-- returns the name, id and type of the quest ender
	local attrib = addon.QuestAttrib[questID]
	if not attrib then return end
	
	local enderType, id

	if TestBit(attrib, 27) then		-- if the same npc/object started this quest
		enderType = bAnd(RightShift(attrib, 28), 3)
		id = bAnd(RightShift(attrib, 30), 65535)
		if id == 0 then
			id = addon.QuestStarters[questID]
		end
	else
		if not addon.QuestEnders[questID] then
			return
		end
		enderType = bAnd(addon.QuestEnders[questID], 3)
		id = RightShift(addon.QuestEnders[questID], 2)
	end
	
	local name
	if enderType == 1 then		-- npc
		name = addon:GetNPCName(id)
	elseif enderType == 2 then	-- object
		name = addon:GetObjectName(id)
	end
	
	return name or "", id or 0, enderType
end

local categoryCache = {}	-- this cache will contains the list of quests in a given category/subcategory

function addon:GetCategoryQuests(mainCat, subCat)
	local cacheIndex = format("%s.%s", mainCat, subCat)
	
	if categoryCache[cacheIndex] then		-- already in cache ? return it
		return categoryCache[cacheIndex]
	end

	local out = {}
	local main, sub
	for questID, attrib in pairs(addon.QuestAttrib) do	-- parse the quest DB
		main = bAnd(RShift(attrib, 9), 15)
		sub = bAnd(RShift(attrib, 13), 63)
		
		if main == mainCat and sub == subCat then		-- same cat & subcat ? ok save it
			table.insert(out, questID)
		end
	end

	categoryCache[cacheIndex] = out
	return out
end

local npcCache = {}		-- this cache will contain a list of quests for a given npc

function addon:GetNPCQuests(npcID)
	if npcCache[npcID] then		-- already in cache ? return it
		return npcCache[npcID]
	end

	local out = {}
	local starterID
	
	for questID, attrib in pairs(addon.QuestAttrib) do			-- parse the quest DB
		if bAnd(RightShift(attrib, 28), 3) == 1 then				-- if quest is started by an npc ...
			starterID = bAnd(RightShift(attrib, 30), 65535)		-- .. get its id ...
			if starterID == 0 then
				starterID = addon.QuestStarters[questID]
			end
			
			if starterID == npcID then		-- is it the npc we're looking for ? ok save it
				table.insert(out, questID)
			end
		end
	end
	
	npcCache[npcID] = out
	return out
end

function addon:GetSeriesInfo(questID)
	-- if a quest is part of a series, returns the table index (= the first quest in the series), the position of the quest in the series, and the length of the series
	
	-- Quest series format :	[ quest id ] = "quest id 2 , quest id 3 , ... "
		-- [509] = "513|515|517|524",
		-- means quest 509 is the first of the series and is followed, in that order, by 513, 515 etc..
	local count
	
	if addon.QuestSeries[questID] then		-- if the id is the first of a series..
		return questID, 1, GetSeriesSize(questID)
	end
	
	for id, serie in pairs(addon.QuestSeries) do
		for pos, subQuestID in pairs( { strsplit(",", serie) } ) do
			subQuestID = tonumber(subQuestID)
			if questID == subQuestID then
				return id, pos+1, GetSeriesSize(id)
			end
		end
	end
end

function addon:GetQuestSeries(questID)
	-- with the id of the first quest of a series, return an ordered table of questIDs
	local quests = addon.QuestSeries[questID]
	if quests then
		return StrToNumTable(format("%s,%s", questID, quests), ",")
	end
end


-- *** Race ***
function addon:GetRaceQuests(race)
	local quests = addon.QuestsByRace[race]
	if quests then
		return StrToNumTable(quests, ",")
	end
end

local revRaceQuests = {}

for race, quests in pairs(addon.QuestsByRace) do
	for id in quests:gmatch("(%d+)") do
		revRaceQuests[tonumber(id)] = race
	end
end

function addon:IsRaceQuest(questID)
	return revRaceQuests[questID]
end

function addon:IsSpecificRaceQuest(questID, race)
	if revRaceQuests[questID] then
		return (string.find(revRaceQuests[questID], race))
	end
end


-- *** Other ***
function addon:IsQuestRepeatable(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 19)
	end
end

function addon:IsQuestDaily(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 20)
	end
end

function addon:IsQuestWeekly(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 21)
	end
end

function addon:IsDungeonQuest(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 22)
	end
end

function addon:IsPVPQuest(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 23)
	end
end

function addon:IsRaidQuest(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 24)
	end
end

function addon:IsGoToQuest(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 25)
	end
end

function addon:IsQuestGivingNoXP(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib then
		return TestBit(attrib, 26)
	end
end

function addon:IsLevelingQuest(questID)
	-- a quest is a leveling quest if : it's not repeatable, daily, weekly, giving 0 xp, dungeon, pvp, raid
	-- ie:  if bits 19 to 26 are all 0, then it's a leveling quest
	
	local attrib = addon.QuestAttrib[id]
	if attrib then
		return (bAnd(RShift(attrib, 19), 255) == 0)	-- 8-bits mask
	end
end

function addon:IsStartedByItem(questID)
	local attrib = addon.QuestAttrib[questID]
	if attrib and bAnd(RightShift(attrib, 28), 3) == 3 then
		return true
	end
end

function addon:GetQuestChoices(questID)
	local choices = addon.QuestChoices[questID]
	if not choices then return end

	local out = {}
	for choice in choices:gmatch("[^,]+") do
		table.insert(out, choice)
	end
	
	return out
end

function addon:GetQuestRewards(questID)
	local rewards = addon.QuestRewards[questID]
	if not rewards then return end

	local out = {}
	for reward in rewards:gmatch("[^,]+") do
		table.insert(out, reward)
	end
	
	return out
end

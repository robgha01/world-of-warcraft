SimulationCraft Addon
=====================

This addon collects information about your character and presents a text version suitable for running in Simc

Maintainers
-----------

* navv
* seriallos
* aethys
* Theck (retired)
